# X7 v0.15.0 — AndroidIDE-ready

X7 is a tablet-focused Android Linux desktop manager. The Android app owns a private Debian ARM64 rootfs and a rootless PRoot runtime. It does not require Termux or Termux:X11.

## Build
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1
- Java 17
- compileSdk 34 / targetSdk 34 / minSdk 24

Open the **X7** directory in AndroidIDE and build `app`.

## Runtime architecture
1. X7 app private storage
2. Debian ARM64 rootfs
3. rootless PRoot
4. APT/dpkg
5. XFCE or KDE Plasma
6. X7-managed internal display runtime

No Termux package, Termux:X11 application, or external VNC application is required by the Android UI.

## Stability work in v0.15.0
- Single shared Debian runtime executor
- Main-thread UI callbacks
- Bounded command output
- Safe page fallback instead of UI crashes
- Real embedded runtime scripts included in `app/src/main/assets/scripts`
- VNC/legacy Termux compatibility paths removed
- Installation commands corrected so `apt-get install` is never called without packages
- Runtime/desktop state is checkpointed and recoverable
