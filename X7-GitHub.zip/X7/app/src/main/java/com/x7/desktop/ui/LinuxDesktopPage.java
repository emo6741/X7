package com.x7.desktop.ui;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.EmbeddedDebianRuntime;

/** X7 masaüstü kabuğu. Linux rootfs'i yönetir; gerçek XFCE görüntüsü için ayrı X sunucusu gerekmez şekilde Android içi kabuk sağlar. */
public final class LinuxDesktopPage {
    private LinuxDesktopPage() {}
    public static View build(final Ui ui, final MainActivity act){
        LinearLayout root=ui.column(); root.setBackground(ui.rounded(0xFF102235,16,ui.stroke));
        LinearLayout top=ui.row(); top.setGravity(Gravity.CENTER_VERTICAL); top.addView(ui.text("X7 Linux",25,0xFFFFFFFF,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView status=ui.text("● Debian",12,ui.green,true); top.addView(status); root.addView(top);
        root.addView(ui.text("Dahili Linux çalışma alanı",12,0xFFB8C7D9,false));
        LinearLayout apps=ui.row(); apps.setGravity(Gravity.CENTER); apps.setPadding(0,ui.dp(24),0,ui.dp(24));
        addIcon(ui,apps,"▣","Terminal",v->act.showTab(2)); addIcon(ui,apps,"▤","Mağaza",v->act.showTab(3)); addIcon(ui,apps,"▥","Dosyalar",v->EmbeddedDebianRuntime.get(act).shell("pwd; ls -la /root",(ok,t)->act.runOnUiThread(()->new android.app.AlertDialog.Builder(act).setTitle("/root").setMessage(t).setPositiveButton("Kapat",null).show())));
        root.addView(apps);
        LinearLayout task=ui.addCard(root); task.setPadding(ui.dp(12),ui.dp(10),ui.dp(12),ui.dp(10)); task.addView(ui.text("X7 Desktop Shell",14,ui.text,true)); task.addView(ui.text("Debian rootfs: "+EmbeddedDebianRuntime.get(act).status(),12,ui.sub,false));
        ui.addButton(task,"XFCE paketlerini kur",false,v->EmbeddedDebianRuntime.get(act).shell("apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y xfce4 xfce4-terminal dbus-x11",(ok,t)->act.runOnUiThread(()->new android.app.AlertDialog.Builder(act).setTitle(ok?"XFCE hazır":"Hata").setMessage(t).setPositiveButton("Kapat",null).show())));
        return root;
    }
    private static void addIcon(Ui u,LinearLayout p,String icon,String name,View.OnClickListener l){LinearLayout c=u.column();c.setGravity(Gravity.CENTER);TextView i=u.text(icon,34,0xFFFFFFFF,true);i.setGravity(Gravity.CENTER);c.addView(i,new LinearLayout.LayoutParams(u.dp(78),u.dp(58)));TextView n=u.text(name,11,0xFFFFFFFF,true);n.setGravity(Gravity.CENTER);c.addView(n);c.setOnClickListener(l);u.pressable(c);p.addView(c,new LinearLayout.LayoutParams(0,u.dp(100),1));}
}
