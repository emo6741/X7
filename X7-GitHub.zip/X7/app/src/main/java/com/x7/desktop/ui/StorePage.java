package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.EmbeddedDebianRuntime;

/** Güvenli Debian paket mağazası. Çıktı sınırlıdır ve UI yalnızca ana thread'de güncellenir. */
public final class StorePage {
    private StorePage() {}
    private static final String[][] PKGS={
            {"XFCE Desktop","xfce4 xfce4-terminal dbus-x11","Hafif Linux masaüstü ve terminal"},
            {"Firefox","firefox-esr","Web tarayıcısı"},
            {"Chromium","chromium","Chromium web tarayıcısı"},
            {"VLC","vlc","Medya oynatıcı"},
            {"Git","git","Sürüm kontrolü"},
            {"Python 3","python3 python3-pip","Python geliştirme araçları"},
            {"KDE Plasma","kde-plasma-desktop","Tam KDE masaüstü (büyük paket)"}
    };
    public static View build(final Ui ui, final MainActivity act){
        final EmbeddedDebianRuntime rt=EmbeddedDebianRuntime.get(act);
        LinearLayout col=ui.column();
        col.addView(ui.text("Uygulama Mağazası",28,ui.text,true));
        col.addView(ui.text("Paketler yalnızca X7'nin özel Debian rootfs alanına kurulur.",13,ui.sub,false));
        LinearLayout state=ui.addCard(col);
        state.addView(ui.text("Runtime",16,ui.text,true));
        ui.addRow(state,"Debian",rt.rootfsPresent()?"✓ Hazır":"○ Hazırlanmadı");
        ui.addRow(state,"PRoot",rt.prootPresent()?"✓ Hazır":"○ Hazırlanmadı");
        if(!rt.installed()){
            ui.addButton(state,"Dahili Debian'ı Hazırla",true,v->prepare(act,rt));
            TextView n=ui.text("İlk kullanımda Debian rootfs ve PRoot indirilecektir. Bu işlem uzun sürebilir; uygulama açık kalmalıdır.",12,ui.sub,false); n.setPadding(0,ui.dp(8),0,0); state.addView(n);
        } else {
            ui.addButton(col,"Paket listesini güncelle",false,v->run(act,"apt-get update"));
        }
        for(String[] p:PKGS){
            LinearLayout c=ui.addCard(col); c.addView(ui.text(p[0],17,ui.text,true)); c.addView(ui.text(p[2],12,ui.sub,false));
            ui.addButton(c,"Kur: "+p[1],true,v->{ if(!rt.installed()){ info(act,"Debian hazır değil","Önce Dahili Debian'ı Hazırla düğmesine bas."); return;} run(act,"DEBIAN_FRONTEND=noninteractive apt-get install -y "+p[1]); });
        }
        return ui.scroll(col);
    }
    private static void prepare(MainActivity act,EmbeddedDebianRuntime rt){
        info(act,"Dahili Debian","Hazırlanıyor...\nBu işlem ilk kurulumda uzun sürebilir.");
        rt.prepare((ok,msg)->act.runOnUiThread(()->info(act,ok?"Debian hazır":"Hazırlama başarısız",msg)));
    }
    private static void run(MainActivity act,String cmd){
        EmbeddedDebianRuntime.get(act).shell(cmd,20*60*1000L,(ok,out)->act.runOnUiThread(()->info(act,ok?"Tamamlandı":"İşlem başarısız",out)));
    }
    private static void info(MainActivity act,String title,String msg){
        if(act.isFinishing() || (android.os.Build.VERSION.SDK_INT>=17 && act.isDestroyed())) return;
        TextView tv=new TextView(act); tv.setText(msg==null?"":msg); tv.setTextIsSelectable(true); tv.setTextSize(12); tv.setPadding(24,20,24,20);
        ScrollView sv=new ScrollView(act); sv.addView(tv);
        new AlertDialog.Builder(act).setTitle(title).setView(sv).setPositiveButton("Kapat",null).show();
    }
}
