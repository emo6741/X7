package com.x7.desktop.backend;

import android.content.Context;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.*;
import org.tukaani.xz.XZInputStream;

/** Uygulamanın özel alanındaki Debian ARM64 + rootless PRoot çalışma katmanı. */
public final class EmbeddedDebianRuntime {
    public static final String ROOTFS_URL="https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz";
    public static final String PROOT_URL="https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static";
    private static final int MAX_OUTPUT=48*1024;
    private static final long DEFAULT_TIMEOUT_MS=15*60*1000L;
    private static volatile EmbeddedDebianRuntime instance;
    private final Context app;
    private final File base,rootfs,proot;
    private final ExecutorService io;
    private volatile boolean preparing=false;
    private EmbeddedDebianRuntime(Context c){app=c.getApplicationContext();base=new File(app.getFilesDir(),"linux");rootfs=new File(base,"debian");proot=new File(base,"bin/proot");io=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"X7-Debian");t.setDaemon(true);return t;});}
    public static EmbeddedDebianRuntime get(Context c){EmbeddedDebianRuntime r=instance;if(r==null)synchronized(EmbeddedDebianRuntime.class){r=instance;if(r==null){r=new EmbeddedDebianRuntime(c);instance=r;}}return r;}
    public File rootfs(){return rootfs;}
    public boolean installed(){return new File(rootfs,"etc/debian_version").exists() && proot.isFile() && proot.length()>100*1024 && proot.canExecute();}
    public boolean rootfsPresent(){return new File(rootfs,"etc/debian_version").exists();}
    public boolean prootPresent(){return proot.isFile()&&proot.length()>100*1024&&proot.canExecute();}
    public String status(){return installed()?"Hazır":(rootfsPresent()?"PRoot eksik":"Debian kurulmamış");}
    public void prepare(Callback cb){
        if(installed()){post(cb,true,"Debian hazır");return;}
        io.execute(()->{
            synchronized(this){if(preparing){post(cb,false,"Debian hazırlama işlemi zaten çalışıyor");return;}preparing=true;}
            try{
                base.mkdirs();new File(base,"bin").mkdirs();
                if(!prootPresent()){File part=new File(base,"bin/proot.part");download(PRoot_URL(),part);atomicMove(part,proot);if(!proot.setExecutable(true,true))throw new IOException("PRoot çalıştırılabilir yapılamadı");}
                if(!rootfsPresent()){File archive=new File(base,"debian-rootfs.tar.xz");download(ROOTFS_URL,archive);File tmpRoot=new File(base,"debian.partial");deleteTree(tmpRoot);extractXzTar(archive,tmpRoot);File etc=new File(tmpRoot,"etc/debian_version");if(!etc.exists())throw new IOException("Debian rootfs yapısı geçersiz: /etc/debian_version bulunamadı");deleteTree(rootfs);if(!tmpRoot.renameTo(rootfs))throw new IOException("Debian rootfs taşınamadı");archive.delete();}
                fixRootfs();post(cb,installed(),installed()?"Debian hazır":"Runtime eksik");
            }catch(Throwable t){post(cb,false,safeError(t));}
            finally{synchronized(this){preparing=false;}}
        });
    }
    private static String PRoot_URL(){return PROOT_URL;}
    public void shell(String command,Callback cb){shell(command,DEFAULT_TIMEOUT_MS,cb);}
    public void shell(String command,long timeoutMs,Callback cb){
        final String safe=command==null?"":command.trim();
        io.execute(()->{
            if(!installed()){post(cb,false,"Debian henüz hazır değil");return;}
            Process p=null;
            try{
                ProcessBuilder pb=new ProcessBuilder(proot.getAbsolutePath(),"-0","-r",rootfs.getAbsolutePath(),"-b",app.getFilesDir().getAbsolutePath()+":/x7-host", "/usr/bin/env","-i","HOME=/root","TERM=xterm-256color","LANG=C.UTF-8","LC_ALL=C.UTF-8","PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin","/bin/bash","-lc",safe);
                pb.redirectErrorStream(true);p=pb.start();
                final Process proc=p; final CappedReader reader=new CappedReader(proc.getInputStream(),MAX_OUTPUT);
                Thread drain=new Thread(reader,"X7-output");drain.setDaemon(true);drain.start();
                boolean finished=p.waitFor(Math.max(1000L,timeoutMs),TimeUnit.MILLISECONDS);
                if(!finished){p.destroy();if(!p.waitFor(2,TimeUnit.SECONDS))p.destroyForcibly();post(cb,false,reader.text()+"\nX7: işlem zaman aşımı.");return;}
                drain.join(3000L);int rc=p.exitValue();post(cb,rc==0,reader.text());
            }catch(Throwable t){if(p!=null)p.destroyForcibly();post(cb,false,safeError(t));}
        });
    }
    private void fixRootfs()throws IOException{new File(rootfs,"tmp").mkdirs();new File(rootfs,"root").mkdirs();new File(rootfs,"run").mkdirs();File r=new File(rootfs,"etc/resolv.conf");if(!r.exists())write(r,"nameserver 1.1.1.1\nnameserver 8.8.8.8\n");}
    private static void extractXzTar(File archive,File dest)throws Exception{dest.mkdirs();File tar=new File(archive.getParentFile(),"rootfs.partial.tar");try(InputStream in=new XZInputStream(new FileInputStream(archive));OutputStream out=new BufferedOutputStream(new FileOutputStream(tar))){byte[] b=new byte[128*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}Process p=new ProcessBuilder("/system/bin/tar","-xf",tar.getAbsolutePath(),"-C",dest.getAbsolutePath()).redirectErrorStream(true).start();String e=readCapped(p.getInputStream(),8192);int rc=p.waitFor();tar.delete();if(rc!=0)throw new IOException("rootfs tar açma hatası: "+e);}
    private static void download(String url,File out)throws Exception{File tmp=new File(out.getAbsolutePath()+".download");HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setInstanceFollowRedirects(true);try{c.connect();int code=c.getResponseCode();if(code/100!=2)throw new IOException("HTTP "+code);try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream os=new BufferedOutputStream(new FileOutputStream(tmp))){byte[] b=new byte[128*1024];int n;while((n=in.read(b))!=-1)os.write(b,0,n);}}finally{c.disconnect();}if(tmp.length()<100*1024){tmp.delete();throw new IOException("İndirilen dosya geçersiz veya eksik");}atomicMove(tmp,out);}
    private static void atomicMove(File a,File b)throws IOException{if(b.exists()&&!b.delete())throw new IOException("Eski dosya silinemedi");if(!a.renameTo(b))throw new IOException("Dosya taşınamadı");}
    private static void write(File f,String s)throws IOException{File parent=f.getParentFile();if(parent!=null)parent.mkdirs();try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes("UTF-8"));}}
    private static String readCapped(InputStream in,int max)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream(Math.min(max,8192));byte[] x=new byte[8192];int n,total=0;while((n=in.read(x))!=-1){int take=Math.min(n,Math.max(0,max-total));if(take>0)b.write(x,0,take);total+=n;}if(total>max)b.write("\n[X7: çıktı kısaltıldı]\n".getBytes("UTF-8"));return b.toString("UTF-8");}
    private static void deleteTree(File f){if(!f.exists())return;File[] a=f.listFiles();if(a!=null)for(File x:a){if(x.isDirectory() && !java.nio.file.Files.isSymbolicLink(x.toPath()))deleteTree(x);else x.delete();}f.delete();}
    private static String safeError(Throwable t){String s=t==null?"":String.valueOf(t);return s.length()>2000?s.substring(0,2000):s;}
    private static void post(Callback cb,boolean ok,String out){if(cb==null)return;cb.done(ok,out==null?"":out);}
    public void shutdown(){io.shutdownNow();}
    public interface Callback{void done(boolean ok,String output);}
    private static final class CappedReader implements Runnable{
        private final InputStream in;private final int max;private final ByteArrayOutputStream b=new ByteArrayOutputStream();
        CappedReader(InputStream i,int m){in=i;max=m;}
        public void run(){try{byte[] x=new byte[8192];int n,total=0;while((n=in.read(x))!=-1){int take=Math.min(n,Math.max(0,max-total));if(take>0)b.write(x,0,take);total+=n;}}catch(Exception ignored){}}
        String text(){String s;try{s=b.toString("UTF-8");}catch(Exception e){s=b.toString();}return s+(b.size()>=max?"\n[X7: çıktı kısaltıldı]\n":"");}
    }
}
