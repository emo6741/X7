package com.x7.desktop.backend;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/** Dahili Debian içindeki XFCE/KDE oturumunu güvenli biçimde yönetir. Harici görüntüleme uygulaması yoktur. */
public final class DesktopController {
    public enum Status { UNKNOWN, STOPPED, STARTING, RUNNING, STOPPING, REPAIRING, ERROR }
    public interface Listener { void onChanged(); }
    public interface CheckCallback { void onDone(X11Diagnosis d, CommandResult r); }
    private static final long START_TIMEOUT_MS=90000L;
    private static final long STOP_TIMEOUT_MS=30000L;
    private static DesktopController instance;
    private final Context app;
    private volatile Status status=Status.UNKNOWN;
    private volatile String message="", progress="", notice="", details="";
    private volatile X11Diagnosis diagnosis;
    private volatile Listener listener;
    private volatile boolean operating=false;
    private DesktopController(Context c){app=c.getApplicationContext();}
    public static DesktopController get(Context c){if(instance==null)synchronized(DesktopController.class){if(instance==null)instance=new DesktopController(c);}return instance;}
    public Status getStatus(){return status;} public String getMessage(){return message;} public String getProgress(){return progress;}
    public String getNotice(){return notice;} public String getDetails(){return details;} public X11Diagnosis getDiagnosis(){return diagnosis;}
    public void setListener(Listener l){listener=l;}
    private void changed(){new Handler(Looper.getMainLooper()).post(()->{Listener l=listener;if(l!=null)l.onChanged();});}
    private boolean ready(){return EmbeddedDebianRuntime.get(app).installed() && StateManager.load(app).installState==StateManager.InstallState.COMPLETED;}
    public void refresh(){if(operating)return; if(!ready()){status=Status.STOPPED;message="Önce Debian masaüstü kurulumunu tamamla.";progress="";changed();return;}
        RuntimeRunner.run(app,CommandBuilder.Id.DESKTOP_STATUS,20000L,r->{
            if(r.ok && r.stdout.contains("state=running")){status=Status.RUNNING;message="";} else {status=Status.STOPPED;message=r.ok?"":"Durum okunamadı: "+r.error;}
            changed();
        });
    }
    public void start(){if(operating)return;if(!ready()){fail("Debian runtime hazır değil. Önce kurulumu tamamla.");return;}operating=true;status=Status.STARTING;message="";notice="";diagnosis=null;progress="Masaüstü başlatılıyor...";changed();
        StateManager st=StateManager.load(app); CommandBuilder.Spec spec=CommandBuilder.desktopStart(st.desktop);
        RuntimeRunner.run(app,spec,START_TIMEOUT_MS,r->{
            details=r.stdout; operating=false;
            if(r.ok && (r.stdout.contains("state=running")||r.stdout.contains("state=starting"))){status=Status.RUNNING;notice="✓ "+st.desktop+" başlatıldı.";message="";} else {status=Status.ERROR;message=r.error.length()>0?r.error:"Masaüstü başlatılamadı.";diagnosis=X11Diagnosis.fromCommandResult(r);}
            progress="";changed();
        });
    }
    public void stop(boolean force){if(operating&&status!=Status.RUNNING)return;operating=true;status=Status.STOPPING;progress=force?"Masaüstü zorla durduruluyor...":"Masaüstü durduruluyor...";changed();
        RuntimeRunner.run(app,force?CommandBuilder.Id.DESKTOP_FORCE_STOP:CommandBuilder.Id.DESKTOP_STOP,STOP_TIMEOUT_MS,r->{operating=false;details=r.stdout;status=r.ok?Status.STOPPED:Status.ERROR;message=r.ok?"":r.error;progress="";changed();});
    }
    public void restart(){if(operating)return;stop(false);new Handler(Looper.getMainLooper()).postDelayed(this::start,1200);}
    public void checkX11(CheckCallback cb){RuntimeRunner.run(app,CommandBuilder.Id.X11_CHECK,30000L,r->{X11Diagnosis d=X11Diagnosis.fromCommandResult(r);if(cb!=null)cb.onDone(d,r);});}
    public void repairX11(){if(operating)return;operating=true;status=Status.REPAIRING;progress="Dahili görüntüleme temizleniyor...";changed();RuntimeRunner.run(app,CommandBuilder.Id.X11_REPAIR,60000L,r->{operating=false;details=r.stdout;status=r.ok?Status.STOPPED:Status.ERROR;message=r.ok?"":"Görüntüleme onarımı başarısız: "+r.error;progress="";changed();});}
    public void dismissError(){diagnosis=null;message="";if(status==Status.ERROR)status=Status.STOPPED;changed();}
    public void setRepairing(String p){status=Status.REPAIRING;progress=p;changed();}
    private void fail(String s){operating=false;status=Status.ERROR;message=s;progress="";changed();}
}
