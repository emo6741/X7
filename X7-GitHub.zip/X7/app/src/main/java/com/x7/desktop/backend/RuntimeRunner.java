package com.x7.desktop.backend;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/** Tek giriş noktası: CommandBuilder'ın beyaz listedeki gerçek komutunu dahili Debian'da çalıştırır. */
public final class RuntimeRunner {
    public static final String PERMISSION = "android.permission.INTERNET";
    private RuntimeRunner() {}
    public interface Callback { void onResult(CommandResult r); }
    public static boolean hasPermission(Context c) { return true; }
    public static void run(Context ctx, CommandBuilder.Id id, Callback cb) { run(ctx,id,15000L,cb); }
    public static void run(Context ctx, CommandBuilder.Id id, long timeoutMs, Callback cb) {
        try { run(ctx, CommandBuilder.build(ctx,id), timeoutMs, cb); }
        catch (Throwable t) { post(cb, CommandResult.failure("Komut hazırlanamadı: "+safe(t))); }
    }
    public static void run(Context ctx, CommandBuilder.Spec spec, long timeoutMs, Callback cb) {
        if (spec == null) { post(cb, CommandResult.failure("Boş komut")); return; }
        final EmbeddedDebianRuntime rt=EmbeddedDebianRuntime.get(ctx);
        rt.shell(spec.shellCommand(), timeoutMs, (ok,out) -> {
            int rc=ok?0:1;
            CommandResult r=CommandResult.of(rc,out==null?"":out,ok?"":(out==null?"Dahili runtime hatası":out),ok?"":(out==null?"Dahili runtime hatası":out));
            post(cb,r);
        });
    }
    private static void post(final Callback cb, final CommandResult r) {
        if(cb==null)return;
        new Handler(Looper.getMainLooper()).post(() -> cb.onResult(r));
    }
    private static String safe(Throwable t){String s=t==null?"":String.valueOf(t);return s.length()>1200?s.substring(0,1200):s;}
}
