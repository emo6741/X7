package com.x7.desktop.ui;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;

/** X7 hakkında: mimari, çalışma modeli ve projenin amacı. */
public final class InfoPage {
    private InfoPage() {}
    public static View build(final Ui ui, String ignoredTitle, String ignoredDesc, String ignoredStage) {
        LinearLayout col=ui.column();
        LinearLayout h=new LinearLayout(ui.ctx); h.setGravity(Gravity.CENTER_VERTICAL);
        TextView x=ui.text("X7",31,ui.accent,true); x.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD_ITALIC));
        h.addView(x,new LinearLayout.LayoutParams(ui.dp(42),-2));
        h.addView(ui.text("Hakkında",21,ui.text,true)); col.addView(h);
        col.addView(ui.text("X7 Linux Desktop Manager",13,ui.sub,false));

        LinearLayout hero=ui.addTintCard(col,ui.accent);
        TextView logo=ui.text("X7",58,0xFFFFFFFF,true); logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD_ITALIC));
        hero.addView(logo,new LinearLayout.LayoutParams(-1,ui.dp(76)));
        TextView hv=ui.text("v0.15.0",16,0xFFFFFFFF,true); hv.setGravity(Gravity.CENTER); hero.addView(hv);
        TextView hs=ui.text("Android içinde bağımsız Linux çalışma alanı",13,0xCCFFFFFF,false); hs.setGravity(Gravity.CENTER); hero.addView(hs);

        section(ui,col,"X7 neden yapıldı?",
                "X7'nin amacı Android tablette Linux masaüstü deneyimini tek bir uygulama içinde sunmaktır. " +
                "Harici masaüstü uygulamalarına veya ayrı bir X11 uygulamasına ihtiyaç duymadan Debian çalışma alanını yönetmek hedeflenir.");
        section(ui,col,"Nasıl çalışıyor?",
                "X7 kendi özel uygulama dizininde Debian ARM64 rootfs ve rootless PRoot çalışma katmanını kullanır. " +
                "Linux komutları bu izole çalışma alanında çalışır. Paket kurulumu Debian'ın apt sistemi üzerinden yapılır. " +
                "XFCE veya KDE kurulduğunda masaüstü süreçleri yine aynı dahili çalışma alanından başlatılır.");
        section(ui,col,"Uygulamalar nasıl çalışıyor?",
                "Mağaza sekmesi Debian paketlerini yönetir. Terminal sekmesi doğrudan dahili Debian kabuğuna komut gönderir. " +
                "Masaüstü sekmesi XFCE/KDE oturumunu başlatır, durdurur ve durumunu kontrol eder. Temalar sekmesi Linux masaüstü görünümünü yönetir. " +
                "Onarım sekmesi paket ve runtime sorunlarını kontrol eder.");
        section(ui,col,"Güvenlik ve izolasyon",
                "X7 root erişimi istemez. Debian rootfs Android uygulamasının özel dosya alanında tutulur ve Linux işlemleri rootless PRoot üzerinden çalıştırılır. " +
                "Bu nedenle sistem Android dosyaları üzerinde root yetkisi kullanmaz.");

        LinearLayout c=ui.addCard(col); c.addView(ui.text("Teknik Bilgiler",18,ui.text,true));
        ui.addRow(c,"Runtime","Dahili Debian + PRoot");
        ui.addRow(c,"Mimari","ARM64 / aarch64");
        ui.addRow(c,"Grafik","X7 dahili görüntüleme katmanı");
        ui.addRow(c,"Masaüstü","XFCE / KDE Plasma");
        ui.addRow(c,"Paket yöneticisi","APT / dpkg");
        ui.addRow(c,"Minimum Android","24");
        ui.addRow(c,"Compile SDK","34");
        ui.addRow(c,"Java","17");

        LinearLayout why=ui.addCard(col);
        why.addView(ui.text("Önemli not",16,ui.orange,true));
        why.addView(ui.text("Eski harici bağlantı katmanları bu sürümden kaldırılmıştır. " +
                "Bu sürümün amacı tüm Linux çalışma akışını uygulamanın kendi runtime'ı içinde tutmaktır.",13,ui.sub,false));
        ui.addButton(why,"GitHub",false,new View.OnClickListener(){ public void onClick(View v){ MainActivity a=(MainActivity)ui.ctx; try{ a.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse("https://github.com/emo6741/X7"))); }catch(Exception ignored){} }});
        return ui.scroll(col);
    }
    private static void section(Ui ui,LinearLayout col,String title,String body){
        LinearLayout c=ui.addCard(col); c.addView(ui.text(title,18,ui.text,true));
        TextView t=ui.text(body,14,ui.sub,false); t.setPadding(0,ui.dp(8),0,0); c.addView(t);
    }
}
