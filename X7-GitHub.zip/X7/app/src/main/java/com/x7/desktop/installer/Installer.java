package com.x7.desktop.installer;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.x7.desktop.backend.CommandBuilder;
import com.x7.desktop.backend.CommandResult;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.RuntimeRunner;
import com.x7.desktop.backend.EmbeddedDebianRuntime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Kurulum adımlarını sırayla çalıştırır. Her adım idempotenttir ve bitince
 * checkpoint'e yazılır; yarıda kalırsa kaldığı adımdan devam edilir.
 * Adım içi yüzde gösterilmez: Dahili Debian gerçek ilerleme verisi vermiyor.
 */
public final class Installer {
    public enum StepStatus { PENDING, RUNNING, DONE, FAILED }

    public static final class Step {
        public final String id;
        public final String title;
        public final CommandBuilder.Id cmd;
        public StepStatus status = StepStatus.PENDING;
        Step(String id, String title, CommandBuilder.Id cmd) {
            this.id = id; this.title = title; this.cmd = cmd;
        }
    }

    public interface Listener { void onChanged(); }

    private static final long STEP_TIMEOUT_MS = 40L * 60 * 1000;
    private static Installer instance;

    public final List<Step> steps = new ArrayList<Step>();
    private final Context app;
    private StateManager state;
    private Listener listener;
    private boolean running = false;
    private String error = "";

    private Installer(Context app) {
        this.app = app;
        steps.add(new Step("repo", "Paket deposu (Debian)", CommandBuilder.Id.STEP_REPO));
        steps.add(new Step("scripts", "X7 Dahili Debian scriptleri", CommandBuilder.Id.INSTALL_SCRIPTS));
        steps.add(new Step("desktop", "Masaüstü kuruluyor", CommandBuilder.Id.STEP_XFCE));
        steps.add(new Step("x11", "Dahili Debian:X11 paketi", CommandBuilder.Id.STEP_X11));
        steps.add(new Step("verify", "Doğrulama", CommandBuilder.Id.STEP_VERIFY));
        state = StateManager.load(app);
        // Eski X7 sürümlerinde script adımı yoktu. Kurulum tamamlandı görünse bile
        // scriptler eksikse bir sonraki çalıştırmada gerçek kurulumu yeniden doğrula.
        if (state.installState == StateManager.InstallState.COMPLETED && !state.isDone("scripts")) {
            state.installState = StateManager.InstallState.FAILED;
            state.failedStep = "scripts";
            state.lastError = "Eski kurulumda X7 Dahili Debian scriptleri kurulmamış. Yeniden doğrulama gerekli.";
            state.save();
        }
        syncFromState();
    }

    public static Installer get(Context c) {
        if (instance == null) instance = new Installer(c.getApplicationContext());
        return instance;
    }

    public void setListener(Listener l) { listener = l; }
    public boolean isRunning() { return running; }
    public String getError() { return error; }

    private void notifyChanged() {
        final Listener l = listener;
        if (l == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            Listener current = listener;
            if (current != null) current.onChanged();
        });
    }

    private void syncFromState() {
        for (Step s : steps) {
            s.status = state.isDone(s.id) ? StepStatus.DONE : StepStatus.PENDING;
        }
    }

    /** resume=true: checkpoint'teki tamamlanmış adımları atlar. */
    public void start(boolean resume) {
        if (running) return;
        state = StateManager.load(app);
        if (!resume) state.stepsDone = "";
        state.lastError = "";
        state.failedStep = "";
        state.installState = StateManager.InstallState.INSTALLING;
        state.save();
        error = "";
        syncFromState();
        running = true;
        LogManager.info("INST", resume ? "Kurulum devam ediyor" : "Kurulum başlıyor");
        // İlk kurulumda önce rootfs + PRoot hazırlanır; apt komutları bundan sonra çalışır.
        EmbeddedDebianRuntime.get(app).prepare((ok,msg) -> {
            if(!ok){ running=false; state.setFailed("runtime",msg); error=msg; notifyChanged(); return; }
            runNext();
        });
    }

    private void runNext() {
        Step next = null;
        for (Step s : steps) {
            if (s.status != StepStatus.DONE) { next = s; break; }
        }
        if (next == null) {
            state.installState = StateManager.InstallState.COMPLETED;
            state.save();
            running = false;
            LogManager.info("INST", "Kurulum tamamlandı");
            notifyChanged();
            return;
        }
        final Step step = next;
        step.status = StepStatus.RUNNING;
        state.installState = step.id.equals("verify")
                ? StateManager.InstallState.VERIFYING : StateManager.InstallState.INSTALLING;
        state.save();
        notifyChanged();
        LogManager.info("INST", step.title + " başlıyor");
        CommandBuilder.Spec command = CommandBuilder.build(app, step.cmd);
        if ("desktop".equals(step.id)) {
            command = "KDE Plasma".equals(state.desktop)
                    ? CommandBuilder.build(app, CommandBuilder.Id.STEP_KDE)
                    : CommandBuilder.build(app, CommandBuilder.Id.STEP_XFCE);
        }
        RuntimeRunner.run(app, command, STEP_TIMEOUT_MS, new RuntimeRunner.Callback() {
            @Override public void onResult(CommandResult r) { handle(step, r); }
        });
    }

    private void handle(Step step, CommandResult r) {
        boolean ok = r.ok;
        String err = r.error;
        if (ok && step.id.equals("verify")) {
            Map<String, String> kv = r.keyValues();
            String desktopKey = "KDE Plasma".equals(state.desktop) ? "startplasma-x11" : "startxfce4";
            boolean desktopOk = "yes".equals(kv.get(desktopKey));
            boolean displayOk = true;
            if (!desktopOk || !displayOk) {
                ok = false;
                err = "Doğrulama başarısız: " + desktopKey + "=" + kv.get(desktopKey)
                        + ", görüntü=" + state.display;
            }
        }
        if (ok) {
            if (r.stdout.contains("already the newest version")) {
                LogManager.info("INST", step.title + ": paket zaten kurulu.");
            }
            step.status = StepStatus.DONE;
            state.markDone(step.id);
            LogManager.info("INST", step.title + " tamamlandı");
            runNext();
        } else {
            step.status = StepStatus.FAILED;
            String tail = r.stdout.trim();
            if (tail.length() > 400) tail = tail.substring(tail.length() - 400);
            error = err + (tail.length() > 0 ? "\n" + tail : "");
            state.setFailed(step.id, err);
            running = false;
            LogManager.error("INST", step.title + " başarısız: " + err);
            notifyChanged();
        }
    }
}
