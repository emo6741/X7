package com.x7.desktop.backend;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.tukaani.xz.XZInputStream;

/**
 * X7'nin Dahili Debian'tan bağımsız Linux çalışma alanı.
 * Debian rootfs ve PRoot uygulamanın private filesDir alanında tutulur.
 */
public final class EmbeddedDebianRuntime {
    public static final String ROOTFS_URL = "https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz";
    public static final String PROOT_URL = "https://downloads.sourceforge.net/project/proot.mirror/v5.3.0/proot-v5.3.0-aarch64-static";
    private final Context app;
    private final File base, rootfs, proot;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Object PREPARE_LOCK = new Object();
    private static boolean preparing = false;
    private static final int MAX_OUTPUT = 96 * 1024;

    public EmbeddedDebianRuntime(Context c) {
        app = c.getApplicationContext();
        base = new File(app.getFilesDir(), "linux");
        rootfs = new File(base, "debian");
        proot = new File(base, "bin/proot");
    }
    public File rootfs() { return rootfs; }
    public boolean installed() { return new File(rootfs, "etc/debian_version").exists() && proot.exists(); }
    public boolean rootfsPresent() { return new File(rootfs, "etc/debian_version").exists(); }
    public boolean prootPresent() { return proot.exists(); }
    public String status() { return installed() ? "Hazır" : (rootfsPresent() ? "Runtime eksik" : "Debian kurulmamış"); }

    public void prepare(Callback cb) {
        synchronized (PREPARE_LOCK) {
            if (preparing) {
                if (cb != null) cb.done(true, "Debian hazırlığı zaten devam ediyor");
                return;
            }
            preparing = true;
        }
        IO.execute(() -> {
            try {
                base.mkdirs(); new File(base,"bin").mkdirs();
                if (!proot.exists()) download(PROOT_URL, proot, null);
                proot.setExecutable(true, true);
                if (!rootfsPresent()) {
                    File archive = new File(base, "debian-rootfs.tar.xz");
                    download(ROOTFS_URL, archive, null);
                    extractXzTar(archive, rootfs);
                    archive.delete();
                }
                fixRootfs();
                cb.done(true, "Debian hazır");
            } catch (Throwable t) { cb.done(false, t.toString()); }
            finally { synchronized (PREPARE_LOCK) { preparing = false; } }
        });
    }

    public void shell(String command, Callback cb) {
        IO.execute(() -> {
            try {
                if (!installed()) { cb.done(false, "Debian henüz hazır değil"); return; }
                ProcessBuilder pb = new ProcessBuilder(proot.getAbsolutePath(), "-0", "-r", rootfs.getAbsolutePath(),
                        "/usr/bin/env", "-i", "HOME=/root", "TERM=xterm-256color", "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                        "/bin/bash", "-lc", command);
                pb.redirectErrorStream(true);
                Process p = pb.start();
                String out = readCapped(p.getInputStream(), MAX_OUTPUT);
                int rc = p.waitFor();
                cb.done(rc == 0, out);
            } catch (Throwable t) { cb.done(false, t.toString()); }
        });
    }

    private void fixRootfs() throws IOException {
        new File(rootfs,"tmp").mkdirs(); new File(rootfs,"root").mkdirs(); new File(rootfs,"run").mkdirs();
        File resolv = new File(rootfs,"etc/resolv.conf");
        if (!resolv.exists()) { write(resolv, "nameserver 1.1.1.1\nnameserver 8.8.8.8\n"); }
    }
    private static void extractXzTar(File archive, File dest) throws Exception {
        dest.mkdirs();
        ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", "true");
        // Pure Java XZ decoding; TAR extraction is delegated to the Android toybox tar.
        File tar = new File(archive.getParentFile(), "rootfs.tar");
        try (InputStream in = new XZInputStream(new FileInputStream(archive)); OutputStream out = new FileOutputStream(tar)) {
            byte[] b=new byte[1024*128]; int n; while((n=in.read(b))!=-1) out.write(b,0,n);
        }
        Process p = new ProcessBuilder("/system/bin/tar", "-xf", tar.getAbsolutePath(), "-C", dest.getAbsolutePath()).redirectErrorStream(true).start();
        String e=readAll(p.getInputStream()); int rc=p.waitFor(); tar.delete();
        if(rc!=0) throw new IOException("rootfs tar açma hatası: "+e);
    }
    private static void download(String url, File out, String sha256) throws Exception {
        if(out.exists() && out.length()>1024) return;
        File tmp=new File(out.getAbsolutePath()+".part");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setInstanceFollowRedirects(true); c.connect();
        if(c.getResponseCode()/100!=2) throw new IOException("HTTP "+c.getResponseCode());
        try(InputStream in=c.getInputStream(); OutputStream os=new FileOutputStream(tmp)) { byte[] b=new byte[131072]; int n; while((n=in.read(b))!=-1) os.write(b,0,n); }
        c.disconnect(); if(tmp.length()<1024) throw new IOException("İndirilen dosya geçersiz");
        if(!tmp.renameTo(out)) throw new IOException("Dosya taşınamadı");
    }
    private static void write(File f,String s)throws IOException{f.getParentFile().mkdirs();try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes("UTF-8"));}}
    private static String readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return b.toString("UTF-8");}
    public void shutdown(){ /* Paylaşılan executor kapatılmaz. */ }
    private static String readCapped(InputStream in, int max)throws IOException{
        StringBuilder b=new StringBuilder(Math.min(max, 16384));
        byte[] x=new byte[8192]; int n; int total=0;
        while((n=in.read(x))!=-1){
            if(total < max){
                int take=Math.min(n,max-total);
                b.append(new String(x,0,take,"UTF-8"));
            }
            total+=n;
        }
        if(total>max) b.append("\n[çıktı kısaltıldı: ").append(total-max).append(" bayt gizlendi]");
        return b.toString();
    }
    private static String readAll(InputStream in)throws IOException{return readCapped(in, MAX_OUTPUT);}
    public interface Callback { void done(boolean ok,String output); }
}
