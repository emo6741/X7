package com.x7.desktop.util;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import java.util.Locale;

/** Gerçek cihaz değerlerini okur. Okunamazsa "Bilinmiyor" döner, uydurma değer yok. */
public final class SystemInfo {
    private SystemInfo() {}

    public static String android() {
        return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
    }

    public static String ram(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return fmt(mi.availMem) + " boş / " + fmt(mi.totalMem);
        } catch (Exception e) {
            return "Bilinmiyor";
        }
    }

    public static String storage() {
        try {
            StatFs s = new StatFs(Environment.getDataDirectory().getPath());
            return fmt(s.getAvailableBytes()) + " boş / " + fmt(s.getTotalBytes());
        } catch (Exception e) {
            return "Bilinmiyor";
        }
    }

    /** Kullanım yüzdesi Android'de kolay okunamaz; yalnızca çekirdek sayısı gerçek. */
    public static String cpu() {
        int n = Runtime.getRuntime().availableProcessors();
        return n + " çekirdek (kullanım: Bilinmiyor)";
    }

    public static String fmt(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1) return String.format(Locale.US, "%.1f GB", gb);
        return String.format(Locale.US, "%d MB", bytes / (1024 * 1024));
    }

    /** Android veri bölümündeki boş bayt. Okunamazsa -1. */
    public static long freeBytes() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes();
        } catch (Exception e) {
            return -1;
        }
    }

    public static long ramTotal(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.totalMem;
        } catch (Exception e) { return -1; }
    }

    public static long ramAvail(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Exception e) { return -1; }
    }

    public static long storageTotal() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getTotalBytes();
        } catch (Exception e) { return -1; }
    }

    public static String abi() {
        try {
            return Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?";
        } catch (Exception e) { return "?"; }
    }
}
