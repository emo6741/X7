package com.x7.desktop.backend;

import java.util.HashMap;
import java.util.Map;

/** Bir Termux komutunun sonucu. ok = iletim çalıştı VE çıkış kodu 0. */
public final class CommandResult {
    public final boolean ok;
    public final int exitCode;
    public final String stdout;
    public final String stderr;
    public final String error; // ok ise ""

    private CommandResult(boolean ok, int exitCode, String out, String err, String error) {
        this.ok = ok; this.exitCode = exitCode; this.stdout = out; this.stderr = err; this.error = error;
    }

    public static CommandResult failure(String msg) {
        return new CommandResult(false, -1, "", "", msg);
    }

    public static CommandResult of(int exit, String out, String err, String errmsg) {
        boolean hasErr = errmsg != null && errmsg.length() > 0;
        boolean ok = exit == 0 && !hasErr;
        String e = ok ? "" : (hasErr ? errmsg : "Komut " + exit + " koduyla bitti.");
        return new CommandResult(ok, exit, out == null ? "" : out, err == null ? "" : err, e);
    }

    /** stdout içindeki "anahtar=değer" satırlarını ayrıştırır. */
    public Map<String, String> keyValues() {
        Map<String, String> m = new HashMap<String, String>();
        for (String line : stdout.split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) m.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
        return m;
    }
}
