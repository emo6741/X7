package com.x7.desktop.ui;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.CommandBuilder;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.CommandResult;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.TermuxRunner;
import com.x7.desktop.installer.Estimate;
import com.x7.desktop.installer.Installer;
import com.x7.desktop.installer.WizardState;
import com.x7.desktop.util.SystemInfo;

/** Desktop sekmesi: kurulum sihirbazı (0-4), kurulum ilerlemesi (5), kurulu özeti. */
public final class InstallPage {
    private InstallPage() {}

    private static final long MARGIN = 500L * 1024 * 1024; // güvenlik payı
    private static final long PREP_TIMEOUT = 10L * 60 * 1000;

    public static View build(final Ui ui, final MainActivity act) {
        final Installer inst = Installer.get(act);
        inst.setListener(new Installer.Listener() {
            @Override public void onChanged() { act.refresh(); }
        });
        StateManager st = StateManager.load(act);

        LinearLayout col = ui.column();
        col.addView(ui.text("Masaüstü", 28, ui.text, true));

        if (inst.isRunning()) WizardState.screen = 5;

        if (WizardState.screen == 5) {
            progress(ui, act, col, inst);
        } else if (st.installState == StateManager.InstallState.COMPLETED && WizardState.screen == 0) {
            done(ui, act, col, st);
        } else {
            switch (WizardState.screen) {
                case 1: check(ui, act, col); break;
                case 2: choose(ui, act, col); break;
                case 3: storage(ui, act, col); break;
                case 4: summary(ui, act, col, inst); break;
                default: welcome(ui, act, col, st, inst); break;
            }
        }
        return ui.scroll(col);
    }

    // ---------- yardımcılar ----------

    private static void go(MainActivity act, int screen) {
        WizardState.screen = screen;
        act.refresh();
    }

    private static TextView btn(Ui ui, LinearLayout p, String label, boolean primary,
                                boolean enabled, View.OnClickListener l) {
        TextView b = ui.addButton(p, label, primary, l);
        b.setEnabled(enabled);
        b.setAlpha(enabled ? 1f : 0.45f);
        return b;
    }

    private static void note(Ui ui, LinearLayout p, String s) {
        TextView t = ui.text(s, 13, ui.sub, false);
        t.setPadding(0, ui.dp(8), 0, 0);
        p.addView(t);
    }

    private static void nav(Ui ui, LinearLayout col, final MainActivity act,
                            final int back, boolean nextEnabled, final int next, String nextLabel) {
        btn(ui, col, nextLabel, true, nextEnabled, new View.OnClickListener() {
            @Override public void onClick(View v) { go(act, next); }
        });
        btn(ui, col, "Geri", false, true, new View.OnClickListener() {
            @Override public void onClick(View v) { go(act, back); }
        });
    }

    // ---------- 0: Hoş geldiniz ----------

    private static void welcome(final Ui ui, final MainActivity act, LinearLayout col,
                                final StateManager st, final Installer inst) {
        boolean resumable = st.installState != StateManager.InstallState.NOT_STARTED
                && st.installState != StateManager.InstallState.COMPLETED;
        if (resumable) {
            LinearLayout r = ui.addCard(col);
            r.addView(ui.text("Önceki kurulum yarıda kaldı.", 17, ui.text, true));
            if (st.lastError.length() > 0) note(ui, r, "Son hata: " + st.lastError);
            ui.addButton(r, "Kuruluma Devam Et", true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    WizardState.screen = 5;
                    inst.start(true);
                }
            });
            ui.addButton(r, "Baştan Kur", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    st.resetProgress();
                    act.refresh();
                }
            });
        }

        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("X7 · Linux Desktop Manager", 18, ui.accent, true));
        note(ui, c, "X7, cihazınıza Linux masaüstü bileşenleri kuracaktır.\n\n"
                + "İnternet bağlantısı ve yeterli depolama alanı gerekir.\n\n"
                + "Bazı masaüstleri cihazınıza göre yüksek kaynak kullanabilir.\n\n"
                + "Kurulum sırasında uygulamadan çıkmamaya çalış. Yarım kalırsa kaldığı yerden devam edebilir.");
        ui.addButton(c, "Devam Et", true, new View.OnClickListener() {
            @Override public void onClick(View v) { go(act, 1); }
        });
    }

    // ---------- 1: Sistem kontrolü ----------

    private static void check(final Ui ui, final MainActivity act, LinearLayout col) {
        boolean tx = TermuxDetector.check(act, TermuxDetector.TERMUX).installed;
        boolean x11 = TermuxDetector.check(act, TermuxDetector.X11).installed;
        boolean perm = TermuxRunner.hasPermission(act);

        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Sistem Kontrolü", 18, ui.text, true));
        ui.addRow(c, "Android", SystemInfo.android());
        ui.addRow(c, "Termux", tx ? "✓ Bulundu" : "✗ Bulunamadı");
        ui.addRow(c, "Termux:X11", x11 ? "✓ Bulundu" : "✗ Bulunamadı");
        ui.addRow(c, "Komut izni", perm ? "✓ Verildi" : "✗ Verilmedi");
        String net = WizardState.netChecking ? "⟳ Kontrol ediliyor"
                : WizardState.netOk == null ? "Henüz kontrol edilmedi"
                : WizardState.netOk ? "✓ Erişilebilir" : "✗ Yok";
        ui.addRow(c, "İnternet", net);

        if (!tx) {
            note(ui, c, "Eksik uygulamaları Home sekmesindeki bağlantılardan indir, sonra buraya dön.");
        } else if (!perm) {
            note(ui, c, "Settings sekmesinden komut iznini ver ve allow-external-apps ayarını yap.");
        } else if (Boolean.FALSE.equals(WizardState.netOk)) {
            note(ui, c, WizardState.netMsg);
        }

        if (tx && perm) {
            btn(ui, c, "Kontrol Et", false, !WizardState.netChecking, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    WizardState.netChecking = true;
                    act.refresh();
                    TermuxRunner.run(act, CommandBuilder.Id.NETCHECK, new TermuxRunner.Callback() {
                        @Override public void onResult(CommandResult r) {
                            WizardState.netChecking = false;
                            if (!r.ok) {
                                WizardState.netOk = false;
                                WizardState.netMsg = r.error;
                            } else {
                                boolean y = "yes".equals(r.keyValues().get("net"));
                                WizardState.netOk = y;
                                WizardState.netMsg = y ? ""
                                        : "Linux paketlerini indirmek için internet bağlantısı gerekiyor.";
                            }
                            act.refresh();
                        }
                    });
                }
            });
        }
        boolean ready = tx && perm && Boolean.TRUE.equals(WizardState.netOk);
        nav(ui, col, act, 0, ready, 2, "Devam Et");
    }

    // ---------- 2: Masaüstü ve görüntü ----------

    private static void choose(Ui ui, MainActivity act, LinearLayout col) {
        LinearLayout d = ui.addCard(col);
        d.addView(ui.text("Masaüstü", 18, ui.text, true));
        final StateManager desktopState = StateManager.load(act);
        ui.addRow(d, "XFCE", "XFCE".equals(desktopState.desktop) ? "✓ Seçili · Önerilen" : "Önerilen");
        ui.addRow(d, "KDE Plasma", "KDE Plasma".equals(desktopState.desktop) ? "✓ Seçili" : "Daha fazla kaynak kullanabilir");
        note(ui, d, "XFCE hafif ve özelleştirilebilir. KDE Plasma daha modern ancak daha fazla kaynak kullanabilir.");
        ui.addButton(d, "XFCE'yi Seç", "XFCE".equals(desktopState.desktop), new View.OnClickListener() {
            @Override public void onClick(View v) { StateManager s = StateManager.load(act); s.setDesktop("XFCE"); act.refresh(); }
        });
        ui.addButton(d, "KDE Plasma'yı Seç", "KDE Plasma".equals(desktopState.desktop), new View.OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(act).setTitle("Performans Uyarısı")
                        .setMessage("KDE Plasma, XFCE'ye göre daha fazla RAM ve CPU kullanabilir. Daha güçlü cihazlarda tercih edilmesi önerilir.")
                        .setNegativeButton("Vazgeç", null)
                        .setPositiveButton("Devam Et", (dialog, which) -> { StateManager s = StateManager.load(act); s.setDesktop("KDE Plasma"); act.refresh(); }).show();
            }
        });

        LinearLayout g = ui.addCard(col);
        g.addView(ui.text("Görüntü Yöntemi", 18, ui.text, true));
        final StateManager selectedState = StateManager.load(act);
        ui.addRow(g, "Termux:X11", "Termux:X11".equals(selectedState.display) ? "✓ Seçili · Önerilen" : "Önerilen");
        ui.addRow(g, "VNC", "VNC".equals(selectedState.display) ? "✓ Seçili · Alternatif" : "Alternatif");
        note(ui, g, "Termux:X11 önerilir. VNC, TigerVNC ile localhost üzerinde alternatif görüntü sağlar ve ilk kullanımda Termux'ta vncpasswd gerektirir.");
        ui.addButton(g, "VNC'yi Seç", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                StateManager st = StateManager.load(act);
                st.setDisplay("VNC");
                Toast.makeText(act, "VNC seçildi. Kurulumdan sonra Settings > VNC ile hazırlanabilir.", Toast.LENGTH_SHORT).show();
            }
        });
        ui.addButton(g, "Termux:X11'i Seç", "Termux:X11".equals(desktopState.display), new View.OnClickListener() {
            @Override public void onClick(View v) {
                StateManager st = StateManager.load(act);
                st.setDisplay("Termux:X11");
                act.refresh();
            }
        });
        boolean x11Ready = TermuxDetector.check(act, TermuxDetector.X11).installed;
        if ("Termux:X11".equals(desktopState.display) && !x11Ready) {
            note(ui, g, "Termux:X11 seçili. Kuruluma devam etmek için Termux:X11 Android uygulamasını kurmalısın.");
        }

        nav(ui, col, act, 1, "VNC".equals(desktopState.display) || x11Ready, 3, "Devam Et");
    }

    // ---------- 3: Depolama ----------

    private static void storage(final Ui ui, final MainActivity act, LinearLayout col) {
        Estimate e = WizardState.estimate;
        long free = SystemInfo.freeBytes();

        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Depolama", 18, ui.text, true));
        ui.addRow(c, "Boş alan", free < 0 ? "Bilinmiyor" : SystemInfo.fmt(free));

        boolean nextOk = false;
        if (WizardState.estimating) {
            ui.addRow(c, "Durum", "⟳ Hesaplanıyor (depo güncelleniyor)");
            note(ui, c, "Bu işlem internet hızına göre bir iki dakika sürebilir.");
        } else if (e == null || !e.ok) {
            if (e != null) note(ui, c, "✗ " + e.error);
            else note(ui, c, "Gereken alan, paket deposundan okunan gerçek boyutlarla hesaplanır. "
                    + "Bunun için paket deposu güncellenir ve x11-repo eklenir (küçük bir işlem).");
            btn(ui, c, e == null ? "Hesapla" : "Tekrar Dene", true, true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    WizardState.estimating = true;
                    WizardState.estimate = null;
                    act.refresh();
                    StateManager estimateState = StateManager.load(act);
                    TermuxRunner.run(act, CommandBuilder.prepareEstimate(estimateState.desktop, estimateState.display), PREP_TIMEOUT,
                            new TermuxRunner.Callback() {
                        @Override public void onResult(CommandResult r) {
                            WizardState.estimate = Estimate.from(r);
                            WizardState.estimating = false;
                            act.refresh();
                        }
                    });
                }
            });
        } else {
            long need = e.downloadBytes + e.installBytes + MARGIN;
            ui.addRow(c, "İndirme", SystemInfo.fmt(e.downloadBytes));
            ui.addRow(c, "Kurulum (açılmış)", SystemInfo.fmt(e.installBytes));
            ui.addRow(c, "Güvenlik payı", SystemInfo.fmt(MARGIN));
            ui.addRow(c, "Tahmini gereken", SystemInfo.fmt(need));
            if (free >= 0 && free >= need) {
                note(ui, c, "✓ Yeterli depolama var.");
                nextOk = true;
            } else if (free < 0) {
                note(ui, c, "✗ Boş alan okunamadığı için kurulum başlatılamaz.");
            } else {
                note(ui, c, "✗ Yetersiz depolama. Kurulum başlatılamaz; en az "
                        + SystemInfo.fmt(need - free) + " daha boş alan aç.");
            }
        }
        nav(ui, col, act, 2, nextOk, 4, "Devam Et");
    }

    // ---------- 4: Özet ----------

    private static void summary(final Ui ui, final MainActivity act, LinearLayout col,
                                final Installer inst) {
        Estimate e = WizardState.estimate;
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Kurulum Özeti", 18, ui.text, true));
        StateManager selected = StateManager.load(act);
        ui.addRow(c, "Masaüstü", selected.desktop);
        ui.addRow(c, "Görüntü", selected.display);
        ui.addRow(c, "Tema", "KDE Plasma".equals(selected.desktop) ? "Bu aşamada ayrı tema uygulanmayacak" : selected.theme);
        ui.addRow(c, "Ek paket", "0");
        ui.addRow(c, "Tahmini indirme", e != null && e.ok ? SystemInfo.fmt(e.downloadBytes) : "Bilinmiyor");
        ui.addRow(c, "Tahmini kullanım", e != null && e.ok ? SystemInfo.fmt(e.installBytes) : "Bilinmiyor");

        btn(ui, col, "Kurulumu Başlat", true, e != null && e.ok, new View.OnClickListener() {
            @Override public void onClick(View v) {
                WizardState.screen = 5;
                inst.start(false);
            }
        });
        btn(ui, col, "Geri", false, true, new View.OnClickListener() {
            @Override public void onClick(View v) { go(act, 3); }
        });
    }

    // ---------- 5: Kurulum ilerlemesi ----------

    private static void progress(final Ui ui, final MainActivity act, LinearLayout col,
                                 final Installer inst) {
        boolean allDone = true, failed = false;
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Kurulum", 18, ui.text, true));
        for (Installer.Step s : inst.steps) {
            String v;
            switch (s.status) {
                case DONE: v = "✓ Tamamlandı"; break;
                case RUNNING: v = "⟳ Devam ediyor"; break;
                case FAILED: v = "✗ Başarısız"; break;
                default: v = "○ Bekliyor"; break;
            }
            if (s.status != Installer.StepStatus.DONE) allDone = false;
            if (s.status == Installer.StepStatus.FAILED) failed = true;
            ui.addRow(c, s.title, v);
        }

        LinearLayout cmdCard = ui.addCard(col);
        cmdCard.addView(ui.text("Termux'a gönderilen son komut", 16, ui.text, true));
        TextView cmd = ui.text(LogManager.lastCommand(), 12, ui.sub, false);
        cmd.setTextIsSelectable(true);
        cmd.setPadding(0, ui.dp(8), 0, 0);
        cmdCard.addView(cmd);
        ui.addButton(cmdCard, "Komutu Tamamını Gör", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(act)
                        .setTitle("Termux komutu")
                        .setMessage(LogManager.lastCommand())
                        .setPositiveButton("Kapat", null).show();
            }
        });

        if (allDone) {
            LinearLayout d = ui.addCard(col);
            d.addView(ui.text("Kurulum tamamlandı.", 20, ui.text, true));
            note(ui, d, "X7 masaüstünüz hazır. Home veya Desktop sekmesinden başlatabilirsin.");
            ui.addButton(d, "Tamam", true, new View.OnClickListener() {
                @Override public void onClick(View v) { go(act, 0); }
            });
        } else if (failed) {
            LinearLayout d = ui.addCard(col);
            d.addView(ui.text("Kurulum tamamlanamadı", 18, ui.text, true));
            TextView err = ui.text(inst.getError(), 12, ui.sub, false);
            err.setTextIsSelectable(true);
            err.setPadding(0, ui.dp(8), 0, 0);
            d.addView(err);
            ui.addButton(d, "Tekrar Dene", true, new View.OnClickListener() {
                @Override public void onClick(View v) { inst.start(true); }
            });
            ui.addButton(d, "Logları Gör", false, new View.OnClickListener() {
                @Override public void onClick(View v) { act.showTab(5); }
            });
        } else if (inst.isRunning()) {
            note(ui, c, "Bu aşama dakikalar sürebilir. Yüzde gösterilmiyor, çünkü Termux gerçek "
                    + "ilerleme verisi vermiyor. Uygulamadan çıkarsan kurulum kaldığı yerden devam edebilir.");
        } else {
            ui.addButton(c, "Devam Et", true, new View.OnClickListener() {
                @Override public void onClick(View v) { inst.start(true); }
            });
        }
    }

    // ---------- Kurulu özeti ----------

    private static void done(final Ui ui, final MainActivity act, LinearLayout col,
                             final StateManager st) {
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("✓ Masaüstü kurulu", 18, ui.text, true));
        ui.addRow(c, "Masaüstü", st.desktop);
        ui.addRow(c, "Görüntü", st.display);
        LinearLayout k = ui.addCard(col);
        k.addView(ui.text("Masaüstü Kontrolü", 17, ui.text, true));
        ui.addRow(k, "Durum", DesktopControls.statusText(DesktopController.get(act)));
        DesktopControls.add(ui, act, k, true);
        note(ui, k, "Android, Termux süreçlerini arka planda durdurabilir. Sorun yaşarsan Termux için "
                + "pil optimizasyonunu Android ayarlarından kontrol et (X7 bunu senin yerine değiştirmez). "
                + "Çalışan masaüstü bataryayı tüketir.");
        ui.addButton(c, "Yeniden Kur", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                st.resetProgress();
                WizardState.screen = 0;
                act.refresh();
            }
        });
    }
}
