package com.x7.desktop.ui;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.EmbeddedDebianRuntime;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.StateManager;

/** Yalnızca dahili X7 runtime ayarları. Harici Termux/X11 bağımlılığı yoktur. */
public final class SettingsPage {
    private SettingsPage() {}
    public static View build(final Ui ui, final Activity act) {
        LinearLayout col=ui.column(); col.addView(ui.text("Ayarlar",28,ui.text,true));
        final EmbeddedDebianRuntime rt=new EmbeddedDebianRuntime(act);
        LinearLayout r=ui.addCard(col); r.addView(ui.text("Dahili Linux Runtime",18,ui.text,true));
        ui.addRow(r,"Debian rootfs",rt.rootfsPresent()?"✓ Hazır":"✗ Kurulmamış");
        ui.addRow(r,"PRoot",rt.prootPresent()?"✓ Hazır":"✗ Kurulmamış");
        ui.addRow(r,"Genel durum",rt.status());
        final TextView out=ui.text("",12,ui.sub,false); out.setTypeface(Typeface.MONOSPACE); out.setTextIsSelectable(true); r.addView(out);
        ui.addButton(r,"Runtime'ı Hazırla",true,new View.OnClickListener(){ public void onClick(View v){ out.setText("⟳ Debian hazırlanıyor..."); rt.prepare((ok,msg)->act.runOnUiThread(()->{out.setText((ok?"✓ ":"✗ ")+msg); if(act instanceof MainActivity)((MainActivity)act).refresh();})); }});
        ui.addButton(r,"Runtime Durumunu Yenile",false,new View.OnClickListener(){ public void onClick(View v){ out.setText("Durum: "+rt.status()); }});

        LinearLayout d=ui.addCard(col); d.addView(ui.text("Görüntüleme",18,ui.text,true));
        d.addView(ui.text("Harici Termux:X11 veya ayrı X11 APK'sı kullanılmaz. Grafik katmanı X7'nin kendi Linux çalışma akışının parçasıdır.",13,ui.sub,false));
        final StateManager st=StateManager.load(act); ui.addRow(d,"Masaüstü",st.desktop); ui.addRow(d,"Görüntü", "Dahili");
        ui.addButton(d,"Masaüstü ayarlarını aç",false,new View.OnClickListener(){ public void onClick(View v){ if(act instanceof MainActivity)((MainActivity)act).showTab(1); }});

        LinearLayout logs=ui.addCard(col); logs.addView(ui.text("Son İşlem",18,ui.text,true));
        final TextView last=ui.text(LogManager.lastCommand(),11,ui.text,false); last.setTypeface(Typeface.MONOSPACE); last.setTextIsSelectable(true); logs.addView(last);
        ui.addButton(logs,"Logu Yenile",false,new View.OnClickListener(){ public void onClick(View v){ last.setText(LogManager.lastCommand()); }});
        return ui.scroll(col);
    }
}
