package com.x7.desktop.ui;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.backend.CommandBuilder;
import com.x7.desktop.backend.CommandResult;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.TermuxRunner;
import com.x7.desktop.backend.X11Diagnosis;
import com.x7.desktop.MainActivity;
import java.util.List;
import java.util.Map;

/** Ayarlar: Termux bağlantısı testi, kurulum durumu, loglar. */
public final class SettingsPage {
    private SettingsPage() {}

    private static final String ENABLE_CMD = com.x7.desktop.backend.ConnectionDoctor.ALLOW_CMD;

    public static View build(final Ui ui, final Activity act) {
        LinearLayout col = ui.column();
        col.addView(ui.text("Settings", 28, ui.text, true));

        final boolean termuxOk = TermuxDetector.check(act, TermuxDetector.TERMUX).installed;
        final boolean perm = TermuxRunner.hasPermission(act);

        // --- Termux bağlantısı ---
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Termux Bağlantısı", 18, ui.text, true));
        ui.addRow(c, "Termux", termuxOk ? "✓ Kurulu" : "✗ Kurulu değil");
        ui.addRow(c, "RUN_COMMAND izni", perm ? "✓ Verildi" : "✗ Verilmedi");
        TextView how = ui.text("X7'nin Termux'a komut gönderebilmesi için Termux'ta bir kez şu komutu "
                + "çalıştır, sonra Termux'u tamamen kapatıp yeniden aç. X7 bunu senin yerine yapamaz.",
                13, ui.sub, false);
        how.setPadding(0, ui.dp(8), 0, ui.dp(6));
        c.addView(how);
        TextView cmd = ui.text(ENABLE_CMD, 12, ui.text, false);
        cmd.setTypeface(Typeface.MONOSPACE);
        cmd.setTextIsSelectable(true);
        c.addView(cmd);
        ui.addButton(c, "Komutu Kopyala ve Termux'u Aç", false, new View.OnClickListener() {
            @Override public void onClick(View v) { ConnectionCard.copyAllowCmdAndOpenTermux(act); }
        });

        final TextView result = ui.text("", 13, ui.sub, false);
        result.setPadding(0, ui.dp(10), 0, 0);

        if (termuxOk && !perm) {
            ui.addButton(c, "İzni İste", true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    LogManager.info("PERM", "RUN_COMMAND izni isteniyor");
                    act.requestPermissions(new String[]{TermuxRunner.PERMISSION}, 1);
                }
            });
        }
        ui.addButton(c, "Bağlantıyı Test Et", perm && termuxOk, new View.OnClickListener() {
            @Override public void onClick(View v) {
                result.setText("⟳ Test ediliyor...");
                TermuxRunner.run(act, CommandBuilder.Id.PROBE, new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult r) {
                        if (!r.ok) { result.setText("✗ " + r.error); return; }
                        Map<String, String> kv = r.keyValues();
                        result.setText("✓ Bağlantı çalışıyor\n"
                                + "Mimari: " + kv.get("arch") + "\n"
                                + "XFCE (startxfce4): " + kv.get("startxfce4") + "\n"
                                + "termux-x11 paketi: " + kv.get("termux-x11"));
                    }
                });
            }
        });
        c.addView(result);

        // --- X11 kontrolü (System Check) ---
        final TermuxDetector.Result x11app = TermuxDetector.check(act, TermuxDetector.X11);
        LinearLayout x = ui.addCard(col);
        x.addView(ui.text("X11 Kontrolü", 18, ui.text, true));
        ui.addRow(x, "Termux:X11 uygulaması",
                x11app.installed ? "✓ Kurulu (v" + x11app.version + ")" : "✗ Kurulu değil");
        TextView xhelp = ui.text("X11 grafik bağlantısıdır. Linux masaüstünün Android ekranında "
                + "görüntülenmesini sağlar. Kontrol salt-okunurdur, hiçbir şeyi değiştirmez.",
                13, ui.sub, false);
        xhelp.setPadding(0, ui.dp(8), 0, 0);
        x.addView(xhelp);
        final TextView xres = ui.text("", 13, ui.sub, false);
        xres.setPadding(0, ui.dp(10), 0, 0);
        xres.setTextIsSelectable(true);
        final TextView[] fixBtn = new TextView[1];
        ui.addButton(x, "X11 Kontrol Et", perm && termuxOk, new View.OnClickListener() {
            @Override public void onClick(View v) {
                xres.setText("⟳ Kontrol ediliyor...");
                if (fixBtn[0] != null) fixBtn[0].setVisibility(View.GONE);
                DesktopController.get(act).checkX11(new DesktopController.CheckCallback() {
                    @Override public void onDone(X11Diagnosis d, CommandResult r) {
                        xres.setText(describeX11(x11app.installed, d, r));
                        boolean installed = StateManager.load(act).installState
                                == StateManager.InstallState.COMPLETED;
                        if (fixBtn[0] != null) {
                            fixBtn[0].setVisibility(d.fixable && installed ? View.VISIBLE : View.GONE);
                        }
                    }
                });
            }
        });
        x.addView(xres);
        fixBtn[0] = ui.addButton(x, "🔧 Sorunu Çöz", true, new View.OnClickListener() {
            @Override public void onClick(View v) {
                DesktopController.get(act).repairX11();
                if (act instanceof MainActivity) ((MainActivity) act).showTab(1); // ilerlemeyi göster
            }
        });
        fixBtn[0].setVisibility(View.GONE);

        // --- Görüntü yöntemi / VNC ---
        final StateManager current = StateManager.load(act);
        LinearLayout dcard = ui.addCard(col);
        dcard.addView(ui.text("Görüntü Yöntemi", 18, ui.text, true));
        ui.addRow(dcard, "Seçili", current.display);
        dcard.addView(ui.text("Termux:X11 önerilir. VNC alternatif görüntü yöntemidir ve localhost ile sınırlandırılır.",
                13, ui.sub, false));
        ui.addButton(dcard, "Termux:X11 kullan", "Termux:X11".equals(current.display), new View.OnClickListener() {
            @Override public void onClick(View v) {
                StateManager s = StateManager.load(act);
                s.setDisplay("Termux:X11");
                if (act instanceof MainActivity) ((MainActivity) act).refresh();
            }
        });
        ui.addButton(dcard, "VNC kullan", "VNC".equals(current.display), new View.OnClickListener() {
            @Override public void onClick(View v) {
                DesktopController.get(act).setupVnc(new Runnable() {
                    @Override public void run() { if (act instanceof MainActivity) ((MainActivity) act).refresh(); }
                });
            }
        });
        ui.addButton(dcard, "VNC çözünürlüğü: " + current.vncResolution, false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                final String[] values = {"1280x720", "1600x900", "1920x1080"};
                int checked = 0;
                String now = StateManager.load(act).vncResolution;
                for (int i = 0; i < values.length; i++) if (values[i].equals(now)) checked = i;
                new android.app.AlertDialog.Builder(act)
                        .setTitle("VNC çözünürlüğü")
                        .setSingleChoiceItems(values, checked, (dialog, which) -> {
                            StateManager st = StateManager.load(act);
                            st.setVncResolution(values[which]);
                            dialog.dismiss();
                            if (act instanceof MainActivity) ((MainActivity) act).refresh();
                        }).setNegativeButton("İptal", null).show();
            }
        });
        final TextView vncStatus = ui.text("", 13, ui.sub, false);
        dcard.addView(vncStatus);
        ui.addButton(dcard, "VNC Durumunu Kontrol Et", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                vncStatus.setText("⟳ Kontrol ediliyor...");
                TermuxRunner.run(act, CommandBuilder.Id.VNC_STATUS, new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult r) {
                        if (!r.ok) { vncStatus.setText("✗ " + r.error); return; }
                        Map<String,String> kv = r.keyValues();
                        vncStatus.setText("Durum: " + kv.get("state") + "\n"
                                + "Port: " + kv.get("port") + "\n"
                                + "Parola: " + ("yes".equals(kv.get("password")) ? "✓ Ayarlı" : "✗ Ayarlı değil"));
                    }
                });
            }
        });
        ui.addButton(dcard, "VNC'yi Termux'ta Hazırla", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                DesktopController.get(act).setupVnc(new Runnable() {
                    @Override public void run() {
                        TermuxDetector.open(act, TermuxDetector.TERMUX);
                        new android.app.AlertDialog.Builder(act).setTitle("VNC parolası")
                                .setMessage("Termux'ta bir kez 'vncpasswd' çalıştır. X7 parolayı görmez ve saklamaz.")
                                .setPositiveButton("Tamam", null).show();
                    }
                });
            }
        });

        // --- Kurulum durumu ---
        StateManager st = StateManager.load(act);
        LinearLayout s = ui.addCard(col);
        s.addView(ui.text("Kurulum Durumu", 18, ui.text, true));
        ui.addRow(s, "Durum", st.installState.name());
        ui.addRow(s, "Masaüstü", st.desktop);
        ui.addRow(s, "Görüntü", st.display);
        ui.addRow(s, "Son hata", st.lastError.length() == 0 ? "-" : st.lastError);

        // --- Loglar ---
        LinearLayout l = ui.addCard(col);
        l.addView(ui.text("Loglar", 18, ui.text, true));
        final TextView logView = ui.text("", 11, ui.sub, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        final boolean[] detailed = {false};
        refreshLog(logView, detailed[0]);
        l.addView(logView);
        ui.addButton(l, "Teknik Ayrıntılar", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                detailed[0] = !detailed[0];
                refreshLog(logView, detailed[0]);
            }
        });

        return ui.scroll(col);
    }

    private static String yes(String v) { return "yes".equals(v) ? "✓" : "✗"; }

    /** Kontrol sonucunu satır satır, gerçek değerlerle yazar. Doğrulanamayanı "ok" göstermez. */
    private static String describeX11(boolean appInstalled, X11Diagnosis d, CommandResult r) {
        Map<String, String> kv = r.keyValues();
        StringBuilder sb = new StringBuilder();
        if (kv.containsKey("pkg_x11")) {
            sb.append("termux-x11 paketi: ").append(yes(kv.get("pkg_x11"))).append('\n');
            sb.append("XFCE (startxfce4): ").append(yes(kv.get("pkg_xfce"))).append('\n');
            String sv = kv.get("server");
            sb.append("X sunucusu: ").append("running".equals(sv) ? "Çalışıyor"
                    : "stopped".equals(sv) ? "Çalışmıyor" : "Bilinmiyor").append('\n');
            sb.append("Soket (X0): ").append(yes(kv.get("socket"))).append('\n');
            sb.append("DISPLAY: ").append(kv.get("display")).append('\n');
            String cn = kv.get("conn");
            sb.append("Bağlantı: ").append("ok".equals(cn) ? "✓ Doğrulandı"
                    : "fail".equals(cn) ? "✗ Başarısız"
                    : "unknown".equals(cn) ? "Doğrulanamadı (xdpyinfo/xset/xrandr yok)"
                    : "- (sunucu çalışmıyor)").append('\n');
            String fm = kv.get("free_mb");
            sb.append("Boş alan: ").append(fm == null || fm.startsWith("-") ? "Bilinmiyor" : fm + " MB")
                    .append("\n\n");
        }
        if (d.ok()) {
            sb.append(appInstalled ? "✓ X11 hazır"
                    : "⚠ Paketler hazır ama Termux:X11 uygulaması kurulu değil.");
        } else {
            sb.append("✗ ").append(d.title).append('\n').append(d.detail);
        }
        return sb.toString();
    }

    private static void refreshLog(TextView tv, boolean detailed) {
        List<String> lines = LogManager.recent(detailed ? 60 : 20, detailed);
        if (lines.isEmpty()) { tv.setText("(henüz log yok)"); return; }
        StringBuilder sb = new StringBuilder();
        for (String s : lines) sb.append(s).append('\n');
        tv.setText(sb.toString());
    }
}
