package com.x7.desktop.backend;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Merkezi log: bellekte son 300 satır + dosya (256 KB'ı geçince döner). */
public final class LogManager {
    public enum Level { INFO, WARNING, ERROR, DEBUG }

    private static final int MAX_MEM = 300;
    private static final long MAX_FILE = 256 * 1024;
    private static final ArrayList<String> mem = new ArrayList<String>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private static File file;

    private LogManager() {}

    public static synchronized void init(Context c) {
        File dir = new File(c.getFilesDir(), "logs");
        dir.mkdirs();
        file = new File(dir, "x7.log");
    }

    public static synchronized void log(Level l, String tag, String msg) {
        String line = FMT.format(new Date()) + " [" + l + "] " + tag + ": " + msg;
        mem.add(line);
        while (mem.size() > MAX_MEM) mem.remove(0);
        writeFile(line);
    }

    public static void info(String tag, String msg) { log(Level.INFO, tag, msg); }
    public static void warn(String tag, String msg) { log(Level.WARNING, tag, msg); }
    public static void error(String tag, String msg) { log(Level.ERROR, tag, msg); }
    public static void debug(String tag, String msg) { log(Level.DEBUG, tag, msg); }

    /** Son n satır (eskiden yeniye). includeDebug=false ise DEBUG satırları gizlenir. */
    public static synchronized List<String> recent(int n, boolean includeDebug) {
        ArrayList<String> out = new ArrayList<String>();
        for (int i = mem.size() - 1; i >= 0 && out.size() < n; i--) {
            String s = mem.get(i);
            if (!includeDebug && s.contains("[DEBUG]")) continue;
            out.add(s);
        }
        Collections.reverse(out);
        return out;
    }

    /** Son gönderilen gerçek Termux komutunu döndürür. */
    public static synchronized String lastCommand() {
        for (int i = mem.size() - 1; i >= 0; i--) {
            String s = mem.get(i);
            int p = s.indexOf(" Komut: ");
            if (p >= 0) return s.substring(p + 1);
        }
        return "Henüz Termux'a komut gönderilmedi.";
    }

    private static void writeFile(String line) {
        if (file == null) return;
        try {
            if (file.length() > MAX_FILE) {
                File old = new File(file.getPath() + ".1");
                if (old.exists()) old.delete();
                file.renameTo(old);
            }
            FileWriter w = new FileWriter(file, true);
            try { w.write(line + "\n"); } finally { w.close(); }
        } catch (IOException e) {
            // Log yazılamıyorsa uygulamayı düşürme.
        }
    }
}
