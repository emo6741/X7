package com.x7.desktop.backend;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

/** Termux ve Termux:X11 kurulu mu? Gerçek PackageManager sorgusu, tahmin yok. */
public final class TermuxDetector {
    public static final String TERMUX = "com.termux";
    public static final String X11 = "com.termux.x11";

    public static final class Result {
        public final boolean installed;
        public final String version;   // kurulu değilse ""
        public final String installer; // bilinmiyorsa ""
        Result(boolean i, String v, String s) { installed = i; version = v; installer = s; }
    }

    private TermuxDetector() {}

    @SuppressWarnings("deprecation")
    public static Result check(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            String ver = pi.versionName == null ? "?" : pi.versionName;
            String inst = pm.getInstallerPackageName(pkg);
            return new Result(true, ver, inst == null ? "" : inst);
        } catch (PackageManager.NameNotFoundException e) {
            return new Result(false, "", "");
        } catch (Exception e) {
            return new Result(false, "", "");
        }
    }

    /** Eski/deneysel Termux sürümü Play Store'dan gelir. */
    public static boolean isPlayStoreBuild(Result r) {
        return r.installed && "com.android.vending".equals(r.installer);
    }

    /** Uygulamayı açar. Başarılıysa true. */
    public static boolean open(Context c, String pkg) {
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            c.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Tarayıcıda bağlantı açar (izin gerekmez). */
    public static boolean openUrl(Context c, String url) {
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
