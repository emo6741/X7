package com.x7.desktop.backend;

import android.content.Context;

/** Legacy source-compatibility facade. It only describes X7 internal runtime state; it never opens or controls external apps. */
public final class TermuxDetector {
    public static final String TERMUX="embedded-debian";
    public static final String X11="embedded-display";
    public static final class Result { public final boolean installed; public final String packageName; public final String version; public Result(boolean i,String p,String v){installed=i;packageName=p;version=v;} }
    private TermuxDetector(){}
    public static Result check(Context c,String what){ EmbeddedDebianRuntime r=new EmbeddedDebianRuntime(c); boolean ok=TERMUX.equals(what)?r.installed():r.installed(); return new Result(ok,what,"internal"); }
    public static boolean isPlayStoreBuild(Result r){return false;}
    public static boolean open(Context c,String what){return false;}
    public static boolean openUrl(Context c,String url){return false;}
}
