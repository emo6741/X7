package com.x7.desktop.theme;

import android.content.Context;
import com.x7.desktop.backend.CommandBuilder;
import com.x7.desktop.backend.CommandResult;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxRunner;
import java.util.HashMap;
import java.util.Map;

/**
 * Tema uygulama / geri alma / durum okuma. Gerçek iş Termux'taki x7-theme scriptinde yapılır;
 * burada yalnızca sıra ve sonuç yorumu vardır:
 *   scriptleri yaz -> tema dosyalarını kopyala -> paketleri kur (başarısızsa uyarı) -> x7-theme apply
 * x7-theme önce yedek alır, dosyaları yazar, doğrular; doğrulama başarısızsa eski ayarlara döner.
 */
public final class ThemeManager {
    public interface Listener { void onChanged(); }

    public enum Level { NONE, SUCCESS, WARNING, ERROR }

    private static final long SHORT_MS = 30000;
    private static final long PKG_MS = 15L * 60 * 1000;
    private static ThemeManager instance;

    private final Context app;
    private Listener listener;
    private boolean busy = false;
    private boolean refreshing = false;
    private String progress = "";
    private Level level = Level.NONE;
    private String resultText = "";
    private String details = "";
    private boolean backupExists = false;
    private String desktopState = "unknown";   // running | stopped | unknown
    private String filesState = "unknown";     // complete | missing | unknown
    private final Map<String, String> applied = new HashMap<String, String>(); // gtk, icons, cursor, xfwm, menu

    private ThemeManager(Context app) { this.app = app; }

    public static ThemeManager get(Context c) {
        if (instance == null) instance = new ThemeManager(c.getApplicationContext());
        return instance;
    }

    public void setListener(Listener l) { listener = l; }
    public boolean isBusy() { return busy; }
    public String getProgress() { return progress; }
    public Level getLevel() { return level; }
    public String getResultText() { return resultText; }
    public String getDetails() { return details; }
    public boolean hasBackup() { return backupExists; }
    public String getDesktopState() { return desktopState; }
    public Map<String, String> getApplied() { return applied; }

    private void changed() {
        Listener l = listener;
        if (l != null) l.onChanged();
    }

    private void result(Level lv, String text, String det) {
        level = lv; resultText = text; details = det == null ? "" : det;
    }

    private boolean ready() {
        return com.x7.desktop.backend.TermuxDetector.check(app,
                com.x7.desktop.backend.TermuxDetector.TERMUX).installed
                && TermuxRunner.hasPermission(app);
    }

    private boolean xfceSelected() {
        return "XFCE".equals(StateManager.load(app).desktop);
    }

    // ------------------------------------------------------------ durum
    /** Termux'tan gerçek tema durumunu okur (script yoksa tema uygulanmamıştır). */
    public void refresh(final String themeId) {
        if (busy || refreshing || !ready()) return;
        refreshing = true;
        runTheme(CommandBuilder.ThemeOp.STATUS, themeId, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                refreshing = false;
                StateManager st = StateManager.load(app);
                String newDesktop = "unknown";
                boolean newBackup = false;
                String t = st.themeApplied;
                if (r.ok) {
                    Map<String, String> kv = r.keyValues();
                    newDesktop = valueOr(kv.get("desktop"), "unknown");
                    newBackup = "yes".equals(kv.get("backup"));
                    t = valueOr(kv.get("theme"), "");
                }
                // x7-theme henüz Termux'a yazılmamışsa (r.ok=false) kayıtlı durum korunur.
                boolean differs = !newDesktop.equals(desktopState) || newBackup != backupExists
                        || !t.equals(st.themeApplied);
                desktopState = newDesktop;
                backupExists = newBackup;
                if (!t.equals(st.themeApplied)) { st.themeApplied = t; st.save(); }
                // Yalnızca değişiklik varsa arayüzü tazele: aksi halde sayfa yeniden çizilip
                // refresh tekrar tetiklenir ve sonsuz döngü olur.
                if (differs) changed();
            }
        });
    }

    // ------------------------------------------------------------ uygula
    public void apply(final String themeId) {
        if (busy) return;
        if (!xfceSelected()) {
            result(Level.ERROR, "Bu tema yalnızca XFCE için kullanılabilir.", "KDE Plasma seçiliyken XFCE tema ayarları uygulanmaz.");
            changed();
            return;
        }
        if (!ready()) {
            result(Level.ERROR, "Termux hazır değil (kurulu değil veya izin yok).", "");
            changed();
            return;
        }
        busy = true;
        result(Level.NONE, "", "");
        LogManager.info("THEME", "Tema uygulanıyor: " + themeId);
        step("Scriptler hazırlanıyor...");
        TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) { fail("Scriptler Termux'a yazılamadı", r); return; }
                step("Tema dosyaları kopyalanıyor...");
                runTheme(CommandBuilder.ThemeOp.FILES, themeId, SHORT_MS,
                        new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult r2) {
                        if (!r2.ok || !"ok".equals(r2.keyValues().get("files"))) {
                            fail("Tema dosyaları kopyalanamadı", r2); return;
                        }
                        step("Gerekli paketler kontrol ediliyor...");
                        runTheme(CommandBuilder.ThemeOp.PACKAGES, themeId, PKG_MS,
                                new TermuxRunner.Callback() {
                            @Override public void onResult(CommandResult r3) {
                                // Paket kurulamazsa tema yine uygulanır; script yedek menüyü seçer.
                                final String pkgWarn = r3.ok ? ""
                                        : "Başlat menüsü paketi kurulamadı (internet/depo?). "
                                          + "Yedek olarak XFCE'nin standart uygulama menüsü kullanıldı.";
                                if (!r3.ok) LogManager.warn("THEME", "Paket adımı başarısız: " + r3.error);
                                step("win7".equals(themeId)
                                        ? "Windows 7 kaynakları indiriliyor, çıkarılıyor ve tema uygulanıyor..."
                                        : "Tema uygulanıyor (yedek alınıyor)...");
                                runTheme(CommandBuilder.ThemeOp.APPLY, themeId, "win7".equals(themeId) ? PKG_MS : SHORT_MS,
                                        new TermuxRunner.Callback() {
                                    @Override public void onResult(CommandResult r4) { finishApply(themeId, r4, pkgWarn); }
                                });
                            }
                        });
                    }
                });
            }
        });
    }

    private void finishApply(String themeId, CommandResult r, String pkgWarn) {
        Map<String, String> kv = r.keyValues();
        String msg = valueOr(kv.get("msg"), r.error);
        if (r.ok && ("ok".equals(kv.get("applied")) || "already".equals(kv.get("applied")))) {
            applied.clear();
            for (String k : new String[]{"gtk", "icons", "cursor", "xfwm", "menu"}) {
                if (kv.get(k) != null) applied.put(k, kv.get(k));
            }
            StateManager st = StateManager.load(app);
            st.themeApplied = themeId;
            st.save();
            StringBuilder warn = new StringBuilder(pkgWarn);
            for (String line : r.stdout.split("\n")) {
                if (line.startsWith("warn=")) append(warn, line.substring(5));
                if (line.startsWith("warn_plugin=")) append(warn, "Panel eklentisi bulunamadı: " + line.substring(12));
            }
            LogManager.info("THEME", "Tema uygulandı: " + themeId);
            if (warn.length() > 0) result(Level.WARNING, msg, warn.toString());
            else result(Level.SUCCESS, msg, "");
        } else {
            LogManager.error("THEME", "Tema uygulanamadı (exit=" + r.exitCode + "): " + msg);
            result(Level.ERROR, explain(r.exitCode, msg), tail(r));
        }
        busy = false;
        progress = "";
        changed();
        refresh(themeId);
    }

    // ------------------------------------------------------------ geri al
    public void rollback(final String themeId) {
        if (busy) return;
        if (!xfceSelected()) {
            result(Level.ERROR, "Tema geri alma yalnızca XFCE için kullanılabilir.", "KDE Plasma seçiliyken XFCE tema ayarları değiştirilmez.");
            changed();
            return;
        }
        if (!ready()) {
            result(Level.ERROR, "Termux hazır değil (kurulu değil veya izin yok).", "");
            changed();
            return;
        }
        busy = true;
        result(Level.NONE, "", "");
        step("Önceki ayarlar geri yükleniyor...");
        runTheme(CommandBuilder.ThemeOp.ROLLBACK, themeId, SHORT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                String msg = valueOr(r.keyValues().get("msg"), r.error);
                if (r.ok) {
                    StateManager st = StateManager.load(app);
                    st.themeApplied = "";
                    st.save();
                    applied.clear();
                    LogManager.info("THEME", "Tema geri alındı");
                    result(Level.SUCCESS, msg, "");
                } else {
                    LogManager.error("THEME", "Geri alma başarısız: " + msg);
                    result(Level.ERROR, explain(r.exitCode, msg), tail(r));
                }
                busy = false;
                progress = "";
                changed();
                refresh(themeId);
            }
        });
    }

    // ------------------------------------------------------------ yardımcılar
    /** Komutu hazırlar; hazırlama hatası (bozuk theme.json vb.) çökme yerine hata sonucu olur. */
    private void runTheme(CommandBuilder.ThemeOp op, String id, long timeoutMs, TermuxRunner.Callback cb) {
        CommandBuilder.Spec spec;
        try {
            spec = CommandBuilder.theme(app, op, id);
        } catch (RuntimeException e) {
            LogManager.error("THEME", "Komut hazırlanamadı: " + e.getMessage());
            cb.onResult(CommandResult.failure("Komut hazırlanamadı: " + e.getMessage()));
            return;
        }
        TermuxRunner.run(app, spec, timeoutMs, cb);
    }

    private void step(String text) {
        progress = text;
        LogManager.info("THEME", text);
        changed();
    }

    private void fail(String what, CommandResult r) {
        LogManager.error("THEME", what + ": " + r.error);
        result(Level.ERROR, what + ".", tail(r));
        busy = false;
        progress = "";
        changed();
    }

    private static String explain(int exit, String msg) {
        if (exit == 22) return "Masaüstü çalışıyor. Önce masaüstünü durdur, sonra tekrar dene.";
        if (exit == 20) return "Tema eksik. " + msg;
        if (exit == 21) return msg; // script zaten "eski ayarlara dönüldü" der
        if (exit == 23) return "Geri alınacak bir yedek yok.";
        return msg.length() > 0 ? msg : "Tema işlemi başarısız.";
    }

    private static String tail(CommandResult r) {
        String t = r.stdout.trim();
        if (t.length() > 500) t = t.substring(t.length() - 500);
        return t;
    }

    private static void append(StringBuilder sb, String s) {
        if (sb.length() > 0) sb.append('\n');
        sb.append(s);
    }

    private static String valueOr(String v, String d) { return v == null ? d : v; }
}
