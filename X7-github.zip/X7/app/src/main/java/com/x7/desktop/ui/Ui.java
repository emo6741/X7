package com.x7.desktop.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Renkler (açık/koyu) ve küçük görünüm yardımcıları. Kütüphane yok. */
public final class Ui {
    public final Context ctx;
    public final boolean dark;
    public final int bg, card, text, sub, accent;
    private final float density;

    public Ui(Context c) {
        ctx = c;
        density = c.getResources().getDisplayMetrics().density;
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bg = dark ? 0xFF101418 : 0xFFF4F7FB;
        card = dark ? 0xFF1B2128 : 0xFFFFFFFF;
        text = dark ? 0xFFEAEFF5 : 0xFF1A1F26;
        sub = dark ? 0xFF9AA7B5 : 0xFF5B6673;
        accent = 0xFF1E6FD9;
    }

    public int dp(int v) { return Math.round(v * density); }

    public TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public LinearLayout column() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        return l;
    }

    /** Yuvarlatılmış kart oluşturup parent'a ekler. */
    public LinearLayout addCard(LinearLayout parent) {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(card);
        bgd.setCornerRadius(dp(16));
        c.setBackground(bgd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    /** "Etiket .... değer" satırı. */
    public void addRow(LinearLayout card, String label, String value) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView l = text(label, 15, text, false);
        TextView v = text(value, 15, sub, false);
        v.setGravity(Gravity.END);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        card.addView(row);
    }

    public ScrollView scroll(LinearLayout content) {
        ScrollView sv = new ScrollView(ctx);
        sv.setFillViewport(true);
        sv.addView(content);
        return sv;
    }

    /** Dokunma hedefi büyük (48dp+) buton. */
    public TextView addButton(LinearLayout parent, String label, boolean primary,
                              android.view.View.OnClickListener l) {
        TextView b = text(label, 15, primary ? 0xFFFFFFFF : accent, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(48));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        if (primary) g.setColor(accent); else { g.setColor(0x00000000); g.setStroke(dp(1), accent); }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(b, lp);
        return b;
    }
}
