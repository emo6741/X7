package com.x7.desktop.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.animation.ValueAnimator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Renkler (açık/koyu) ve küçük görünüm yardımcıları. Kütüphane yok. */
public final class Ui {
    public final Context ctx;
    public final boolean dark;
    public final int bg, card, text, sub, accent, accent2, stroke;
    public final int green = 0xFF22B573, red = 0xFFE5484D, orange = 0xFFF5A623, purple = 0xFF6D5CE7, teal = 0xFF1FA48C;
    private final float density;

    public Ui(Context c) {
        ctx = c;
        density = c.getResources().getDisplayMetrics().density;
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bg = dark ? 0xFF07111B : 0xFFF6F9FD;
        card = dark ? 0xFF0E1A27 : 0xFFFFFFFF;
        stroke = dark ? 0xFF223247 : 0xFFE4EAF2;
        text = dark ? 0xFFEAEFF5 : 0xFF161B22;
        sub = dark ? 0xFF8B98A7 : 0xFF5B6673;
        accent = 0xFF1688FF;
        accent2 = 0xFF315CFF;
    }

    public int dp(int v) { return Math.round(v * density); }

    public TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0f, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public LinearLayout column() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(18), dp(14), dp(16));
        return l;
    }

    /** Yuvarlatılmış kart oluşturup parent'a ekler. */
    public LinearLayout addCard(LinearLayout parent) {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(card);
        bgd.setCornerRadius(dp(14));
        bgd.setStroke(dp(1), stroke);
        c.setBackground(bgd);
        if (!dark) c.setElevation(dp(1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        parent.addView(c, lp);
        return c;
    }

    /** "Etiket .... değer" satırı. ✓ yeşil, ✗ kırmızı, ⚠ turuncu görünür. */
    public void addRow(LinearLayout card, String label, String value) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, dp(8));
        int vc = sub;
        if (value != null) {
            if (value.startsWith("✓")) vc = 0xFF2EAD6B;
            else if (value.startsWith("✗")) vc = 0xFFE5484D;
            else if (value.startsWith("⚠")) vc = 0xFFF5A623;
        }
        TextView l = text(label, 15, text, false);
        TextView v = text(value, 15, vc, true);
        v.setGravity(Gravity.END);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        card.addView(row);
    }

    public ScrollView scroll(LinearLayout content) {
        ScrollView sv = new ScrollView(ctx);
        sv.setFillViewport(true);
        sv.addView(content);
        return sv;
    }

    /** Dokunma hedefi büyük (52dp) buton, dokunma efekti var. */
    public TextView addButton(LinearLayout parent, String label, boolean primary,
                              android.view.View.OnClickListener l) {
        TextView b = text(label, 15, primary ? 0xFFFFFFFF : accent, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(52));
        b.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable g;
        if (primary) {
            g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{accent, accent2});
        } else {
            g = new GradientDrawable();
            g.setColor(0x00000000);
            g.setStroke(dp(1), accent);
        }
        g.setCornerRadius(dp(12));
        int rip = primary ? 0x55FFFFFF : ((accent & 0x00FFFFFF) | 0x33000000);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(rip), g, null));
        b.setOnClickListener(l);
        pressable(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(b, lp);
        return b;
    }

    // ------------------------------------------------------------------ Yeni görünüm yardımcıları

    /** a ile b'yi karıştırır (opak sonuç). t=0 -> a, t=1 -> b. */
    public static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Kart zemininin üzerine hafif renk tonu. */
    public int tintFill(int base) { return mix(card, base, dark ? 0.12f : 0.07f); }

    public int tintStroke(int base) { return mix(stroke, base, dark ? 0.35f : 0.30f); }

    public GradientDrawable rounded(int fill, int radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    /** Renkli tonlu kart (ana sayfa kartları). */
    public LinearLayout addTintCard(LinearLayout parent, int base) {
        LinearLayout c = addCard(parent);
        c.setBackground(rounded(tintFill(base), 18, tintStroke(base)));
        return c;
    }

    /** Dokununca hafifçe küçülüp yaylanarak geri gelir. Tıklamayı engellemez. */
    @SuppressWarnings("ClickableViewAccessibility")
    public void pressable(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(1f).scaleY(1f).setDuration(220)
                                .setInterpolator(new OvershootInterpolator(2.2f)).start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /** Sayfa açılırken alt öğeler sırayla yumuşakça belirir. */
    public void animateIn(ViewGroup col) {
        int n = col.getChildCount();
        for (int i = 0; i < n; i++) {
            View ch = col.getChildAt(i);
            ch.setAlpha(0f);
            ch.setTranslationY(dp(20));
            ch.animate().alpha(1f).translationY(0f)
                    .setStartDelay(Math.min(i, 10) * 55L).setDuration(380)
                    .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        }
    }

    /** Renkli yuvarlak köşeli ikon karosu. */
    public FrameLayout tile(IconView.Type type, int c1, int c2, int sizeDp, int iconDp) {
        FrameLayout f = new FrameLayout(ctx);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(Math.round(sizeDp * 0.28f)));
        f.setBackground(g);
        IconView ic = new IconView(ctx, type, 0xFFFFFFFF);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER);
        f.addView(ic, lp);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    /** Dolu oran çubuğu: iki ağırlıklı çocuk (dolu + boş). */
    public LinearLayout bar(int color) {
        LinearLayout track = new LinearLayout(ctx);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setWeightSum(1f);
        track.setBackground(rounded(mix(card, sub, 0.18f), 4, 0));
        View fill = new View(ctx);
        fill.setBackground(rounded(color, 4, 0));
        View rest = new View(ctx);
        track.addView(fill, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0f));
        track.addView(rest, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return track;
    }

    public void setBar(final LinearLayout bar, float fraction, boolean animate) {
        final float f = Math.max(0.02f, Math.min(1f, fraction));
        final View fill = bar.getChildAt(0);
        final View rest = bar.getChildAt(1);
        final LinearLayout.LayoutParams fl = (LinearLayout.LayoutParams) fill.getLayoutParams();
        final LinearLayout.LayoutParams rl = (LinearLayout.LayoutParams) rest.getLayoutParams();
        if (!animate) {
            fl.weight = f; rl.weight = 1f - f;
            bar.requestLayout();
            return;
        }
        final float from = fl.weight;
        ValueAnimator va = ValueAnimator.ofFloat(from, f);
        va.setDuration(800);
        va.setStartDelay(250);
        va.setInterpolator(new DecelerateInterpolator(1.8f));
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float v = (Float) a.getAnimatedValue();
                fl.weight = v; rl.weight = 1f - v;
                bar.requestLayout();
            }
        });
        va.start();
    }
}
