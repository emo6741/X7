package com.x7.desktop.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Renkler (açık/koyu) ve küçük görünüm yardımcıları. Kütüphane yok. */
public final class Ui {
    public final Context ctx;
    public final boolean dark;
    public final int bg, card, text, sub, accent, accent2, stroke;
    private final float density;

    public Ui(Context c) {
        ctx = c;
        density = c.getResources().getDisplayMetrics().density;
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bg = dark ? 0xFF0D1117 : 0xFFF3F6FA;
        card = dark ? 0xFF161B22 : 0xFFFFFFFF;
        stroke = dark ? 0xFF262D36 : 0xFFE3E8EF;
        text = dark ? 0xFFEAEFF5 : 0xFF161B22;
        sub = dark ? 0xFF8B98A7 : 0xFF5B6673;
        accent = 0xFF2F7DF6;
        accent2 = 0xFF22B8CF;
    }

    public int dp(int v) { return Math.round(v * density); }

    public TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0f, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public LinearLayout column() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(24), dp(18), dp(20));
        return l;
    }

    /** Yuvarlatılmış kart oluşturup parent'a ekler. */
    public LinearLayout addCard(LinearLayout parent) {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(card);
        bgd.setCornerRadius(dp(20));
        bgd.setStroke(dp(1), stroke);
        c.setBackground(bgd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(14);
        parent.addView(c, lp);
        return c;
    }

    /** "Etiket .... değer" satırı. ✓ yeşil, ✗ kırmızı, ⚠ turuncu görünür. */
    public void addRow(LinearLayout card, String label, String value) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, dp(8));
        int vc = sub;
        if (value != null) {
            if (value.startsWith("✓")) vc = 0xFF2EAD6B;
            else if (value.startsWith("✗")) vc = 0xFFE5484D;
            else if (value.startsWith("⚠")) vc = 0xFFF5A623;
        }
        TextView l = text(label, 15, text, false);
        TextView v = text(value, 15, vc, true);
        v.setGravity(Gravity.END);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        card.addView(row);
    }

    public ScrollView scroll(LinearLayout content) {
        ScrollView sv = new ScrollView(ctx);
        sv.setFillViewport(true);
        sv.addView(content);
        return sv;
    }

    /** Dokunma hedefi büyük (52dp) buton, dokunma efekti var. */
    public TextView addButton(LinearLayout parent, String label, boolean primary,
                              android.view.View.OnClickListener l) {
        TextView b = text(label, 15, primary ? 0xFFFFFFFF : accent, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(52));
        b.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable g;
        if (primary) {
            g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{accent, accent2});
        } else {
            g = new GradientDrawable();
            g.setColor(0x00000000);
            g.setStroke(dp(1), accent);
        }
        g.setCornerRadius(dp(14));
        int rip = primary ? 0x55FFFFFF : ((accent & 0x00FFFFFF) | 0x33000000);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(rip), g, null));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(b, lp);
        return b;
    }
}
