package com.x7.desktop.ui;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.util.SystemInfo;

/** Ana sayfa. Termux/X11 durumu gerçek; XFCE henüz kontrol edilmez (Aşama 5). */
public final class HomePage {
    private HomePage() {}

    // Güvenilir kaynaklar: resmi F-Droid girdisi ve resmi GitHub sürümleri.
    private static final String TERMUX_FDROID = "https://f-droid.org/packages/com.termux/";
    private static final String TERMUX_GITHUB = "https://github.com/termux/termux-app/releases";
    private static final String X11_GITHUB = "https://github.com/termux/termux-x11/releases";

    public static View build(final Ui ui) {
        final TermuxDetector.Result tx = TermuxDetector.check(ui.ctx, TermuxDetector.TERMUX);
        final TermuxDetector.Result x11 = TermuxDetector.check(ui.ctx, TermuxDetector.X11);

        LinearLayout col = ui.column();
        col.addView(ui.text("X7", 40, ui.accent, true));
        col.addView(ui.text("Linux Desktop Manager", 16, ui.sub, false));
        col.addView(new View(ui.ctx), new LinearLayout.LayoutParams(1, ui.dp(16)));

        // --- Durum kartı ---
        LinearLayout status = ui.addCard(col);
        status.addView(ui.text("Sistem Durumu", 18, ui.text, true));
        ui.addRow(status, "Termux", tx.installed ? "✓ Bulundu (v" + tx.version + ")" : "✗ Bulunamadı");
        ui.addRow(status, "Termux:X11", x11.installed ? "✓ Bulundu (v" + x11.version + ")" : "✗ Bulunamadı");
        final StateManager st = StateManager.load(ui.ctx);
        final boolean installed = st.installState == StateManager.InstallState.COMPLETED;
        String xfce = installed ? "✓ Kurulum tamamlandı"
                : st.installState == StateManager.InstallState.NOT_STARTED ? "✗ Kurulmadı" : "⚠ Yarım kaldı";
        ui.addRow(status, "XFCE", xfce);
        final DesktopController dc = DesktopController.get(ui.ctx);
        ui.addRow(status, "Tema", st.themeApplied.length() > 0 ? "✓ " + st.themeApplied + " uygulandı" : "Uygulanmadı");
        ui.addRow(status, "Masaüstü", DesktopControls.statusText(dc));
        ui.addRow(status, "Genel",
                (tx.installed && x11.installed)
                        ? (installed ? "Hazır" : "Masaüstü henüz kurulmadı")
                        : "Eksik bileşen var");

        if (!installed && ui.ctx instanceof MainActivity) {
            LinearLayout k = ui.addCard(col);
            k.addView(ui.text("Kurulum", 17, ui.text, true));
            k.addView(ui.text("XFCE masaüstü henüz kurulu değil. Kurulum sihirbazı Desktop sekmesinde.",
                    14, ui.sub, false));
            ui.addButton(k, "Kurulum Sihirbazını Aç", true, new View.OnClickListener() {
                @Override public void onClick(View v) { ((MainActivity) ui.ctx).showTab(1); }
            });
        }

        // --- Termux yok ---
        if (!tx.installed) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("Termux gerekli", 17, ui.text, true));
            c.addView(ui.text("X7'nin Linux masaüstünü kurabilmesi için Termux gereklidir. "
                    + "Termux'u yalnızca F-Droid veya resmi GitHub sürümlerinden indir; "
                    + "rastgele APK sitelerini kullanma.", 14, ui.sub, false));
            ui.addButton(c, "Termux'u İndir (F-Droid)", true, link(ui, TERMUX_FDROID));
            ui.addButton(c, "Termux GitHub Sürümleri", false, link(ui, TERMUX_GITHUB));
        } else if (TermuxDetector.isPlayStoreBuild(tx)) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("⚠ Termux Play Store sürümü", 17, ui.text, true));
            c.addView(ui.text("Termux'un Play Store sürümü eski kalmış olabilir; paket kurulumunda "
                    + "sorun çıkarabilir. F-Droid veya GitHub sürümü önerilir.", 14, ui.sub, false));
            ui.addButton(c, "Termux'u İndir (F-Droid)", false, link(ui, TERMUX_FDROID));
        }

        // --- Termux:X11 yok ---
        if (!x11.installed) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("Termux:X11 gerekli", 17, ui.text, true));
            c.addView(ui.text("Termux:X11, Linux grafik arayüzlerinin Android ekranında "
                    + "görüntülenmesini sağlar. Önerilen görüntü yöntemidir.", 14, ui.sub, false));
            ui.addButton(c, "Termux:X11 Sürümleri (GitHub)", true, link(ui, X11_GITHUB));
        }

        // --- Uygulamaları aç ---
        if (tx.installed || x11.installed) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("Kısayollar", 17, ui.text, true));
            if (tx.installed) {
                ui.addButton(c, "Termux'u Aç", false, launch(ui, TermuxDetector.TERMUX));
            }
            if (x11.installed) {
                ui.addButton(c, "Termux:X11'i Aç", false, launch(ui, TermuxDetector.X11));
            }
        }

        // --- Cihaz ---
        LinearLayout sys = ui.addCard(col);
        sys.addView(ui.text("Cihaz", 18, ui.text, true));
        ui.addRow(sys, "Sistem", SystemInfo.android());
        ui.addRow(sys, "CPU", SystemInfo.cpu());
        ui.addRow(sys, "RAM", SystemInfo.ram(ui.ctx));
        ui.addRow(sys, "Depolama", SystemInfo.storage());

        // --- Başlat / Durdur ---
        if (ui.ctx instanceof MainActivity) {
            DesktopControls.add(ui, (MainActivity) ui.ctx, col, false);
        }

        return ui.scroll(col);
    }

    private static View.OnClickListener link(final Ui ui, final String url) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!TermuxDetector.openUrl(ui.ctx, url)) {
                    Toast.makeText(ui.ctx, "✗ Bağlantı açılamadı", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    private static View.OnClickListener launch(final Ui ui, final String pkg) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!TermuxDetector.open(ui.ctx, pkg)) {
                    Toast.makeText(ui.ctx, "✗ Uygulama açılamadı", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }
}
