package com.x7.desktop.ui;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.ConnectionDoctor;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.TermuxRunner;
import com.x7.desktop.util.SystemInfo;

/**
 * Ana sayfa (v0.13). Tüm değerler gerçektir: kurulu uygulamalar PackageManager'dan,
 * RAM/depolama sistemden, masaüstü durumu DesktopController'dan okunur. CPU kullanım yüzdesi
 * Android'de okunamadığı için gösterilmez; yalnızca çekirdek sayısı gösterilir.
 */
public final class HomePage {
    private HomePage() {}

    /** MainActivity yalnızca sekme açılışında true yapar; arka plan yenilemelerinde animasyon tekrarlanmaz. */
    public static boolean intro = false;

    private static final String TERMUX_FDROID = "https://f-droid.org/packages/com.termux/";
    private static final String TERMUX_GITHUB = "https://github.com/termux/termux-app/releases";

    public static View build(final Ui ui) {
        final Context ctx = ui.ctx;
        final boolean playIntro = intro;
        final boolean wide = ctx.getResources().getConfiguration().screenWidthDp >= 600;
        final MainActivity act = (ctx instanceof MainActivity) ? (MainActivity) ctx : null;

        final TermuxDetector.Result tx = TermuxDetector.check(ctx, TermuxDetector.TERMUX);
        final TermuxDetector.Result x11 = TermuxDetector.check(ctx, TermuxDetector.X11);
        final StateManager st = StateManager.load(ctx);
        final DesktopController dc = DesktopController.get(ctx);
        final boolean perm = TermuxRunner.hasPermission(ctx);
        final boolean installed = st.installState == StateManager.InstallState.COMPLETED;
        final boolean needX11 = !"VNC".equals(st.display);
        final DesktopController.Status ds = dc.getStatus();
        if (act != null) {
            dc.setListener(new DesktopController.Listener() {
                @Override public void onChanged() { act.refresh(); }
            });
        }

        LinearLayout col = ui.column();
        addReferenceHeader(ui, col, act);
        addReferenceSystemInfo(ui, col, st);
        addReferenceConnection(ui, col, tx, x11, perm, st, installed);
        addStartArea(ui, col, act, dc, ds, installed);
        addNavCards(ui, col, act, st);
        addShortcuts(ui, col, tx, x11);
        return ui.scroll(col);
    }

    // ------------------------------------------------------------------ Reference UI

    private static void addReferenceHeader(final Ui ui, LinearLayout col, final MainActivity act) {
        LinearLayout h = new LinearLayout(ui.ctx);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = ui.text("X7", 48, ui.accent, true);
        logo.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC));
        logo.setLetterSpacing(-0.08f);
        logo.setIncludeFontPadding(false);
        h.addView(logo, new LinearLayout.LayoutParams(ui.dp(92), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout mid = new LinearLayout(ui.ctx);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_VERTICAL);
        mid.addView(ui.text("v" + versionName(ui.ctx), 13, ui.text, true));
        mid.addView(ui.text("Android'da Linux Deneyimi", 12, ui.sub, false));
        h.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView state = ui.text("● Bağlı", 12, ui.green, true);
        h.addView(state, new LinearLayout.LayoutParams(ui.dp(54), ViewGroup.LayoutParams.WRAP_CONTENT));
        IconView gear = new IconView(ui.ctx, IconView.Type.GEAR, ui.text);
        gear.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (act != null) act.showTab(5); }});
        h.addView(gear, new LinearLayout.LayoutParams(ui.dp(28), ui.dp(28)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = ui.dp(8);
        col.addView(h, lp);
    }

    private static void addReferenceSystemInfo(Ui ui, LinearLayout col, StateManager st) {
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Sistem Bilgileri", 15, ui.text, true));
        addMetric(ui, c, IconView.Type.RAM, "RAM", SystemInfo.ramTotal(ui.ctx), SystemInfo.ramAvail(ui.ctx), ui.accent);
        addMetric(ui, c, IconView.Type.DISK, "Depolama", SystemInfo.storageTotal(), SystemInfo.freeBytes(), ui.accent);
        int cpu = SystemInfo.cpuUsagePercent();
        addMetricPercent(ui, c, IconView.Type.CPU, "CPU", cpu, ui.accent);
        LinearLayout row = new LinearLayout(ui.ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        IconView ic = new IconView(ui.ctx, IconView.Type.TERMINAL, ui.sub);
        row.addView(ic, new LinearLayout.LayoutParams(ui.dp(25),ui.dp(25)));
        row.addView(ui.text("Android", 13, ui.text, false), new LinearLayout.LayoutParams(0,-2,1));
        row.addView(ui.text(android.os.Build.VERSION.RELEASE + "", 12, ui.sub, true));
        c.addView(row);
    }

    private static void addMetric(Ui ui, LinearLayout c, IconView.Type type, String label, long total, long avail, int color) {
        long used = (total > 0 && avail >= 0) ? total - avail : -1;
        int pct = (total > 0 && used >= 0) ? (int)Math.round(100.0 * used / total) : -1;
        addMetricPercent(ui,c,type,label,pct,color,(used>0?SystemInfo.fmt(used):"Bilinmiyor") + (total>0?" / "+SystemInfo.fmt(total):""));
    }
    private static void addMetricPercent(Ui ui, LinearLayout c, IconView.Type type, String label, int pct, int color) {
        addMetricPercent(ui,c,type,label,pct,color,pct<0?"Bilinmiyor":pct+"%");
    }
    private static void addMetricPercent(Ui ui, LinearLayout c, IconView.Type type, String label, int pct, int color, String value) {
        LinearLayout row = new LinearLayout(ui.ctx); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        IconView ic = new IconView(ui.ctx, type, ui.sub);
        row.addView(ic, new LinearLayout.LayoutParams(ui.dp(25),ui.dp(25)));
        LinearLayout mid = new LinearLayout(ui.ctx); mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(ui.dp(8),0,ui.dp(8),0);
        mid.addView(ui.text(label,13,ui.text,false));
        LinearLayout bar = ui.bar(color); bar.setMinimumHeight(ui.dp(5));
        ui.setBar(bar, pct < 0 ? 0.02f : pct/100f, false);
        mid.addView(bar,new LinearLayout.LayoutParams(-1,ui.dp(5)));
        row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(ui.text(value,11,ui.sub,true));
        c.addView(row); 
        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)row.getLayoutParams(); lp.topMargin=ui.dp(6); row.setLayoutParams(lp);
    }

    private static void addReferenceConnection(Ui ui, LinearLayout col, TermuxDetector.Result tx,
                                               TermuxDetector.Result x11, boolean perm, StateManager st, boolean installed) {
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Bağlantı Durumu", 15, ui.text, true));
        addDotRow(ui,c,"Termux",tx.installed && perm);
        addDotRow(ui,c,"X11", "VNC".equals(st.display) || x11.installed);
    }
    private static void addDotRow(Ui ui, LinearLayout c, String label, boolean ok) {
        LinearLayout r=new LinearLayout(ui.ctx); r.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot=ui.text("●",14,ok?ui.green:ui.red,true); r.addView(dot,new LinearLayout.LayoutParams(ui.dp(22),-2));
        r.addView(ui.text(label+": "+(ok?"Çalışıyor":"Eksik"),12,ui.sub,false)); c.addView(r);
    }

    // ------------------------------------------------------------------ Başlık

    private static void addHeader(final Ui ui, LinearLayout col, final MainActivity act) {
        LinearLayout h = new LinearLayout(ui.ctx);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);

        TextView logo = ui.text("X7", 46, ui.accent, true);
        logo.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC));
        logo.setLetterSpacing(-0.06f);
        logo.setIncludeFontPadding(false);
        h.addView(logo);

        LinearLayout mid = new LinearLayout(ui.ctx);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(ui.dp(14), 0, ui.dp(8), 0);
        mid.addView(ui.text("X7", 22, ui.text, true));
        mid.addView(ui.text("Linux Desktop Manager", 15, ui.sub, false));
        TextView tag = ui.text("Android cihazınızda güçlü bir Linux masaüstü deneyimi.", 12, ui.sub, false);
        tag.setPadding(0, ui.dp(2), 0, 0);
        mid.addView(tag);
        h.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView chip = ui.text("v" + versionName(ui.ctx), 12, ui.accent, true);
        chip.setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4));
        chip.setBackground(ui.rounded(Ui.mix(ui.card, ui.accent, 0.13f), 14, 0));
        h.addView(chip);

        IconView info = new IconView(ui.ctx, IconView.Type.INFO, ui.accent);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(ui.dp(26), ui.dp(26));
        il.leftMargin = ui.dp(10);
        info.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(ui.ctx)
                        .setTitle("X7 Linux Desktop Manager")
                        .setMessage("Sürüm: v" + versionName(ui.ctx)
                                + "\nPaket: " + ui.ctx.getPackageName()
                                + "\n" + SystemInfo.android()
                                + "\nCihaz: " + Build.MANUFACTURER + " " + Build.MODEL
                                + "\nMimari: " + SystemInfo.abi())
                        .setPositiveButton("Tamam", null).show();
            }
        });
        ui.pressable(info);
        h.addView(info, il);

        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hl.bottomMargin = ui.dp(18);
        col.addView(h, hl);
    }

    private static String versionName(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionName == null ? "?" : pi.versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    // ------------------------------------------------------------------ Sistem durumu

    private static void addStatusCard(Ui ui, LinearLayout col, boolean wide,
                                      TermuxDetector.Result tx, TermuxDetector.Result x11,
                                      StateManager st, boolean perm, boolean installed,
                                      boolean needX11, DesktopController.Status ds, boolean playIntro) {
        int base;
        String sub, pill;
        boolean good = false;
        if (!tx.installed) { base = ui.red; sub = "Termux bulunamadı. Önce Termux'u kur."; pill = "Eksik"; }
        else if (needX11 && !x11.installed) { base = ui.orange; sub = "Termux:X11 uygulaması bulunamadı."; pill = "Eksik"; }
        else if (!perm) { base = ui.orange; sub = "Termux komut izni verilmedi."; pill = "İzin gerekli"; }
        else if (!installed) { base = ui.orange; sub = "Masaüstü henüz kurulmadı."; pill = "Kurulum gerekli"; }
        else if (ds == DesktopController.Status.RUNNING) { base = ui.green; sub = "Masaüstü şu an çalışıyor."; pill = "Çalışıyor"; good = true; }
        else if (ds == DesktopController.Status.ERROR) { base = ui.red; sub = "Masaüstünde bir hata var."; pill = "Hata"; }
        else { base = ui.green; sub = "Tüm bileşenler kurulu ve hazır."; pill = "Sistem hazır"; good = true; }
        boolean ok = good || base == ui.green;

        LinearLayout card = ui.addTintCard(col, base);
        card.setPadding(0, 0, 0, 0);
        card.setClipToOutline(true);

        LinearLayout head = new LinearLayout(ui.ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(14));

        FrameLayout circle = new FrameLayout(ui.ctx);
        GradientDrawable cg = new GradientDrawable();
        cg.setShape(GradientDrawable.OVAL);
        cg.setColor(base);
        circle.setBackground(cg);
        IconView ci = new IconView(ui.ctx, ok ? IconView.Type.CHECK : IconView.Type.WARN, 0xFFFFFFFF);
        circle.addView(ci, new FrameLayout.LayoutParams(ui.dp(28), ui.dp(28), Gravity.CENTER));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ui.dp(52), ui.dp(52));
        cl.rightMargin = ui.dp(14);
        head.addView(circle, cl);
        if (playIntro) {
            circle.setScaleX(0f);
            circle.setScaleY(0f);
            circle.animate().scaleX(1f).scaleY(1f).setStartDelay(300).setDuration(520)
                    .setInterpolator(new OvershootInterpolator(2.6f)).start();
        }

        LinearLayout tcol = new LinearLayout(ui.ctx);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.addView(ui.text("Sistem Durumu", 19, ui.text, true));
        tcol.addView(ui.text(sub, 13, ui.sub, false));
        head.addView(tcol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView p = ui.text((ok ? "✓ " : "⚠ ") + pill, 12, base, true);
        p.setPadding(ui.dp(12), ui.dp(7), ui.dp(12), ui.dp(7));
        p.setBackground(ui.rounded(Ui.mix(ui.card, base, 0.16f), 18, 0));
        head.addView(p);
        card.addView(head);

        View line = new View(ui.ctx);
        line.setBackgroundColor(ui.tintStroke(base));
        card.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(1)));

        // Bileşenler
        LinearLayout row = new LinearLayout(ui.ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(ui.dp(8), ui.dp(14), ui.dp(8), ui.dp(14));
        row.setBackgroundColor(ui.card);

        // Termux
        String tS; int tC;
        if (!tx.installed) { tS = "Yok ✗"; tC = ui.red; }
        else if (!perm) { tS = "İzin yok"; tC = ui.orange; }
        else { tS = "Hazır ✓"; tC = ui.green; }
        row.addView(statusTile(ui, wide, ui.tile(IconView.Type.TERMINAL, 0xFF263041, 0xFF0B0F17, 44, 24),
                "Termux", tS, tC), cellLp());
        row.addView(divider(ui));

        // Masaüstü (XFCE / KDE)
        String dName = st.desktop.startsWith("KDE") ? "KDE" : "XFCE";
        String dS; int dC;
        if (installed) { dS = "Kurulu ✓"; dC = ui.green; }
        else if (st.installState == StateManager.InstallState.NOT_STARTED) { dS = "Kurulmadı"; dC = ui.orange; }
        else if (st.installState == StateManager.InstallState.FAILED) { dS = "Başarısız ✗"; dC = ui.red; }
        else { dS = "Yarım kaldı"; dC = ui.orange; }
        row.addView(statusTile(ui, wide, ui.tile(IconView.Type.DESKTOP, 0xFF3C8DFF, 0xFF1E6FEA, 44, 24),
                dName, dS, dC), cellLp());
        row.addView(divider(ui));

        // X11
        String xS; int xC;
        if (x11.installed) { xS = "Hazır ✓"; xC = ui.green; }
        else if (needX11) { xS = "Yok ✗"; xC = ui.red; }
        else { xS = "Gerekmiyor"; xC = ui.sub; }
        row.addView(statusTile(ui, wide, ui.tile(IconView.Type.XMARK, 0xFF263041, 0xFF0B0F17, 44, 22),
                "X11", xS, xC), cellLp());
        row.addView(divider(ui));

        // VNC (yalnızca seçili görüntü yöntemi bilgisi; kurulu olduğu iddia edilmez)
        boolean vnc = "VNC".equals(st.display);
        row.addView(statusTile(ui, wide, textTile(ui, "VNC", 0xFF3C8DFF, 0xFF1E6FEA, 44),
                "VNC", vnc ? "Seçili" : "Kullanılmıyor", vnc ? ui.accent : ui.sub), cellLp());

        card.addView(row);
    }

    private static LinearLayout.LayoutParams cellLp() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private static View divider(Ui ui) {
        View d = new View(ui.ctx);
        d.setBackgroundColor(ui.stroke);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ui.dp(1), ui.dp(40));
        lp.gravity = Gravity.CENTER_VERTICAL;
        d.setLayoutParams(lp);
        return d;
    }

    private static View textTile(Ui ui, String label, int c1, int c2, int sizeDp) {
        FrameLayout f = new FrameLayout(ui.ctx);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(ui.dp(Math.round(sizeDp * 0.28f)));
        f.setBackground(g);
        TextView t = ui.text(label, 12, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        f.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(ui.dp(sizeDp), ui.dp(sizeDp)));
        return f;
    }

    private static View statusTile(Ui ui, boolean wide, View tile, String name, String status, int color) {
        LinearLayout t = new LinearLayout(ui.ctx);
        t.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        t.setGravity(wide ? (Gravity.CENTER_VERTICAL | Gravity.START) : Gravity.CENTER_HORIZONTAL);
        t.setPadding(ui.dp(4), 0, ui.dp(4), 0);
        LinearLayout.LayoutParams tl = (LinearLayout.LayoutParams) tile.getLayoutParams();
        if (wide) tl.rightMargin = ui.dp(10); else tl.bottomMargin = ui.dp(8);
        t.addView(tile);
        LinearLayout txt = new LinearLayout(ui.ctx);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setGravity(wide ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        TextView n = ui.text(name, 15, ui.text, true);
        TextView s = ui.text(status, 12, color, true);
        s.setPadding(0, ui.dp(2), 0, 0);
        txt.addView(n);
        txt.addView(s);
        t.addView(txt);
        return t;
    }

    // ------------------------------------------------------------------ Eksik bileşen kartları

    private static void addMissingCards(Ui ui, LinearLayout col, TermuxDetector.Result tx,
                                        TermuxDetector.Result x11, boolean needX11) {
        if (!tx.installed) {
            LinearLayout c = ui.addTintCard(col, ui.red);
            c.addView(ui.text("Termux gerekli", 17, ui.text, true));
            c.addView(ui.text("X7'nin Linux masaüstünü kurabilmesi için Termux gereklidir. "
                    + "Termux'u yalnızca F-Droid veya resmi GitHub sürümlerinden indir; "
                    + "rastgele APK sitelerini kullanma.", 14, ui.sub, false));
            ui.addButton(c, "Termux'u İndir (F-Droid)", true, link(ui, TERMUX_FDROID));
            ui.addButton(c, "Termux GitHub Sürümleri", false, link(ui, TERMUX_GITHUB));
        } else if (TermuxDetector.isPlayStoreBuild(tx)) {
            LinearLayout c = ui.addTintCard(col, ui.orange);
            c.addView(ui.text("⚠ Termux Play Store sürümü", 17, ui.text, true));
            c.addView(ui.text("Termux'un Play Store sürümü eski kalmış olabilir; komut servisi ve paket "
                    + "kurulumunda sorun çıkarabilir. F-Droid veya GitHub sürümü önerilir.", 14, ui.sub, false));
            ui.addButton(c, "Termux'u İndir (F-Droid)", false, link(ui, TERMUX_FDROID));
        }
        if (needX11 && !x11.installed) {
            LinearLayout c = ui.addTintCard(col, ui.orange);
            c.addView(ui.text("Termux:X11 gerekli", 17, ui.text, true));
            c.addView(ui.text("Termux:X11, Linux masaüstünü Android ekranında gösterir. Kurulum sihirbazı "
                    + "Termux'a 'termux-x11-nightly' paketini kurar; bu yüzden APK'nın da NIGHTLY sürümünü "
                    + "kur (sürümler uyuşmazsa X11 bağlanmaz).", 14, ui.sub, false));
            ui.addButton(c, "Termux:X11 Nightly APK (GitHub)", true, link(ui, ConnectionDoctor.X11_NIGHTLY_URL));
        }
    }

    // ------------------------------------------------------------------ Başlat alanı

    private static void addStartArea(Ui ui, LinearLayout col, final MainActivity act,
                                     final DesktopController dc, DesktopController.Status ds,
                                     boolean installed) {
        if (!installed) {
            View b = bigButton(ui, "Kurulumu Başlat", "Önce Linux masaüstünü kur.",
                    IconView.Type.PLAY, 0xFF3C8DFF, 0xFF1E6FEA, false, new View.OnClickListener() {
                        @Override public void onClick(View v) { if (act != null) act.showTab(3); }
                    });
            col.addView(b, bigLp(ui));
            return;
        }
        if (ds == DesktopController.Status.STOPPED || ds == DesktopController.Status.UNKNOWN) {
            View b = bigButton(ui, "Masaüstünü Başlat", "Seçtiğiniz ayarlarla Linux masaüstünüzü başlatın.",
                    IconView.Type.PLAY, 0xFF3C8DFF, 0xFF1E6FEA, false, new View.OnClickListener() {
                        @Override public void onClick(View v) { dc.start(); }
                    });
            pulse(b);
            col.addView(b, bigLp(ui));
            return;
        }
        if (ds == DesktopController.Status.STARTING || ds == DesktopController.Status.REPAIRING
                || ds == DesktopController.Status.STOPPING) {
            String t = ds == DesktopController.Status.STARTING ? "Başlatılıyor..."
                    : ds == DesktopController.Status.REPAIRING ? "Onarılıyor..." : "Durduruluyor...";
            String p = dc.getProgress();
            View b = bigButton(ui, t, p.length() > 0 ? p : "Lütfen bekleyin.",
                    IconView.Type.GEAR, 0xFF5A8FD8, 0xFF3F6FB8, true, null);
            col.addView(b, bigLp(ui));
            return;
        }
        // RUNNING / ERROR: ortak kontrol düğmeleri
        if (act != null) {
            int base = ds == DesktopController.Status.RUNNING ? ui.green : ui.red;
            LinearLayout c = ui.addTintCard(col, base);
            if (ds == DesktopController.Status.RUNNING) {
                c.addView(ui.text("Masaüstü çalışıyor", 17, ui.text, true));
            }
            DesktopControls.add(ui, act, c, false);
        }
    }

    private static LinearLayout.LayoutParams bigLp(Ui ui) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = ui.dp(14);
        return lp;
    }

    private static LinearLayout bigButton(Ui ui, String title, String subtitle, IconView.Type icon,
                                          int c1, int c2, boolean spin, View.OnClickListener click) {
        LinearLayout b = new LinearLayout(ui.ctx);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        b.setMinimumHeight(ui.dp(80));
        b.setPadding(ui.dp(20), ui.dp(14), ui.dp(20), ui.dp(14));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(ui.dp(18));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
        if (!ui.dark) b.setElevation(ui.dp(4));

        IconView ic = new IconView(ui.ctx, icon, 0xFFFFFFFF);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(ui.dp(32), ui.dp(32));
        il.rightMargin = ui.dp(14);
        b.addView(ic, il);
        if (spin) {
            final ObjectAnimator a = ObjectAnimator.ofFloat(ic, View.ROTATION, 0f, 360f);
            a.setDuration(1800);
            a.setRepeatCount(ObjectAnimator.INFINITE);
            a.setInterpolator(new LinearInterpolator());
            ic.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override public void onViewAttachedToWindow(View v) { a.start(); }
                @Override public void onViewDetachedFromWindow(View v) { a.cancel(); }
            });
        }

        LinearLayout t = new LinearLayout(ui.ctx);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(ui.text(title, 19, 0xFFFFFFFF, true));
        t.addView(ui.text(subtitle, 13, 0xDDFFFFFF, false));
        b.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (click != null) b.setOnClickListener(click);
        return b;
    }

    /** Hazır durumdaki ana düğmeye yavaş nefes alma animasyonu. Ekrandan kalkınca durur. */
    private static void pulse(View v) {
        final ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.018f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.018f));
        a.setDuration(1300);
        a.setRepeatCount(ObjectAnimator.INFINITE);
        a.setRepeatMode(ObjectAnimator.REVERSE);
        v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View x) { a.start(); }
            @Override public void onViewDetachedFromWindow(View x) { a.cancel(); }
        });
    }

    // ------------------------------------------------------------------ Masaüstü / Görüntü / Tema kartları

    private static void addNavCards(Ui ui, LinearLayout col, final MainActivity act, StateManager st) {
        boolean kde = st.desktop.startsWith("KDE");
        navCard(ui, col, ui.accent, IconView.Type.DESKTOP, 0xFF3C8DFF, 0xFF1E6FEA,
                "Masaüstü", kde ? "KDE Plasma" : "XFCE",
                kde ? "Zengin özellikli, modern masaüstü ortamı." : "Hafif, hızlı ve kararlı bir masaüstü ortamı.",
                new View.OnClickListener() {
                    @Override public void onClick(View v) { if (act != null) act.showTab(1); }
                });

        boolean vnc = "VNC".equals(st.display);
        navCard(ui, col, ui.purple, IconView.Type.DESKTOP, 0xFF8B7BFF, 0xFF5B49D6,
                "Görüntü", vnc ? "VNC" : "Termux:X11",
                vnc ? "VNC üzerinden görüntüleme (127.0.0.1:5901)." : "Yerel X11 görüntüleme (daha iyi performans).",
                new View.OnClickListener() {
                    @Override public void onClick(View v) { if (act != null) act.showTab(5); }
                });

        String id = st.themeApplied;
        String name, desc;
        if (id.length() == 0) { name = st.theme; desc = "Henüz uygulanmadı. Temalar sekmesinden uygulayabilirsin."; }
        else if ("win7".equals(id)) { name = "Windows 7 Inspired"; desc = "Klasik ve tanıdık bir görünüm."; }
        else if ("win10".equals(id)) { name = "Windows 10 Inspired"; desc = "Modern ve sade bir görünüm."; }
        else if ("pure-xfce".equals(id)) { name = "Pure XFCE"; desc = "XFCE'nin varsayılan görünümü."; }
        else { name = id; desc = "Uygulanmış tema."; }
        navCard(ui, col, ui.teal, IconView.Type.PALETTE, 0xFF2BC4A8, 0xFF16957F,
                "Tema", name, desc, new View.OnClickListener() {
                    @Override public void onClick(View v) { if (act != null) act.showTab(2); }
                });
    }

    private static void navCard(Ui ui, LinearLayout col, int tint, IconView.Type icon, int c1, int c2,
                                String label, String value, String desc, View.OnClickListener click) {
        LinearLayout c = ui.addTintCard(col, tint);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
        int rip = (tint & 0x00FFFFFF) | 0x33000000;
        c.setBackground(new RippleDrawable(ColorStateList.valueOf(rip),
                ui.rounded(ui.tintFill(tint), 18, ui.tintStroke(tint)), null));

        View tile = ui.tile(icon, c1, c2, 56, 28);
        ((LinearLayout.LayoutParams) tile.getLayoutParams()).rightMargin = ui.dp(14);
        c.addView(tile);

        LinearLayout t = new LinearLayout(ui.ctx);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(ui.text(label, 13, ui.sub, true));
        t.addView(ui.text(value, 20, ui.text, true));
        t.addView(ui.text(desc, 13, ui.sub, false));
        c.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        c.addView(new IconView(ui.ctx, IconView.Type.CHEVRON, ui.sub), new LinearLayout.LayoutParams(ui.dp(20), ui.dp(20)));
        c.setOnClickListener(click);
        ui.pressable(c);
    }

    // ------------------------------------------------------------------ Sistem kaynakları

    private static void addResources(final Ui ui, LinearLayout col, boolean playIntro) {
        final LinearLayout card = ui.addCard(col);

        LinearLayout head = new LinearLayout(ui.ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        IconView hi = new IconView(ui.ctx, IconView.Type.CHART, ui.accent);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(ui.dp(24), ui.dp(24));
        hl.rightMargin = ui.dp(10);
        head.addView(hi, hl);
        head.addView(ui.text("Sistem Kaynakları", 17, ui.text, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView dev = ui.text("Cihaz: " + Build.MODEL, 11, ui.sub, false);
        dev.setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4));
        dev.setBackground(ui.rounded(Ui.mix(ui.card, ui.sub, 0.12f), 12, 0));
        head.addView(dev);
        card.addView(head);

        LinearLayout row = new LinearLayout(ui.ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, ui.dp(16), 0, 0);

        // CPU: kullanım yüzdesi okunamaz; yalnızca çekirdek sayısı ve mimari (gerçek).
        int cores = Runtime.getRuntime().availableProcessors();
        TextView cpuVal = ui.text(cores + " çekirdek", 17, ui.text, true);
        TextView cpuSub = ui.text(SystemInfo.abi(), 12, ui.sub, false);
        row.addView(resColumn(ui, IconView.Type.CPU, ui.accent, "CPU", cpuVal, cpuSub), cellLp());
        row.addView(divider(ui));

        final TextView ramVal = ui.text("", 17, ui.text, true);
        final LinearLayout ramBar = ui.bar(ui.green);
        row.addView(resColumn(ui, IconView.Type.RAM, ui.green, "RAM", ramVal, ramBar), cellLp());
        row.addView(divider(ui));

        final TextView stoVal = ui.text("", 17, ui.text, true);
        final LinearLayout stoBar = ui.bar(ui.purple);
        row.addView(resColumn(ui, IconView.Type.DISK, ui.purple, "Depolama", stoVal, stoBar), cellLp());
        card.addView(row);

        final Runnable update = new Runnable() {
            @Override public void run() { updateRes(ui, ramVal, ramBar, stoVal, stoBar, false); }
        };
        updateRes(ui, ramVal, ramBar, stoVal, stoBar, playIntro);

        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable tick = new Runnable() {
            @Override public void run() { update.run(); h.postDelayed(this, 3000); }
        };
        card.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { h.postDelayed(tick, 3000); }
            @Override public void onViewDetachedFromWindow(View v) { h.removeCallbacks(tick); }
        });
    }

    private static void updateRes(Ui ui, TextView ramVal, LinearLayout ramBar,
                                  TextView stoVal, LinearLayout stoBar, boolean animate) {
        long rt = SystemInfo.ramTotal(ui.ctx), ra = SystemInfo.ramAvail(ui.ctx);
        if (rt > 0 && ra >= 0) {
            ramVal.setText(pair(ui, rt - ra, rt));
            ui.setBar(ramBar, (rt - ra) / (float) rt, animate);
        } else {
            ramVal.setText("Bilinmiyor");
        }
        long st = SystemInfo.storageTotal(), sa = SystemInfo.freeBytes();
        if (st > 0 && sa >= 0) {
            stoVal.setText(pair(ui, st - sa, st));
            ui.setBar(stoBar, (st - sa) / (float) st, animate);
        } else {
            stoVal.setText("Bilinmiyor");
        }
    }

    private static CharSequence pair(Ui ui, long used, long total) {
        SpannableStringBuilder sb = new SpannableStringBuilder(SystemInfo.fmt(used));
        int a = sb.length();
        sb.append(" / ").append(SystemInfo.fmt(total));
        sb.setSpan(new RelativeSizeSpan(0.66f), a, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan(ui.sub), a, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private static LinearLayout resColumn(Ui ui, IconView.Type icon, int color, String label,
                                          TextView value, View bottom) {
        LinearLayout c = new LinearLayout(ui.ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(ui.dp(12), 0, ui.dp(12), 0);
        LinearLayout l = new LinearLayout(ui.ctx);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(ui.dp(18), ui.dp(18));
        il.rightMargin = ui.dp(6);
        l.addView(new IconView(ui.ctx, icon, color), il);
        l.addView(ui.text(label, 13, ui.sub, true));
        c.addView(l);
        value.setPadding(0, ui.dp(6), 0, ui.dp(8));
        c.addView(value);
        if (bottom instanceof LinearLayout) {
            c.addView(bottom, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8)));
        } else {
            c.addView(bottom);
        }
        return c;
    }

    // ------------------------------------------------------------------ Kısayollar ve ipucu

    private static void addShortcuts(Ui ui, LinearLayout col, TermuxDetector.Result tx, TermuxDetector.Result x11) {
        if (!tx.installed && !x11.installed) return;
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text("Kısayollar", 17, ui.text, true));
        if (tx.installed) ui.addButton(c, "Termux'u Aç", false, launch(ui, TermuxDetector.TERMUX));
        if (x11.installed) ui.addButton(c, "Termux:X11'i Aç", false, launch(ui, TermuxDetector.X11));
    }

    private static void addTip(final Ui ui, LinearLayout col, StateManager st) {
        final SharedPreferences sp = ui.ctx.getSharedPreferences("x7_ui", Context.MODE_PRIVATE);
        if (sp.getBoolean("tip_off", false)) return;
        final LinearLayout c = ui.addTintCard(col, ui.accent);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(ui.dp(14), ui.dp(12), ui.dp(10), ui.dp(12));

        FrameLayout bulb = new FrameLayout(ui.ctx);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Ui.mix(ui.card, ui.accent, 0.14f));
        bulb.setBackground(bg);
        bulb.addView(new IconView(ui.ctx, IconView.Type.BULB, ui.accent),
                new FrameLayout.LayoutParams(ui.dp(24), ui.dp(24), Gravity.CENTER));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(ui.dp(44), ui.dp(44));
        bl.rightMargin = ui.dp(12);
        c.addView(bulb, bl);

        LinearLayout t = new LinearLayout(ui.ctx);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(ui.text("İpucu", 15, ui.accent, true));
        boolean vnc = "VNC".equals(st.display);
        t.addView(ui.text(vnc ? "Daha iyi performans için VNC yerine Termux:X11 görüntü yöntemini dene."
                : "En iyi performans için XFCE masaüstü ve Termux:X11 kullanmanız önerilir.", 13, ui.sub, false));
        c.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IconView x = new IconView(ui.ctx, IconView.Type.CLOSE, ui.sub);
        x.setPadding(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4));
        x.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putBoolean("tip_off", true).apply();
                c.animate().alpha(0f).translationX(ui.dp(60)).setDuration(240)
                        .withEndAction(new Runnable() {
                            @Override public void run() { c.setVisibility(View.GONE); }
                        }).start();
            }
        });
        c.addView(x, new LinearLayout.LayoutParams(ui.dp(32), ui.dp(32)));
    }

    // ------------------------------------------------------------------ Ortak

    private static View.OnClickListener link(final Ui ui, final String url) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!TermuxDetector.openUrl(ui.ctx, url)) {
                    Toast.makeText(ui.ctx, "✗ Bağlantı açılamadı", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    private static View.OnClickListener launch(final Ui ui, final String pkg) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!TermuxDetector.open(ui.ctx, pkg)) {
                    Toast.makeText(ui.ctx, "✗ Uygulama açılamadı", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }
}
