package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.theme.ThemeInfo;
import com.x7.desktop.theme.ThemeManager;
import java.util.List;
import java.util.Map;

/**
 * Themes sekmesi. Aşama 12 ile XFCE için gerçek, metadata tabanlı birden çok tema desteklenir.
 * KDE seçiliyken XFCE temaları gösterilmez ve uygulanamaz.
 */
public final class ThemesPage {
    private ThemesPage() {}


    public static View build(final Ui ui, final MainActivity act) {
        final ThemeManager tm = ThemeManager.get(act);
        tm.setListener(new ThemeManager.Listener() {
            @Override public void onChanged() { act.refresh(); }
        });

        final StateManager st = StateManager.load(act);
        final boolean installed = st.installState == StateManager.InstallState.COMPLETED;
        final boolean xfceSelected = "XFCE".equals(st.desktop);
        final DesktopController dc = DesktopController.get(act);
        final boolean running = dc.getStatus() == DesktopController.Status.RUNNING
                || "running".equals(tm.getDesktopState());

        LinearLayout col = ui.column();
        col.addView(ui.text("Themes", 28, ui.text, true));
        col.addView(ui.text("Tema, XFCE ayar dosyalarına yazılır; uygulamadan önce mevcut ayarlar "
                + "yedeklenir ve istediğinde geri alınır.", 14, ui.sub, false));
        col.addView(new View(act), new LinearLayout.LayoutParams(1, ui.dp(12)));

        List<ThemeInfo> allThemes = ThemeInfo.loadAll(act);
        List<ThemeInfo> themes = new java.util.ArrayList<ThemeInfo>();
        for (ThemeInfo t : allThemes) {
            if (xfceSelected && "xfce".equalsIgnoreCase(t.desktop)) themes.add(t);
        }
        if (!xfceSelected) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("KDE Plasma seçili", 17, ui.text, true));
            c.addView(ui.text("Bu aşamadaki gelişmiş temalar XFCE içindir. KDE seçiliyken XFCE tema ayarlarının yanlışlıkla uygulanmasına izin verilmez.", 14, ui.sub, false));
        } else if (themes.isEmpty()) {
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text("✗ Tema bulunamadı", 17, ui.text, true));
            c.addView(ui.text("assets/themes altında geçerli bir theme.json yok.", 14, ui.sub, false));
        }

        for (final ThemeInfo t : themes) {
            final boolean isApplied = t.id.equals(st.themeApplied);
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text(t.name, 20, ui.text, true));
            TextView d = ui.text(t.description, 14, ui.sub, false);
            d.setPadding(0, ui.dp(4), 0, ui.dp(8));
            c.addView(d);
            ui.addRow(c, "Masaüstü", t.desktop.toUpperCase());
            ui.addRow(c, "GTK teması", t.gtkTheme);
            if (t.packages.length() > 0) ui.addRow(c, "Ek paket", t.packages);
            ui.addRow(c, "Durum", isApplied ? "✓ Uygulandı" : "Uygulanmadı");

            Map<String, String> ap = tm.getApplied();
            if (isApplied && !ap.isEmpty()) {
                if (ap.get("menu") != null) ui.addRow(c, "Başlat menüsü", ap.get("menu"));
                if (ap.get("icons") != null) ui.addRow(c, "Simgeler", ap.get("icons"));
                if (ap.get("cursor") != null) ui.addRow(c, "İmleç", ap.get("cursor"));
                if (ap.get("xfwm") != null) ui.addRow(c, "Pencere çerçevesi", ap.get("xfwm"));
            }

            if (tm.isBusy()) {
                TextView b = ui.addButton(c, "⟳ " + tm.getProgress(), true, null);
                b.setEnabled(false);
                b.setAlpha(0.45f);
            } else if (!xfceSelected) {
                note(ui, c, "Bu tema XFCE içindir; KDE Plasma seçiliyken uygulanamaz.");
            } else if (!installed) {
                note(ui, c, "Önce Desktop sekmesinden XFCE kurulumunu tamamla.");
            } else if (running) {
                note(ui, c, "Masaüstü çalışıyor. Çalışan oturum ayar dosyalarını geri yazabileceği için "
                        + "tema yalnızca masaüstü durdurulmuşken uygulanır.");
                ui.addButton(c, "⏹ Masaüstünü Durdur", false, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        dc.stop(false);
                        act.showTab(0);
                    }
                });
            } else {
                ui.addButton(c, isApplied ? "↻ Yeniden Uygula" : "Temayı Uygula", true,
                        new View.OnClickListener() {
                    @Override public void onClick(View v) { confirmApply(ui, act, tm, t); }
                });
                if (isApplied || tm.hasBackup()) {
                    ui.addButton(c, "↩ Geri Al", false, new View.OnClickListener() {
                        @Override public void onClick(View v) { confirmRollback(act, tm, t); }
                    });
                }
            }
            if (isApplied && !tm.isBusy() && !running) {
                ui.addButton(c, "🚀 Masaüstünü Başlat", false, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        dc.start();
                        act.showTab(0);
                    }
                });
            }
        }

        addResult(ui, col, tm);

        if (xfceSelected) {
            LinearLayout info = ui.addCard(col);
            info.addView(ui.text("Aşama 12", 17, ui.text, true));
            info.addView(ui.text("Windows 7, Windows 10 Inspired ve Pure XFCE temaları gerçek XFCE ayar dosyaları üzerinden uygulanır.", 14, ui.sub, false));
        }

        if (xfceSelected) tm.refresh(themes.isEmpty() ? "win7" : themes.get(0).id);
        return ui.scroll(col);
    }

    private static void note(Ui ui, LinearLayout c, String s) {
        TextView n = ui.text(s, 13, ui.sub, false);
        n.setPadding(0, ui.dp(8), 0, 0);
        c.addView(n);
    }

    private static void addResult(Ui ui, LinearLayout col, ThemeManager tm) {
        if (tm.getLevel() == ThemeManager.Level.NONE || tm.getResultText().length() == 0) return;
        LinearLayout c = ui.addCard(col);
        String icon = tm.getLevel() == ThemeManager.Level.SUCCESS ? "✓ "
                : tm.getLevel() == ThemeManager.Level.WARNING ? "⚠ " : "✗ ";
        c.addView(ui.text(icon + tm.getResultText(), 15, ui.text, true));
        if (tm.getDetails().length() > 0) {
            TextView d = ui.text(tm.getDetails(), 13, ui.sub, false);
            d.setPadding(0, ui.dp(6), 0, 0);
            c.addView(d);
        }
    }

    private static void confirmApply(Ui ui, MainActivity act, final ThemeManager tm, final ThemeInfo t) {
        new AlertDialog.Builder(act)
                .setTitle(t.name + " uygulansın mı?")
                .setMessage("Panel, pencere ve masaüstü arka planı ayarları değişir. Mevcut ayarlar "
                        + "yedeklenir; sorun olursa \"Geri Al\" ile dönebilirsin.\n\n"
                        + "Gerekirse Başlat menüsü paketi indirilir (internet gerekir).")
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Uygula", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { tm.apply(t.id); }
                })
                .show();
    }

    private static void confirmRollback(MainActivity act, final ThemeManager tm, final ThemeInfo t) {
        new AlertDialog.Builder(act)
                .setTitle("Temayı geri al")
                .setMessage("Temadan önceki XFCE ayarları geri yüklenir.")
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Geri Al", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { tm.rollback(t.id); }
                })
                .show();
    }
}
