package com.x7.desktop.backend;

import android.content.Context;
import java.util.concurrent.atomic.AtomicInteger;

/** Compatibility facade: eski X7 çağrı yüzeyi korunur, fakat hiçbir Dahili Debian IPC kullanılmaz. */
public final class TermuxRunner {
    public static final String PERMISSION = "android.permission.INTERNET";
    private static final AtomicInteger SEQ = new AtomicInteger();
    public interface Callback { void onResult(CommandResult r); }
    private TermuxRunner() {}

    public static boolean hasPermission(Context c) { return true; }

    public static void run(Context ctx, CommandBuilder.Id id, Callback cb) { run(ctx,id,15000,cb); }
    public static void run(Context ctx, CommandBuilder.Id id, long timeoutMs, Callback cb) {
        run(ctx, CommandBuilder.forId(ctx,id), timeoutMs, cb);
    }
    public static void run(Context ctx, CommandBuilder.Spec spec, long timeoutMs, Callback cb) {
        final EmbeddedDebianRuntime rt = new EmbeddedDebianRuntime(ctx);
        final String cmd = translate(spec);
        if (cmd == null) { cb.onResult(CommandResult.failure("Yerel runtime komutu eşlenemedi: "+spec.label)); return; }
        rt.shell(cmd, (ok,out) -> {
            int rc=ok?0:1;
            cb.onResult(CommandResult.of(rc, out == null ? "" : out, ok ? "" : (out == null ? "Yerel runtime hatası" : out), ok ? "" : (out == null ? "Yerel runtime hatası" : out)));
        });
    }
    private static String translate(CommandBuilder.Spec s) {
        String l=s.label == null ? "" : s.label;
        if(l.contains("Ortam kontrolü")||l.contains("Dahili Debian kontrolü")) return "echo state=ok; echo runtime=embedded-debian; echo architecture=$(dpkg --print-architecture 2>/dev/null || uname -m)";
        if(l.contains("İnternet kontrolü")) return "curl -fsSI --max-time 8 https://deb.debian.org >/dev/null && echo net=ok || echo net=fail";
        if(l.contains("Paket deposu")) return "apt-get update";
        if(l.contains("XFCE kurulumu")) return "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y xfce4 xfce4-terminal dbus-x11 procps";
        if(l.contains("KDE Plasma kurulumu")) return "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y kde-plasma-desktop dbus-x11 procps";
        if(l.contains("Dahili Debian:X11 paketi")) return "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y x11-utils xterm";
        if(l.contains("Kurulum doğrulama")) return "echo state=ok; command -v startxfce4 >/dev/null && echo xfce=yes || echo xfce=no; command -v startplasma-x11 >/dev/null && echo kde=yes || echo kde=no; command -v vncserver >/dev/null && echo vncserver=yes || echo vncserver=no; echo termux-x11=no";
        if(l.contains("Scriptleri kur")) return "echo scripts=embedded-runtime";
        if(l.contains("Masaüstü durumu")) return "if pgrep -f xfce4-session >/dev/null 2>&1; then echo state=running; echo desktop=XFCE; else echo state=stopped; echo desktop=stopped; fi";
        if(l.contains("Masaüstünü durdur")||l.contains("Zorla durdur")) return "pkill -TERM -f xfce4-session 2>/dev/null || true; pkill -TERM -f plasmashell 2>/dev/null || true; echo state=stopped; echo msg=Masaüstü durduruldu";
        if(l.contains("Masaüstünü başlat")) {
            boolean kde=s.args!=null && java.util.Arrays.toString(s.args).contains("KDE");
            String bin = kde ? "startplasma-x11" : "startxfce4";
            return "if ! command -v " + bin + " >/dev/null 2>&1; then echo state=stopped; echo msg=" + bin + " bulunamadı; exit 3; fi; "
                    + "export DISPLAY=${DISPLAY:-:0}; " + bin + " >/tmp/x7-desktop.log 2>&1 & "
                    + "sleep 1; if pgrep -f '" + bin + "' >/dev/null 2>&1; then echo state=running; "
                    + "else echo state=stopped; echo msg=Masaüstü süreci başlatılamadı; tail -n 20 /tmp/x7-desktop.log 2>/dev/null; exit 4; fi; "
                    + "echo desktop="+(kde?"KDE Plasma":"XFCE")+"; echo msg=Oturum başlatıldı";
        }
        if(l.contains("X11 kontrolü")) return "echo backend=embedded; echo server=internal; echo state=ok; echo display=internal";
        if(l.contains("X11 temizliği")||l.contains("X11 onarımı")) return "pkill -TERM -f xfce4-session 2>/dev/null || true; echo state=ok; echo msg=Yerel X11 runtime temizlendi";
        if(l.contains("XFCE kontrolü")) return "command -v startxfce4 >/dev/null && echo state=ok || { echo state=issues; exit 3; }";
        if(l.contains("XFCE onarımı")) return "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y xfce4 xfce4-terminal dbus-x11 procps";
        if(l.contains("KDE kontrolü")) return "command -v startplasma-x11 >/dev/null && echo state=ok || { echo state=issues; exit 3; }";
        if(l.contains("KDE onarımı")) return "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y kde-plasma-desktop dbus-x11 procps";
        if(l.contains("Paket kontrolü")) return "dpkg --audit; echo state=ok";
        if(l.contains("Paket onarımı")) return "apt-get -f install -y";
        if(l.contains("Başlangıç scriptleri")) return "echo state=ok; echo runtime=embedded";
        if(l.contains("VNC")) return "echo state=unsupported; echo msg=VNC yerine uygulama içi görüntüleme katmanı kullanılacak";
        if(l.contains("Tema")) return "echo state=ok; echo theme=embedded";
        return "echo state=ok; echo runtime=embedded-debian";
    }
}
