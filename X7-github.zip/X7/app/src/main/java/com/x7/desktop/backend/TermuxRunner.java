package com.x7.desktop.backend;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/**
 * Termux'un resmi RUN_COMMAND servisi ile komut çalıştırır.
 * Gereken: (1) com.termux.permission.RUN_COMMAND izninin Android Ayarlar'ından verilmesi,
 * (2) Termux'ta ~/.termux/termux.properties içinde allow-external-apps=true.
 * Sonuç bir PendingIntent ile geri gelir; 15 sn içinde gelmezse zaman aşımı olur.
 */
public final class TermuxRunner {
    public static final String PERMISSION = "com.termux.permission.RUN_COMMAND";
    private static final long TIMEOUT_MS = 15000;
    private static int counter = 0;

    public interface Callback { void onResult(CommandResult r); }

    private TermuxRunner() {}

    public static boolean hasPermission(Context c) {
        return c.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    public static void run(Context ctx, CommandBuilder.Id id, final Callback cb) {
        run(ctx, id, TIMEOUT_MS, cb);
    }

    public static void run(Context ctx, CommandBuilder.Id id, final long timeoutMs, final Callback cb) {
        CommandBuilder.Spec spec;
        try {
            spec = CommandBuilder.build(ctx.getApplicationContext(), id);
        } catch (RuntimeException e) {
            fail(cb, "Komut hazırlanamadı: " + e.getMessage());
            return;
        }
        run(ctx, spec, timeoutMs, cb);
    }

    /** Hazır bir Spec'i çalıştırır (parametreli komutlar, ör. tema işlemleri). */
    public static void run(Context ctx, CommandBuilder.Spec spec, final long timeoutMs, final Callback cb) {
        final Context app = ctx.getApplicationContext();
        LogManager.info("CMD", "Çalıştırılıyor: " + spec.label);

        if (!TermuxDetector.check(app, TermuxDetector.TERMUX).installed) {
            fail(cb, "Termux kurulu değil.");
            return;
        }
        if (!hasPermission(app)) {
            fail(cb, "RUN_COMMAND izni verilmedi.");
            return;
        }

        counter++;
        final String action = "com.x7.desktop.RESULT." + counter;
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] done = {false};

        final BroadcastReceiver r = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent in) {
                if (done[0]) return;
                done[0] = true;
                h.removeCallbacksAndMessages(null);
                try { app.unregisterReceiver(this); } catch (Exception ignored) {}
                Bundle b = in.getBundleExtra("result");
                if (b == null) { fail(cb, "Termux sonuç döndürmedi."); return; }
                CommandResult res = CommandResult.of(
                        b.getInt("exitCode", -1),
                        b.getString("stdout", ""),
                        b.getString("stderr", ""),
                        b.getString("errmsg", ""));
                LogManager.log(res.ok ? LogManager.Level.INFO : LogManager.Level.ERROR,
                        "CMD", "Bitti: exit=" + res.exitCode + (res.ok ? "" : " " + res.error));
                if (res.stderr.length() > 0) LogManager.debug("CMD", "stderr: " + res.stderr);
                cb.onResult(res);
            }
        };

        IntentFilter f = new IntentFilter(action);
        if (Build.VERSION.SDK_INT >= 33) {
            app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            app.registerReceiver(r, f);
        }

        h.postDelayed(new Runnable() {
            @Override public void run() {
                if (done[0]) return;
                done[0] = true;
                try { app.unregisterReceiver(r); } catch (Exception ignored) {}
                fail(cb, "Termux yanıt vermedi. 'allow-external-apps=true' ayarını ve izni kontrol et, "
                        + "Termux'u tamamen kapatıp yeniden aç.");
            }
        }, timeoutMs);

        try {
            Intent ri = new Intent(action);
            ri.setPackage(app.getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pi = PendingIntent.getBroadcast(app, counter, ri, flags);

            Intent i = new Intent();
            i.setClassName("com.termux", "com.termux.app.RunCommandService");
            i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH", spec.path);
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", spec.args);
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", spec.workdir);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            i.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi);
            app.startService(i);
        } catch (Exception e) {
            if (!done[0]) {
                done[0] = true;
                h.removeCallbacksAndMessages(null);
                try { app.unregisterReceiver(r); } catch (Exception ignored) {}
                fail(cb, "Komut gönderilemedi: " + e.getClass().getSimpleName()
                        + (e.getMessage() == null ? "" : " - " + e.getMessage()));
            }
        }
    }

    private static void fail(Callback cb, String msg) {
        LogManager.error("CMD", msg);
        cb.onResult(CommandResult.failure(msg));
    }
}
