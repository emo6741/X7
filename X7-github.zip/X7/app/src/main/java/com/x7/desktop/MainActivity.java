package com.x7.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.RepairManager;
import com.x7.desktop.installer.Installer;
import com.x7.desktop.ui.HomePage;
import com.x7.desktop.ui.InfoPage;
import com.x7.desktop.ui.InstallPage;
import com.x7.desktop.ui.RepairPage;
import com.x7.desktop.ui.SettingsPage;
import com.x7.desktop.ui.ThemesPage;
import com.x7.desktop.theme.ThemeManager;
import com.x7.desktop.ui.Ui;

/** Ana iskelet + alt navigasyon. */
public class MainActivity extends Activity {

    private static final String[] TABS =
            {"Home", "Desktop", "Themes", "Packages", "Repair", "Settings"};
    private static final String[] DESC = {
            "", "",
            "",
            "Kurulu, önerilen ve ek paketler burada yönetilecek.",
            "",
            ""};
    private static final String[] STAGE = {"", "", "", "Aşama 5 devamı", "", ""};

    private Ui ui;
    private FrameLayout content;
    private final TextView[] nav = new TextView[TABS.length];
    private int current = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogManager.init(this);
        LogManager.info("APP", "X7 başlatıldı");
        ui = new Ui(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ui.bg);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(ui.card);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = ui.text(TABS[i], 11, ui.sub, true);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(idx); }
            });
            nav[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, ui.dp(56), 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        select(current);
        DesktopController.get(this).refresh(); // gerçek durumu Termux'tan oku
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Installer.get(this).setListener(null);
        ThemeManager.get(this).setListener(null);
        RepairManager.get(this).setListener(null);
        DesktopController.get(this).setListener(null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        boolean granted = results.length > 0 && results[0] == 0;
        LogManager.info("PERM", "RUN_COMMAND izni: " + (granted ? "verildi" : "reddedildi"));
        select(current);
    }

    /** Arka plan işleri bitince Desktop sekmesini tazeler. */
    public void refresh() {
        if (isFinishing() || isDestroyed()) return;
        if (current <= 2 || current == 4) select(current);
    }

    public void showTab(int i) { select(i); }

    private void select(int i) {
        current = i;
        content.removeAllViews();
        View page;
        if (i == 0) page = HomePage.build(ui);
        else if (i == 1) page = InstallPage.build(ui, this);
        else if (i == 2) page = ThemesPage.build(ui, this);
        else if (i == 4) page = RepairPage.build(ui, this);
        else if (i == 5) page = SettingsPage.build(ui, this);
        else page = InfoPage.build(ui, TABS[i], DESC[i], STAGE[i]);
        content.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        for (int k = 0; k < nav.length; k++) {
            nav[k].setTextColor(k == i ? ui.accent : ui.sub);
        }
    }
}
