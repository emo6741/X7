package com.x7.desktop;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.RepairManager;
import com.x7.desktop.installer.Installer;
import com.x7.desktop.ui.HomePage;
import com.x7.desktop.ui.IconView;
import com.x7.desktop.ui.InfoPage;
import com.x7.desktop.ui.InstallPage;
import com.x7.desktop.ui.RepairPage;
import com.x7.desktop.ui.SettingsPage;
import com.x7.desktop.ui.ThemesPage;
import com.x7.desktop.theme.ThemeManager;
import com.x7.desktop.ui.Ui;

/** Ana iskelet: tam ekran (durum çubuğu + gezinme tuşları gizli), animasyonlu alt navigasyon. */
public class MainActivity extends Activity {

    // İç sekme numaraları sabit kalır (showTab çağrıları bunlara dayanır).
    private static final String[] TABS =
            {"Home", "Desktop", "Themes", "Packages", "Repair", "Settings"};
    private static final String[] DESC = {
            "", "",
            "",
            "Kurulu, önerilen ve ek paketler burada yönetilecek.",
            "",
            ""};
    private static final String[] STAGE = {"", "", "", "Aşama 5 devamı", "", ""};

    // Alt çubukta görünen sekmeler (Packages henüz içeriksiz olduğu için gösterilmez).
    private static final int[] NAV_TAB = {0, 1, 2, 4, 5};
    private static final String[] NAV_LABEL = {"Home", "Desktop", "Themes", "Repair", "Settings"};
    private static final IconView.Type[] NAV_ICON = {
            IconView.Type.HOME, IconView.Type.DESKTOP, IconView.Type.PALETTE,
            IconView.Type.WRENCH, IconView.Type.GEAR};

    private Ui ui;
    private FrameLayout content;
    private FrameLayout navWrap;
    private View indicator;
    private final IconView[] navIcon = new IconView[NAV_TAB.length];
    private final TextView[] navText = new TextView[NAV_TAB.length];
    private int current = 0;
    private boolean shown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogManager.init(this);
        LogManager.info("APP", "X7 başlatıldı");
        ui = new Ui(this);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0x00000000);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ui.bg);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @SuppressWarnings("deprecation")
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int l = 0, t = 0, r = 0, b = 0;
                if (Build.VERSION.SDK_INT >= 28) {
                    DisplayCutout dc = insets.getDisplayCutout();
                    if (dc != null) {
                        l = dc.getSafeInsetLeft(); t = dc.getSafeInsetTop(); r = dc.getSafeInsetRight();
                    }
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    b = insets.getInsets(WindowInsets.Type.ime()).bottom;
                } else {
                    b = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(l, t, r, b);
                return insets;
            }
        });

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        View line = new View(this);
        line.setBackgroundColor(ui.stroke);
        root.addView(line, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(1)));

        navWrap = new FrameLayout(this);
        navWrap.setBackgroundColor(ui.card);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < NAV_TAB.length; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            IconView ic = new IconView(this, NAV_ICON[i], ui.sub);
            item.addView(ic, new LinearLayout.LayoutParams(ui.dp(26), ui.dp(26)));
            TextView tv = ui.text(NAV_LABEL[i], 11, ui.sub, true);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, ui.dp(3), 0, 0);
            item.addView(tv);
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(NAV_TAB[idx], NAV_TAB[idx] != current); }
            });
            navIcon[i] = ic;
            navText[i] = tv;
            bar.addView(item, new LinearLayout.LayoutParams(0, ui.dp(66), 1f));
        }
        navWrap.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        indicator = new View(this);
        indicator.setBackground(ui.rounded(ui.accent, 2, 0));
        navWrap.addView(indicator, new FrameLayout.LayoutParams(ui.dp(30), ui.dp(3), Gravity.TOP | Gravity.START));
        root.addView(navWrap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        hideSystemBars();
    }

    /** Durum çubuğu ve gezinme tuşları gizli; kenardan kaydırınca geçici görünür. */
    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                if (!ui.dark) {
                    c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
                }
            }
        } else {
            int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            if (!ui.dark && Build.VERSION.SDK_INT >= 23) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            w.getDecorView().setSystemUiVisibility(f);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars(); // diyalog/izin penceresinden dönünce tekrar gizle
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        select(current, !shown);
        shown = true;
        DesktopController.get(this).refresh(); // gerçek durumu Termux'tan oku
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Installer.get(this).setListener(null);
        ThemeManager.get(this).setListener(null);
        RepairManager.get(this).setListener(null);
        DesktopController.get(this).setListener(null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        boolean granted = results.length > 0 && results[0] == 0;
        LogManager.info("PERM", "RUN_COMMAND izni: " + (granted ? "verildi" : "reddedildi"));
        select(current, false);
    }

    /** Arka plan işleri bitince sayfayı tazeler (animasyonsuz). */
    public void refresh() {
        if (isFinishing() || isDestroyed()) return;
        if (current <= 2 || current == 4) select(current, false);
    }

    public void showTab(int i) { select(i, i != current); }

    private void select(int i, boolean animate) {
        current = i;
        content.removeAllViews();
        View page;
        HomePage.intro = animate;
        if (i == 0) page = HomePage.build(ui);
        else if (i == 1) page = InstallPage.build(ui, this);
        else if (i == 2) page = ThemesPage.build(ui, this);
        else if (i == 4) page = RepairPage.build(ui, this);
        else if (i == 5) page = SettingsPage.build(ui, this);
        else page = InfoPage.build(ui, TABS[i], DESC[i], STAGE[i]);
        content.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (animate && page instanceof ScrollView && ((ScrollView) page).getChildCount() > 0) {
            View c = ((ScrollView) page).getChildAt(0);
            if (c instanceof ViewGroup) ui.animateIn((ViewGroup) c);
        }

        int active = -1;
        for (int k = 0; k < NAV_TAB.length; k++) if (NAV_TAB[k] == i) active = k;
        for (int k = 0; k < NAV_TAB.length; k++) {
            boolean on = k == active;
            navIcon[k].setColor(on ? ui.accent : ui.sub);
            navText[k].setTextColor(on ? ui.accent : ui.sub);
            float s = on ? 1.15f : 1f;
            if (animate) {
                navIcon[k].animate().scaleX(s).scaleY(s).setDuration(260)
                        .setInterpolator(new OvershootInterpolator(2.4f)).start();
            } else {
                navIcon[k].setScaleX(s);
                navIcon[k].setScaleY(s);
            }
        }
        moveIndicator(active, animate);
    }

    private void moveIndicator(final int k, final boolean animate) {
        navWrap.post(new Runnable() {
            @Override public void run() {
                int w = navWrap.getWidth();
                if (w == 0) return;
                if (k < 0) { indicator.setAlpha(0f); return; }
                indicator.setAlpha(1f);
                float cell = w / (float) NAV_TAB.length;
                float target = cell * k + (cell - indicator.getWidth()) / 2f;
                if (animate) {
                    indicator.animate().translationX(target).setDuration(300)
                            .setInterpolator(new DecelerateInterpolator(1.6f)).start();
                } else {
                    indicator.setTranslationX(target);
                }
            }
        });
    }
}
