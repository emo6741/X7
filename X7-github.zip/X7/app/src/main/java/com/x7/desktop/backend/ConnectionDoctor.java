package com.x7.desktop.backend;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.util.ArrayList;
import java.util.List;

/** X7 dahili runtime tanılaması. Harici Termux/X11 uygulamalarına erişmez. */
public final class ConnectionDoctor {
    public enum Level { OK,WARN,FAIL,SKIP }
    public enum Fix { RUNTIME_PREPARE,APP_PERMISSION_SETTINGS,BATTERY_SETTINGS,NETWORK_SETTINGS }
    public static final class Step { public final String name; public final Level level; public final String detail; public final List<Fix> fixes=new ArrayList<Fix>(); Step(String n,Level l,String d){name=n;level=l;detail=d;} Step fix(Fix... f){for(Fix x:f)fixes.add(x);return this;} }
    public interface Callback { void onDone(List<Step> steps); }
    private ConnectionDoctor(){}
    public static Boolean deviceOnline(Context c){ try{ ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); if(n==null)return false; NetworkCapabilities nc=cm.getNetworkCapabilities(n); return nc!=null&&nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET); }catch(Exception e){return null;} }
    public static void run(Context c,Callback cb){ final Context app=c.getApplicationContext(); final List<Step> s=new ArrayList<Step>(); final EmbeddedDebianRuntime rt=new EmbeddedDebianRuntime(app); s.add(new Step("Debian rootfs",rt.rootfsPresent()?Level.OK:Level.WARN,rt.rootfsPresent()?"Hazır":"İlk kullanımda indirilecek").fix(Fix.RUNTIME_PREPARE)); s.add(new Step("PRoot",rt.prootPresent()?Level.OK:Level.WARN,rt.prootPresent()?"Hazır":"İlk kullanımda hazırlanacak").fix(Fix.RUNTIME_PREPARE)); Boolean on=deviceOnline(app); s.add(new Step("Cihaz interneti",on==null?Level.SKIP:(on?Level.OK:Level.FAIL),on==null?"Ağ durumu okunamadı":(on?"Bağlı":"Bağlı değil")).fix(Fix.NETWORK_SETTINGS)); s.add(new Step("Görüntüleme",Level.OK,"X7 dahili görüntüleme katmanı")); s.add(new Step("Masaüstü",Level.OK,"XFCE/KDE dahili Debian runtime içinde çalışır")); cb.onDone(s); }
}
