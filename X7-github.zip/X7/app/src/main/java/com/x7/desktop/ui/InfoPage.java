package com.x7.desktop.ui;

import android.view.View;
import android.widget.LinearLayout;

/** Henüz yapılmamış sekmeler için dürüst yer tutucu: ne zaman geleceğini söyler. */
public final class InfoPage {
    private InfoPage() {}

    public static View build(Ui ui, String title, String desc, String stage) {
        LinearLayout col = ui.column();
        col.addView(ui.text(title, 28, ui.text, true));
        LinearLayout c = ui.addCard(col);
        c.addView(ui.text(desc, 15, ui.text, false));
        c.addView(ui.text("Henüz yapılmadı · " + stage, 13, ui.sub, false));
        return ui.scroll(col);
    }
}
