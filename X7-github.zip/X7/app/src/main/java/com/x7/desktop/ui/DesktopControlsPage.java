package com.x7.desktop.ui;

import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;

/** Referans görseldeki Desktop sekmesi: gerçek kontrol düğmeleri + masaüstü önizlemesi. */
public final class DesktopControlsPage {
    private DesktopControlsPage() {}

    public static View build(final Ui ui, final MainActivity act) {
        LinearLayout col = ui.column();
        LinearLayout head = new LinearLayout(ui.ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView x7 = ui.text("X7", 31, ui.accent, true);
        x7.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD_ITALIC));
        head.addView(x7, new LinearLayout.LayoutParams(ui.dp(42), -2));
        head.addView(ui.text("Masaüstü", 21, ui.text, true), new LinearLayout.LayoutParams(0,-2,1));
        col.addView(head);
        col.addView(ui.text("XFCE Masaüstü Yönetimi", 13, ui.sub, false));
        col.addView(sp(ui, 10));

        ImageView preview = new ImageView(ui.ctx);
        preview.setImageResource(com.x7.desktop.R.drawable.wallpaper_pure);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackground(ui.rounded(ui.card, 12, ui.stroke));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, ui.dp(158));
        pp.bottomMargin = ui.dp(10);
        col.addView(preview, pp);

        LinearLayout cap = ui.addCard(col);
        cap.setPadding(ui.dp(12),ui.dp(7),ui.dp(12),ui.dp(7));
        cap.addView(ui.text("XFCE", 13, ui.text, true));
        DesktopControls.add(ui, act, col, false);
        return ui.scroll(col);
    }
    private static View sp(Ui ui,int d){ return new View(ui.ctx){ { setLayoutParams(new LinearLayout.LayoutParams(1,ui.dp(d))); } }; }
}
