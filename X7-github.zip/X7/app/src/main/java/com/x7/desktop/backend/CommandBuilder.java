package com.x7.desktop.backend;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Tüm Termux komutları BURADA tanımlanır (beyaz liste).
 * Masaüstü scriptleri assets/scripts/ altında durur ve INSTALL_SCRIPTS ile Termux'a yazılır.
 */
public final class CommandBuilder {
    public enum Id {
        PROBE, NETCHECK, PREPARE_ESTIMATE, STEP_REPO, STEP_XFCE, STEP_KDE, STEP_X11, STEP_VERIFY,
        INSTALL_SCRIPTS, DESKTOP_STATUS, DESKTOP_START, DESKTOP_STOP, DESKTOP_FORCE_STOP,
        X11_CHECK, X11_CLEAN, X11_REPAIR,
        REPAIR_TERMUX, REPAIR_XFCE, REPAIR_XFCE_FIX, REPAIR_KDE, REPAIR_KDE_FIX, REPAIR_PACKAGES, REPAIR_PACKAGES_FIX,
        REPAIR_STARTUP,
        VNC_INSTALL, VNC_SETUP, VNC_STATUS, VNC_START, VNC_STOP, VNC_FORCE_STOP
    }

    /** Tema işlemleri (parametreli: tema kimliği). */
    public enum ThemeOp { FILES, PACKAGES, APPLY, ROLLBACK, STATUS }

    private static final Pattern THEME_ID = Pattern.compile("[a-z0-9_-]+");
    private static final Pattern REL_PATH = Pattern.compile("[A-Za-z0-9._-]+(/[A-Za-z0-9._-]+)*");
    private static final Pattern PKG_NAME = Pattern.compile("[a-z0-9][a-z0-9+.-]*");

    public static final class Spec {
        public final String label;
        public final String path;
        public final String[] args;
        public final String workdir;
        /** true ise Termux komutun çalışmasını kendi terminal penceresinde görünür tutar. */
        public final boolean visibleInTermux;
        Spec(String label, String path, String[] args, String workdir) {
            this(label, path, args, workdir, false);
        }
        Spec(String label, String path, String[] args, String workdir, boolean visibleInTermux) {
            this.label = label; this.path = path; this.args = args; this.workdir = workdir;
            this.visibleInTermux = visibleInTermux;
        }
        public String shellCommand() {
            StringBuilder b = new StringBuilder(path);
            for (String a : args) {
                b.append(' ').append(shellQuote(a));
            }
            return b.toString();
        }
        private static String shellQuote(String s) {
            if (s == null) return "''";
            return "'" + s.replace("'", "'\"'\"'") + "'";
        }
    }

    private static final String HOME = "/data/data/com.termux/files/home";
    private static final String BIN = "/data/data/com.termux/files/usr/bin";
    private static final String BASH = BIN + "/bash";
    private static final String[] SCRIPTS = {"x7-start", "x7-stop", "x7-status", "x7-x11check", "x7-x11repair", "x7-theme", "x7-repair", "x7-vnc"};

    private static final String ENV = "export DEBIAN_FRONTEND=noninteractive; ";
    private static final String UPD = "apt-get update";
    private static final String INST =
            "apt-get install -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef ";

    private CommandBuilder() {}

    /** Termux'a yazılan scriptlerin adları (x7-repair sağlamlık kontrolü için). */
    public static String[] scriptNames() { return SCRIPTS.clone(); }

    /**
     * Her scriptin BEKLENEN SHA-256 özeti (INSTALL_SCRIPTS'in yazacağı içerikle birebir:
     * sonunda satır sonu yoksa eklenir). Termux'taki gerçek dosyayla karşılaştırılır.
     */
    public static java.util.Map<String, String> scriptHashes(Context c) {
        java.util.Map<String, String> m = new java.util.LinkedHashMap<String, String>();
        for (String n : SCRIPTS) {
            try {
                String body = asset(c, n);
                if (!body.endsWith("\n")) body = body + "\n";
                java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
                byte[] d = md.digest(body.getBytes("UTF-8"));
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                m.put(n, sb.toString());
            } catch (Exception e) {
                m.put(n, "");
            }
        }
        return m;
    }

    private static Spec bash(String label, String script) {
        return new Spec(label, BASH, new String[]{"-c", script}, HOME);
    }

    private static Spec bashVisible(String label, String script) {
        return new Spec(label, BASH, new String[]{"-c", script}, HOME, true);
    }

    private static Spec script(String label, String name, String... extra) {
        String[] a = new String[1 + extra.length];
        a[0] = BIN + "/" + name;
        System.arraycopy(extra, 0, a, 1, extra.length);
        return new Spec(label, BASH, a, HOME);
    }

    private static Spec scriptVisible(String label, String name, String... extra) {
        String[] a = new String[1 + extra.length];
        a[0] = BIN + "/" + name;
        System.arraycopy(extra, 0, a, 1, extra.length);
        return new Spec(label, BASH, a, HOME, true);
    }

    /** Çıktıyı Termux'ta ~/.x7-<ad>.log'a yazar, son 15 satırı döndürür, çıkış kodunu korur. */
    private static String wrap(String name, String body) {
        String log = "$HOME/.x7-" + name + ".log";
        return ENV + "{ " + body + "; } </dev/null >" + log + " 2>&1; rc=$?; tail -n 15 " + log
                + "; exit $rc";
    }

    /** Termux terminalinde canlı çıktı + aynı anda X7 logu. */
    private static String wrapVisible(String name, String body) {
        String log = "$HOME/.x7-" + name + ".log";
        return ENV + "{ " + body + "; } </dev/null 2>&1 | tee \"" + log
                + "\"; rc=${PIPESTATUS[0]}; exit $rc";
    }

    private static String asset(Context c, String name) {
        try {
            InputStream in = c.getAssets().open(name.indexOf('/') >= 0 ? name : "scripts/" + name);
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            } finally {
                in.close();
            }
        } catch (IOException e) {
            throw new IllegalStateException("Script dosyası okunamadı: " + name);
        }
    }

    /** Tema komutları: kimlik ve dosya yolları doğrulanır, rastgele metin shell'e girmez. */
    public static Spec theme(Context c, ThemeOp op, String themeId) {
        if (themeId == null || !THEME_ID.matcher(themeId).matches()) {
            throw new IllegalArgumentException("Geçersiz tema kimliği");
        }
        switch (op) {
            case STATUS:
                return script("Tema durumu", "x7-theme", "status", themeId);
            case APPLY:
                return scriptVisible("Temayı uygula", "x7-theme", "apply", themeId);
            case ROLLBACK:
                return scriptVisible("Temayı geri al", "x7-theme", "rollback", themeId);
            case PACKAGES: {
                JSONArray pk = themeJson(c, themeId).optJSONArray("packages");
                StringBuilder names = new StringBuilder();
                if (pk != null) {
                    for (int i = 0; i < pk.length(); i++) {
                        String n = pk.optString(i, "");
                        if (!PKG_NAME.matcher(n).matches()) {
                            throw new IllegalArgumentException("Geçersiz paket adı: " + n);
                        }
                        names.append(n).append(' ');
                    }
                }
                if (names.length() == 0) return bash("Tema paketleri", "echo packages=none");
                return bashVisible("Tema paketleri", wrapVisible("themepkg", UPD + " && " + INST + names.toString().trim()));
            }
            case FILES: {
                JSONArray files = themeJson(c, themeId).optJSONArray("files");
                if (files == null || files.length() == 0) {
                    throw new IllegalStateException("theme.json içinde dosya listesi yok");
                }
                String root = "$HOME/.x7/themes/" + themeId;
                StringBuilder sb = new StringBuilder("rm -rf \"" + root + "\" && mkdir -p \"" + root + "\"\n");
                for (int i = 0; i < files.length(); i++) {
                    String rel = files.optString(i, "");
                    if (!REL_PATH.matcher(rel).matches() || rel.contains("..")) {
                        throw new IllegalArgumentException("Geçersiz tema dosyası: " + rel);
                    }
                    String body = asset(c, "themes/" + themeId + "/" + rel);
                    sb.append("mkdir -p \"$(dirname \"").append(root).append("/").append(rel).append("\")\"\n");
                    sb.append("cat > \"").append(root).append("/").append(rel).append("\" <<'X7EOF'\n");
                    sb.append(body);
                    if (!body.endsWith("\n")) sb.append("\n");
                    sb.append("X7EOF\n");
                }
                sb.append("echo files=ok\n");
                return bashVisible("Tema dosyalarını kopyala", sb.toString());
            }
            default:
                throw new IllegalArgumentException("Bilinmeyen tema işlemi: " + op);
        }
    }

    private static JSONObject themeJson(Context c, String themeId) {
        try {
            return new JSONObject(asset(c, "themes/" + themeId + "/theme.json"));
        } catch (org.json.JSONException e) {
            throw new IllegalStateException("theme.json okunamadı: " + e.getMessage());
        }
    }

    public static Spec desktopStart(String desktop) {
        if (!"XFCE".equals(desktop) && !"KDE Plasma".equals(desktop)) throw new IllegalArgumentException("Geçersiz masaüstü");
        return script("Masaüstünü başlat", "x7-start", "--desktop", desktop);
    }

    public static Spec vncSetup(String desktop) {
        if (!"XFCE".equals(desktop) && !"KDE Plasma".equals(desktop)) throw new IllegalArgumentException("Geçersiz masaüstü");
        return script("VNC yapılandırması", "x7-vnc", "setup", desktop);
    }

    public static Spec vncStart(String resolution, String desktop) {
        if (!"1280x720".equals(resolution) && !"1600x900".equals(resolution) && !"1920x1080".equals(resolution)) {
            throw new IllegalArgumentException("Geçersiz VNC çözünürlüğü");
        }
        if (!"XFCE".equals(desktop) && !"KDE Plasma".equals(desktop)) throw new IllegalArgumentException("Geçersiz masaüstü");
        return script("VNC başlat", "x7-vnc", "start", resolution, desktop);
    }

    public static Spec prepareEstimate(String desktop, String display) {
        if (!"XFCE".equals(desktop) && !"KDE Plasma".equals(desktop)) throw new IllegalArgumentException("Geçersiz masaüstü");
        String packages = "KDE Plasma".equals(desktop) ? "plasma" : "xfce4 xfce4-terminal";
        if ("VNC".equals(display)) packages += " tigervnc";
        return bash("Boyut hesabı", ENV + "{ " + UPD + " && " + INST + "x11-repo && " + UPD + "; } </dev/null >$HOME/.x7-prep.log 2>&1 || { echo prep=fail; tail -n 5 $HOME/.x7-prep.log; exit 0; }; echo prep=ok; apt-get -s install " + packages + " </dev/null 2>&1 | grep -E \"^Need to get|After this operation|newly installed\"; exit 0");
    }

    public static Spec build(Context c, Id id) {
        switch (id) {
            case PROBE:
                return bash("Ortam kontrolü",
                        "echo x7probe=1; "
                        + "for c in startxfce4 startplasma-x11 termux-x11 pkg; do "
                        + "if command -v $c >/dev/null 2>&1; then echo $c=yes; else echo $c=no; fi; "
                        + "done; echo arch=$(uname -m)");
            case NETCHECK:
                return bash("İnternet kontrolü",
                        "if curl -fsSL --max-time 8 -o /dev/null https://termux.dev >/dev/null 2>&1; then echo net=yes; "
                        + "elif command -v wget >/dev/null 2>&1 && wget -q -T 8 -O /dev/null https://termux.dev >/dev/null 2>&1; then echo net=yes; "
                        + "elif timeout 6 bash -c 'exec 3<>/dev/tcp/1.1.1.1/443' >/dev/null 2>&1; then echo net=yes; "
                        + "else echo net=no; fi");
            case PREPARE_ESTIMATE: {
                StateManager st = StateManager.load(c);
                String packages = "KDE Plasma".equals(st.desktop) ? "plasma procps dbus" : "xfce4 xfce4-terminal procps dbus";
                if (!"VNC".equals(st.display)) packages += " termux-x11-nightly";
                else packages += " tigervnc";
                return bash("Boyut hesabı",
                        ENV + "{ " + UPD + " && " + INST + "x11-repo && " + UPD
                        + "; } </dev/null >$HOME/.x7-prep.log 2>&1 "
                        + "|| { echo prep=fail; tail -n 5 $HOME/.x7-prep.log; exit 0; }; "
                        + "echo prep=ok; "
                        + "apt-get -s install " + packages + " </dev/null 2>&1 "
                        + "| grep -E \"^Need to get|After this operation|newly installed\"; exit 0");
            }
            case STEP_REPO:
                return bashVisible("Paket deposu", wrapVisible("repo", UPD + " && " + INST + "x11-repo && " + UPD));
            case STEP_XFCE:
                return bashVisible("XFCE kurulumu", wrapVisible("xfce", INST + "xfce4 xfce4-terminal procps dbus"));
            case STEP_KDE:
                return bashVisible("KDE Plasma kurulumu", wrapVisible("kde", INST + "plasma procps dbus"));
            case STEP_X11:
                return bashVisible("Termux:X11 paketi", wrapVisible("x11", INST + "termux-x11-nightly"));
            case STEP_VERIFY:
                return bash("Kurulum doğrulama",
                        "echo startxfce4=$(command -v startxfce4 >/dev/null 2>&1 && echo yes || echo no); "
                        + "echo startplasma-x11=$(command -v startplasma-x11 >/dev/null 2>&1 && echo yes || echo no); "
                        + "echo termux-x11=$(command -v termux-x11 >/dev/null 2>&1 && echo yes || echo no); "
                        + "echo vncserver=$(command -v vncserver >/dev/null 2>&1 && echo yes || echo no); "
                        + "echo pkg_plasma=$(dpkg-query -W -f='${Status}' plasma 2>/dev/null | grep -q 'install ok installed' && echo yes || echo no); "
                        + "echo pkg_xfce=$(dpkg-query -W -f='${Status}' xfce4 2>/dev/null | grep -q 'install ok installed' && echo yes || echo no)");
            case INSTALL_SCRIPTS: {
                StringBuilder sb = new StringBuilder("mkdir -p \"" + BIN + "\"\n");
                for (String n : SCRIPTS) {
                    String body = asset(c, n);
                    sb.append("cat > \"").append(BIN).append("/").append(n).append("\" <<'X7EOF'\n");
                    sb.append(body);
                    if (!body.endsWith("\n")) sb.append("\n");
                    sb.append("X7EOF\nchmod 755 \"").append(BIN).append("/").append(n).append("\"\n");
                }
                sb.append("echo scripts=ok\n");
                return bashVisible("Scriptleri kur", sb.toString());
            }
            case DESKTOP_STATUS:
                return script("Masaüstü durumu", "x7-status");
            case DESKTOP_START:
                return scriptVisible("Masaüstünü başlat", "x7-start", "--desktop", "XFCE");
            case DESKTOP_STOP:
                return script("Masaüstünü durdur", "x7-stop");
            case DESKTOP_FORCE_STOP:
                return script("Zorla durdur", "x7-stop", "--force");
            case X11_CHECK:
                return script("X11 kontrolü", "x7-x11check");
            case X11_CLEAN:
                return script("X11 temizliği", "x7-x11repair");
            case X11_REPAIR:
                return scriptVisible("X11 onarımı", "x7-x11repair", "--pkg");
            case REPAIR_TERMUX:
                return script("Termux kontrolü", "x7-repair", "termux");
            case REPAIR_XFCE:
                return script("XFCE kontrolü", "x7-repair", "xfce");
            case REPAIR_XFCE_FIX:
                return script("XFCE onarımı", "x7-repair", "xfce", "--fix");
            case REPAIR_KDE:
                return script("KDE kontrolü", "x7-repair", "kde");
            case REPAIR_KDE_FIX:
                return script("KDE onarımı", "x7-repair", "kde", "--fix");
            case REPAIR_PACKAGES:
                return script("Paket kontrolü", "x7-repair", "packages");
            case REPAIR_PACKAGES_FIX:
                return script("Paket onarımı", "x7-repair", "packages", "--fix");
            case REPAIR_STARTUP:
                return script("Başlangıç scriptleri kontrolü", "x7-repair", "startup");
            case VNC_INSTALL:
                return bashVisible("VNC kurulumu", wrapVisible("vnc-install", UPD + " && " + INST + "x11-repo tigervnc dbus"));
            case VNC_SETUP:
                return script("VNC yapılandırması", "x7-vnc", "setup", "XFCE");
            case VNC_STATUS:
                return script("VNC durumu", "x7-vnc", "status");
            case VNC_START:
                return script("VNC başlat", "x7-vnc", "start", "1280x720");
            case VNC_STOP:
                return script("VNC durdur", "x7-vnc", "stop");
            case VNC_FORCE_STOP:
                return script("VNC zorla durdur", "x7-vnc", "stop", "--force");
            default:
                throw new IllegalArgumentException("Bilinmeyen komut: " + id);
        }
    }
}
