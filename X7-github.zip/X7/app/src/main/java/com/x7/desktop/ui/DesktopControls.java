package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;

/** Dahili Linux masaüstü kontrol düğmeleri. */
public final class DesktopControls {
    private DesktopControls() {}
    public static String statusText(DesktopController dc){ switch(dc.getStatus()){case RUNNING:return "✓ Running";case STOPPED:return "Stopped";case STARTING:return "⟳ Starting";case STOPPING:return "⟳ Stopping";case REPAIRING:return "🔧 Repairing";case ERROR:return "✗ Error";default:return "Bilinmiyor";} }
    private static TextView disabled(Ui ui,LinearLayout p,String label){ TextView b=ui.addButton(p,label,true,null); b.setEnabled(false); b.setAlpha(.45f); b.setMinHeight(ui.dp(56)); return b; }
    public static void add(final Ui ui,final MainActivity act,LinearLayout parent,boolean showForce){
        final DesktopController dc=DesktopController.get(act); dc.setListener(()->act.refresh());
        boolean installed=StateManager.load(act).installState==StateManager.InstallState.COMPLETED;
        if(!installed){ disabled(ui,parent,"🚀 Masaüstünü Başlat"); parent.addView(ui.text("Önce Paketler sekmesinden kurulumu tamamla.",13,ui.sub,false)); return; }
        DesktopController.Status s=dc.getStatus();
        if(s==DesktopController.Status.STARTING||s==DesktopController.Status.REPAIRING||s==DesktopController.Status.STOPPING){ disabled(ui,parent,"⟳ "+(dc.getProgress().length()>0?dc.getProgress():"Lütfen bekleyin...")); }
        else if(s==DesktopController.Status.RUNNING){ ui.addButton(parent,"⏹ Masaüstünü Durdur",true,v->dc.stop(false)); ui.addButton(parent,"↻ Yeniden Başlat",false,v->dc.restart()); }
        else { ui.addButton(parent,"🚀 Masaüstünü Başlat",true,v->dc.start()); if(s==DesktopController.Status.UNKNOWN||s==DesktopController.Status.ERROR) ui.addButton(parent,"Durumu Yenile",false,v->dc.refresh()); }
        if(showForce) ui.addButton(parent,"Zorla Durdur",false,v->confirmForce(act,dc));
        if(dc.getMessage().length()>0){ TextView m=ui.text("✗ "+dc.getMessage(),13,ui.sub,false); m.setPadding(0,ui.dp(8),0,0); m.setTextIsSelectable(true); parent.addView(m); }
        if(dc.getNotice().length()>0){ TextView n=ui.text(dc.getNotice(),13,ui.sub,false); n.setPadding(0,ui.dp(8),0,0); parent.addView(n); }
    }
    private static void confirmForce(MainActivity act,final DesktopController dc){ new AlertDialog.Builder(act).setTitle("Zorla Durdur").setMessage("Linux masaüstü süreçleri sonlandırılacak.").setNegativeButton("İptal",null).setPositiveButton("Zorla Durdur",(d,w)->dc.stop(true)).show(); }
}
