# X7 v0.12.0 — AndroidIDE-ready

A minimal Android project for X7 Desktop Manager.

## Toolchain

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.2.2 |
| Gradle | 8.2.1 |
| Java | 17 |
| Android SDK / compileSdk | 34 |
| Build Tools | 34.0.0 |
| minSdk | 24 |
| targetSdk | 34 |
| External dependencies | 0 |

Open the **X7** directory in AndroidIDE and build `app` with the **JDK 17** supplied by AndroidIDE.

See `docs/ANDROIDIDE_BUILD_CHECKLIST.md` for the exact setup.
