# X7 — AndroidIDE build profile

This project is intentionally kept dependency-free and targets the toolchain that AndroidIDE v2.7.x supports reliably.

## Pinned build toolchain

- Android Gradle Plugin: **8.2.2**
- Gradle: **8.2.1**
- Java language/source/target: **17**
- Android compile SDK: **34**
- Android Build Tools: **34.0.0**
- minSdk: **24**
- targetSdk: **34**
- External Gradle dependencies: **0**

AndroidIDE's bundled **JDK 17** should be selected under **Preferences → Build & Run → JDK version**. The project deliberately does not hard-code an AndroidIDE-internal JDK path because that path is device/version specific.

## AndroidIDE

1. Extract the ZIP.
2. Open the **X7** folder (the folder containing `settings.gradle`).
3. Let Gradle sync.
4. Select **JDK 17** in AndroidIDE if it is not already selected.
5. Build `app` → `assembleRelease` (or use the Build action).

The project contains no Kotlin, Compose, Jetpack, Material, or third-party runtime dependencies, so there is no extra dependency setup beyond Android SDK 34 and AndroidIDE's JDK 17.

## Important limitation

A project ZIP cannot safely bundle a complete AndroidIDE JDK for every phone architecture. AndroidIDE supplies the correct JDK 17 runtime. The project therefore pins the Java *language level* to 17 instead of embedding a device-specific JDK path.
