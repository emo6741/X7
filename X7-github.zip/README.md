# X7 v0.13.0 — AndroidIDE-ready

A minimal Android project for X7 Desktop Manager.

## Toolchain

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.2.2 |
| Gradle | 8.2.1 |
| Java | 17 |
| Android SDK / compileSdk | 34 |
| Build Tools | 34.0.0 |
| minSdk | 24 |
| targetSdk | 34 |
| External dependencies | 0 |

Open the **X7** directory in AndroidIDE and build `app` with the **JDK 17** supplied by AndroidIDE.

See `docs/ANDROIDIDE_BUILD_CHECKLIST.md` for the exact setup.

## Windows 7 theme sources

The X7 Windows 7 XFCE theme installs its external resources when the theme is applied:

- Icons: https://github.com/B00merang-Artwork/Windows-7
- GTK/XFWM4 Aero theme: https://www.xfce-look.org/p/2343514/

X7 downloads the archives into `~/.x7/downloads/win7`, extracts them, installs the icon theme under `~/.icons`, installs the XFCE theme under `~/.themes`, then applies GTK/XFWM4 settings and a bottom Windows-7-style XFCE panel.

## X7 UI Refresh

The Android shell has been redesigned around the X7 dark futuristic reference UI: persistent left navigation, blue/violet gradient accents, elevated rounded cards, compact status tiles, tablet-friendly spacing, press feedback and page-transition animations. Existing page/backend entry points are preserved so the redesign does not require a UI framework dependency.
