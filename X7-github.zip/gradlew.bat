@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%~dp0" %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.2.1 is required. Open this project in AndroidIDE or install Gradle 8.2.1.
exit /b 1
