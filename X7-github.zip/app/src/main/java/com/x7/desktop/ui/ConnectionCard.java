package com.x7.desktop.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.x7.desktop.backend.ConnectionDoctor;
import com.x7.desktop.backend.ConnectionDoctor.Fix;
import com.x7.desktop.backend.ConnectionDoctor.Level;
import com.x7.desktop.backend.ConnectionDoctor.Step;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.TermuxRunner;
import java.util.List;

/** "Bağlantı Tanılama" kartı: gerçek test sonuçları + her sorun için tek dokunuşluk çözüm. */
public final class ConnectionCard {
    private ConnectionCard() {}

    private static List<Step> last; // sayfa yenilense de son sonuç görünür kalır
    private static boolean running;

    public static void add(final Ui ui, final Activity act, LinearLayout parent) {
        LinearLayout c = ui.addCard(parent);
        c.addView(ui.text("Bağlantı Tanılama", 18, ui.text, true));
        TextView d = ui.text("Dahili Debian, komut izni, internet ve X11 bağlantısını tek tek sınar ve "
                + "hangi adımın bozuk olduğunu gösterir.", 13, ui.sub, false);
        d.setPadding(0, ui.dp(6), 0, 0);
        c.addView(d);

        final LinearLayout results = new LinearLayout(act);
        results.setOrientation(LinearLayout.VERTICAL);

        ui.addButton(c, "Tanılamayı Çalıştır", true, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (running) return;
                running = true;
                last = null;
                results.removeAllViews();
                results.addView(ui.text("⟳ Test ediliyor... (en fazla ~30 sn)", 13, ui.sub, false));
                ConnectionDoctor.run(act, new ConnectionDoctor.Callback() {
                    @Override public void onDone(List<Step> steps) {
                        running = false;
                        last = steps;
                        render(ui, act, results, steps);
                    }
                });
            }
        });
        c.addView(results);
        if (last != null) render(ui, act, results, last);
    }

    private static void render(final Ui ui, final Activity act, LinearLayout box, List<Step> steps) {
        box.removeAllViews();
        for (Step s : steps) {
            int col = s.level == Level.OK ? ui.green : s.level == Level.WARN ? ui.orange
                    : s.level == Level.FAIL ? ui.red : ui.sub;
            String mark = s.level == Level.OK ? "✓ " : s.level == Level.WARN ? "⚠ "
                    : s.level == Level.FAIL ? "✗ " : "– ";
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, ui.dp(10), 0, 0);
            row.addView(ui.text(mark + s.name, 15, col, true));
            TextView det = ui.text(s.detail, 13, ui.sub, false);
            det.setTextIsSelectable(true);
            row.addView(det);
            for (final Fix f : s.fixes) {
                ui.addButton(row, label(f), s.level == Level.FAIL && s.fixes.indexOf(f) == 0,
                        new View.OnClickListener() {
                            @Override public void onClick(View v) { apply(act, f); }
                        }).setMinHeight(ui.dp(44));
            }
            box.addView(row);
        }
    }

    private static String label(Fix f) {
        switch (f) {
            case REQUEST_PERMISSION: return "İzni İste";
            case APP_PERMISSION_SETTINGS: return "X7 İzin Ayarlarını Aç";
            case COPY_ALLOW_CMD: return "Komutu Kopyala ve Dahili Debian'u Aç";
            case OPEN_TERMUX: return "Dahili Debian'u Aç";
            case TERMUX_APP_SETTINGS: return "Dahili Debian Uygulama Ayarları (veri/izin)";
            case BATTERY_SETTINGS: return "Pil Optimizasyonu Ayarları";
            case NETWORK_SETTINGS: return "Ağ Ayarlarını Aç";
            case X11_NIGHTLY: return "Dahili Debian:X11 Nightly APK (GitHub)";
            default: return "Dahili Debian'u İndir (F-Droid)";
        }
    }

    private static void apply(Activity act, Fix f) {
        switch (f) {
            case REQUEST_PERMISSION:
                act.requestPermissions(new String[]{TermuxRunner.PERMISSION}, 1);
                break;
            case APP_PERMISSION_SETTINGS:
                openSettings(act, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, act.getPackageName());
                break;
            case COPY_ALLOW_CMD:
                copyAllowCmdAndOpenTermux(act);
                break;
            case OPEN_TERMUX:
                if (!TermuxDetector.open(act, TermuxDetector.TERMUX)) toast(act, "✗ Dahili Debian açılamadı");
                break;
            case TERMUX_APP_SETTINGS:
                openSettings(act, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, TermuxDetector.TERMUX);
                break;
            case BATTERY_SETTINGS:
                openSettings(act, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, null);
                break;
            case NETWORK_SETTINGS:
                openSettings(act, Settings.ACTION_WIRELESS_SETTINGS, null);
                break;
            case X11_NIGHTLY:
                if (!TermuxDetector.openUrl(act, ConnectionDoctor.X11_NIGHTLY_URL)) toast(act, "✗ Bağlantı açılamadı");
                break;
            default:
                if (!TermuxDetector.openUrl(act, ConnectionDoctor.TERMUX_FDROID_URL)) toast(act, "✗ Bağlantı açılamadı");
                break;
        }
    }

    /** allow-external-apps komutunu panoya koyar ve Dahili Debian'u açar. Komutu kullanıcı yapıştırıp çalıştırır. */
    public static void copyAllowCmdAndOpenTermux(Context c) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("X7 Dahili Debian komutu", ConnectionDoctor.ALLOW_CMD));
            toast(c, "Komut kopyalandı: Dahili Debian'a yapıştır, Enter'a bas, sonra Dahili Debian'u kapatıp aç.");
        } catch (Exception e) {
            toast(c, "✗ Pano kullanılamadı; komutu elle yaz.");
        }
        TermuxDetector.open(c, TermuxDetector.TERMUX);
    }

    private static void openSettings(Context c, String action, String pkg) {
        try {
            Intent i = new Intent(action);
            if (pkg != null) i.setData(Uri.parse("package:" + pkg));
            c.startActivity(i);
        } catch (Exception e) {
            toast(c, "✗ Ayar ekranı açılamadı");
        }
    }

    private static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }
}
