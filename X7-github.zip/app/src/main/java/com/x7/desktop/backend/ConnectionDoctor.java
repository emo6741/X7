package com.x7.desktop.backend;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Bağlantı tanılaması: Dahili Debian, Dahili Debian komut izni, internet ve X11 için GERÇEK sonuçlar verir.
 * Hiçbir adım tahmin edilmez; çalıştırılamayan adım "atlandı" olarak işaretlenir.
 */
public final class ConnectionDoctor {
    public static final String X11_NIGHTLY_URL = "https://www.debian.org/";
    public static final String TERMUX_FDROID_URL = "https://www.debian.org/";

    /** Dahili Debian'ta bir kez çalıştırılacak komut: dış uygulama erişimini açar ve ayarı yeniler. */
    public static final String ALLOW_CMD =
            "mkdir -p ~/.termux; sed -i '/allow-external-apps/d' ~/.termux/termux.properties 2>/dev/null; "
            + "echo 'allow-external-apps=true' >> ~/.termux/termux.properties; termux-reload-settings";

    public enum Fix {
        REQUEST_PERMISSION, APP_PERMISSION_SETTINGS, COPY_ALLOW_CMD, OPEN_TERMUX, TERMUX_APP_SETTINGS,
        BATTERY_SETTINGS, NETWORK_SETTINGS, X11_NIGHTLY, TERMUX_DOWNLOAD
    }

    public enum Level { OK, WARN, FAIL, SKIP }

    public static final class Step {
        public final String name;
        public final Level level;
        public final String detail;
        public final List<Fix> fixes = new ArrayList<Fix>();
        Step(String name, Level level, String detail) {
            this.name = name; this.level = level; this.detail = detail;
        }
        Step fix(Fix... f) { for (Fix x : f) fixes.add(x); return this; }
    }

    public interface Callback { void onDone(List<Step> steps); }

    private ConnectionDoctor() {}

    /** Cihazın kendi internet durumu (ağ yetenekleri). Okunamazsa null. */
    public static Boolean deviceOnline(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return Boolean.FALSE;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return Boolean.FALSE;
            return nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Exception e) {
            return null;
        }
    }

    public static void run(final Context ctx, final Callback cb) {
        final Context app = ctx.getApplicationContext();
        final List<Step> steps = new ArrayList<Step>();

        // 1) Dahili Debian kurulu mu?
        TermuxDetector.Result tx = TermuxDetector.check(app, TermuxDetector.TERMUX);
        if (!tx.installed) {
            steps.add(new Step("Dahili Debian", Level.FAIL, "Dahili Debian kurulu değil.").fix(Fix.TERMUX_DOWNLOAD));
            finish(steps, cb);
            return;
        }
        if (TermuxDetector.isPlayStoreBuild(tx)) {
            steps.add(new Step("Dahili Debian", Level.WARN, "Sürüm " + tx.version
                    + " (Play Store). Bu sürüm eski olabilir ve komut servisi çalışmayabilir; F-Droid/GitHub sürümü önerilir.")
                    .fix(Fix.TERMUX_DOWNLOAD));
        } else {
            steps.add(new Step("Dahili Debian", Level.OK, "Kurulu (v" + tx.version + ")"));
        }

        // 2) Komut izni
        if (!TermuxRunner.hasPermission(app)) {
            steps.add(new Step("Dahili Debian komut izni", Level.FAIL,
                    "RUN_COMMAND izni verilmemiş. İzin penceresi çıkmazsa uygulama izin ayarlarından ver.")
                    .fix(Fix.REQUEST_PERMISSION, Fix.APP_PERMISSION_SETTINGS));
            finish(steps, cb);
            return;
        }
        steps.add(new Step("Dahili Debian komut izni", Level.OK, "Verilmiş"));

        // 3) Cihaz interneti (Dahili Debian'tan bağımsız)
        final Boolean online = deviceOnline(app);
        if (online == null) {
            steps.add(new Step("Cihaz interneti", Level.SKIP, "Ağ durumu okunamadı."));
        } else if (online) {
            steps.add(new Step("Cihaz interneti", Level.OK, "Bağlı ve doğrulanmış"));
        } else {
            steps.add(new Step("Cihaz interneti", Level.FAIL,
                    "Cihaz internete bağlı görünmüyor (Wi-Fi/mobil veri/VPN kontrol et).")
                    .fix(Fix.NETWORK_SETTINGS));
        }

        // 4) Dahili Debian komut servisi
        TermuxRunner.run(app, CommandBuilder.Id.PROBE, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) {
                    steps.add(new Step("Dahili Debian komut servisi", Level.FAIL, r.error
                            + "\nDahili Debian'ta bir kez komutu çalıştırıp (Komutu Kopyala), Dahili Debian'u tamamen kapatıp aç.")
                            .fix(Fix.COPY_ALLOW_CMD, Fix.OPEN_TERMUX, Fix.TERMUX_APP_SETTINGS));
                    finish(steps, cb);
                    return;
                }
                Map<String, String> kv = r.keyValues();
                steps.add(new Step("Dahili Debian komut servisi", Level.OK, "Yanıt veriyor (mimari: " + kv.get("arch") + ")"));
                final boolean pkgX11 = "yes".equals(kv.get("termux-x11"));

                // 5) Dahili Debian içinden internet
                TermuxRunner.run(app, CommandBuilder.Id.NETCHECK, new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult nr) {
                        if (!nr.ok) {
                            steps.add(new Step("Dahili Debian interneti", Level.SKIP, "Test çalıştırılamadı: " + nr.error));
                        } else if ("yes".equals(nr.keyValues().get("net"))) {
                            steps.add(new Step("Dahili Debian interneti", Level.OK, "Dahili Debian internete ulaşıyor"));
                        } else if (online != null && !online) {
                            steps.add(new Step("Dahili Debian interneti", Level.FAIL,
                                    "Cihazda internet yok; önce bağlantıyı düzelt.").fix(Fix.NETWORK_SETTINGS));
                        } else {
                            steps.add(new Step("Dahili Debian interneti", Level.FAIL,
                                    "Cihaz çevrimiçi ama Dahili Debian internete ulaşamıyor. Sık nedenler: Dahili Debian için "
                                    + "veri tasarrufu/arka plan veri kısıtı, pil optimizasyonu, VPN veya Özel DNS. "
                                    + "Dahili Debian'a sınırsız veri ve kısıtlamasız pil ver.")
                                    .fix(Fix.TERMUX_APP_SETTINGS, Fix.BATTERY_SETTINGS));
                        }

                        // 6) X11
                        TermuxDetector.Result x11 = TermuxDetector.check(app, TermuxDetector.X11);
                        if (!x11.installed) {
                            steps.add(new Step("Dahili Debian:X11 uygulaması", Level.FAIL, "Kurulu değil.")
                                    .fix(Fix.X11_NIGHTLY));
                        } else {
                            steps.add(new Step("Dahili Debian:X11 uygulaması", Level.OK, "Kurulu (v" + x11.version + ")"));
                        }
                        if (pkgX11) {
                            steps.add(new Step("termux-x11 paketi", Level.OK,
                                    "Kurulu. Dahili Debian:X11 APK'sı da nightly sürüm olmalı; sürümler uyuşmazsa X11 bağlanmaz.")
                                    .fix(Fix.X11_NIGHTLY));
                        } else {
                            steps.add(new Step("termux-x11 paketi", Level.WARN,
                                    "Dahili Debian'ta kurulu değil (Masaüstü sekmesindeki kurulumla gelir)."));
                        }
                        finish(steps, cb);
                    }
                });
            }
        });
    }

    private static void finish(List<Step> steps, Callback cb) {
        LogManager.info("DOCTOR", "Tanılama bitti: " + steps.size() + " adım");
        for (Step s : steps) LogManager.info("DOCTOR", s.level + " " + s.name + " - " + s.detail);
        cb.onDone(steps);
    }
}
