package com.x7.desktop;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.LogManager;
import com.x7.desktop.backend.RepairManager;
import com.x7.desktop.installer.Installer;
import com.x7.desktop.theme.ThemeManager;
import com.x7.desktop.ui.DesktopControlsPage;
import com.x7.desktop.ui.HomePage;
import com.x7.desktop.ui.IconView;
import com.x7.desktop.ui.InfoPage;
import com.x7.desktop.ui.InstallPage;
import com.x7.desktop.ui.RepairPage;
import com.x7.desktop.ui.SettingsPage;
import com.x7.desktop.ui.ThemesPage;
import com.x7.desktop.ui.Ui;

/** X7'nin yeni tablet odaklı, sol menülü ana kabuğu. */
public class MainActivity extends Activity {
    private static final int[] NAV_TAB = {0, 1, 2, 3, 4, 5, 6, 7};
    private static final String[] NAV_LABEL = {"Home", "Masaüstü", "Terminal", "Mağaza", "Paketler", "Temalar", "Onarım", "Ayarlar"};
    private static final IconView.Type[] NAV_ICON = {
            IconView.Type.HOME, IconView.Type.DESKTOP, IconView.Type.TERMINAL, IconView.Type.PACKAGE,
            IconView.Type.PACKAGE, IconView.Type.PALETTE, IconView.Type.WRENCH, IconView.Type.GEAR
    };

    private Ui ui;
    private FrameLayout content;
    private LinearLayout sidebar;
    private final IconView[] navIcons = new IconView[NAV_TAB.length];
    private final TextView[] navTexts = new TextView[NAV_TAB.length];
    private final LinearLayout[] navItems = new LinearLayout[NAV_TAB.length];
    private int current = 0;
    private boolean firstShown = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogManager.init(this);
        ui = new Ui(this);
        getWindow().setStatusBarColor(ui.bg);
        getWindow().setNavigationBarColor(ui.bg);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(ui.bg);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l=0,t=0,r=0,b=0;
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout dc = insets.getDisplayCutout();
                if (dc != null) { l=dc.getSafeInsetLeft(); t=dc.getSafeInsetTop(); r=dc.getSafeInsetRight(); }
            }
            if (Build.VERSION.SDK_INT >= 30) b = insets.getInsets(WindowInsets.Type.ime()).bottom;
            else b = insets.getSystemWindowInsetBottom();
            v.setPadding(l,t,r,b);
            return insets;
        });

        buildSidebar(root);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setBackgroundColor(ui.bg);
        content = new FrameLayout(this);
        right.addView(content, new LinearLayout.LayoutParams(-1,0,1f));
        root.addView(right, new LinearLayout.LayoutParams(0,-1,1f));

        setContentView(root);
        hideSystemBars();
    }

    private void buildSidebar(LinearLayout root) {
        sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(ui.dp(16), ui.dp(20), ui.dp(12), ui.dp(16));
        sidebar.setBackground(ui.rounded(0xFF081321, 0, 0));
        sidebar.setElevation(ui.dp(12));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = ui.text("X7", 35, ui.accent, true);
        logo.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD_ITALIC));
        logo.setLetterSpacing(-0.07f);
        brand.addView(logo, new LinearLayout.LayoutParams(ui.dp(64), -2));
        LinearLayout bt = new LinearLayout(this);
        bt.setOrientation(LinearLayout.VERTICAL);
        bt.addView(ui.text("Linux Desktop", 15, ui.text, true));
        bt.addView(ui.text("Manager", 11, ui.sub, false));
        brand.addView(bt);
        sidebar.addView(brand, new LinearLayout.LayoutParams(-1, ui.dp(64)));

        View line = new View(this); line.setBackgroundColor(ui.stroke);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(-1, ui.dp(1));
        lineLp.topMargin=ui.dp(8); lineLp.bottomMargin=ui.dp(16); sidebar.addView(line,lineLp);

        for (int i=0;i<NAV_TAB.length;i++) addNav(i);

        LinearLayout spacer = new LinearLayout(this); sidebar.addView(spacer,new LinearLayout.LayoutParams(1,0,1f));
        LinearLayout status = ui.addCard(sidebar);
        status.setPadding(ui.dp(10),ui.dp(10),ui.dp(10),ui.dp(10));
        status.addView(ui.text("SİSTEM",9,ui.sub,true));
        TextView st = ui.text("●  Hazır",12,ui.green,true);
        st.setPadding(0,ui.dp(5),0,0); status.addView(st);

        root.addView(sidebar,new LinearLayout.LayoutParams(ui.dp(218),-1));
    }

    private void addNav(final int i) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(ui.dp(12),0,ui.dp(8),0);
        IconView icon = new IconView(this,NAV_ICON[i],ui.sub);
        item.addView(icon,new LinearLayout.LayoutParams(ui.dp(26),ui.dp(26)));
        TextView text = ui.text(NAV_LABEL[i],13,ui.sub,i==0);
        text.setPadding(ui.dp(12),0,0,0);
        item.addView(text,new LinearLayout.LayoutParams(0,-1,1f));
        navIcons[i]=icon; navTexts[i]=text; navItems[i]=item;
        item.setOnClickListener(v -> select(NAV_TAB[i], NAV_TAB[i] != current));
        ui.pressable(item);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,ui.dp(48));
        lp.bottomMargin=ui.dp(6);
        sidebar.addView(item,lp);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        Window w=getWindow();
        if(Build.VERSION.SDK_INT>=30){
            w.setDecorFitsSystemWindows(true);
            WindowInsetsController c=w.getInsetsController();
            if(c!=null){ c.hide(WindowInsets.Type.navigationBars()); c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); c.setSystemBarsAppearance(0,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS); }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)hideSystemBars();}
    @Override protected void onResume(){super.onResume();hideSystemBars();select(current,!firstShown);firstShown=true;DesktopController.get(this).refresh();
        if (!new com.x7.desktop.backend.EmbeddedDebianRuntime(this).installed()) {
            new com.x7.desktop.backend.EmbeddedDebianRuntime(this).prepare((ok,msg) -> runOnUiThread(this::refresh));
        }}
    @Override protected void onDestroy(){super.onDestroy();Installer.get(this).setListener(null);ThemeManager.get(this).setListener(null);RepairManager.get(this).setListener(null);DesktopController.get(this).setListener(null);}

    public void refresh(){ if(isFinishing() || (Build.VERSION.SDK_INT>=17 && isDestroyed())) return; select(current,false); }
    public void showTab(int i){select(i,i!=current);}

    private void select(int i, boolean animate){
        current=i; content.removeAllViews();
        View page;
        HomePage.intro=animate;
        if(i==0) page=HomePage.build(ui);
        else if(i==1) page=com.x7.desktop.ui.LinuxDesktopPage.build(ui,this);
        else if(i==2) page=com.x7.desktop.ui.TerminalPage.build(ui,this);
        else if(i==3) page=com.x7.desktop.ui.StorePage.build(ui,this);
        else if(i==4) page=InstallPage.build(ui,this);
        else if(i==5) page=ThemesPage.build(ui,this);
        else if(i==6) page=RepairPage.build(ui,this);
        else if(i==7) page=SettingsPage.build(ui,this);
        else page=InfoPage.build(ui,"X7",""," ");
        content.addView(page,new FrameLayout.LayoutParams(-1,-1));
        updateNav();
        if(animate) animatePage(page);
    }

    private void updateNav(){
        for(int i=0;i<NAV_TAB.length;i++){
            boolean on=NAV_TAB[i]==current;
            navIcons[i].setColor(on?0xFFFFFFFF:ui.sub);
            navTexts[i].setTextColor(on?0xFFFFFFFF:ui.sub);
            navTexts[i].setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,on?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL));
            navItems[i].setBackground(on?ui.rounded(Ui.mix(ui.accent,ui.purple,0.32f),14,0):null);
            if(on) navItems[i].setElevation(ui.dp(4)); else navItems[i].setElevation(0);
        }
    }

    private void animatePage(View page){
        page.setAlpha(0f); page.setTranslationX(ui.dp(18));
        page.animate().alpha(1f).translationX(0).setDuration(360).setInterpolator(new DecelerateInterpolator(1.5f)).start();
        if(page instanceof ScrollView){ View child=((ScrollView)page).getChildAt(0); if(child instanceof ViewGroup) ui.animateIn((ViewGroup)child); }
    }
}
