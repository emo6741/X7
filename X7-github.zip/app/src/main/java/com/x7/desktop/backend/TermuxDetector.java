package com.x7.desktop.backend;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Compatibility facade; X7 no longer discovers or controls any external Termux package. */
public final class TermuxDetector {
    public static final String TERMUX = "embedded-debian";
    public static final String X11 = "embedded-display";
    public static final class Result {
        public final boolean installed; public final String packageName; public final String version;
        public Result(boolean i,String p,String v){installed=i;packageName=p;version=v;}
    }
    private TermuxDetector(){}
    public static Result check(Context c,String what){
        EmbeddedDebianRuntime r=new EmbeddedDebianRuntime(c);
        return new Result(TERMUX.equals(what)?r.installed():true, what, "internal");
    }
    public static boolean isPlayStoreBuild(Result r){return false;}
    public static boolean open(Context c,String what){ return false; }
    public static boolean openUrl(Context c,String url){
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; }
        catch(Exception e){ return false; }
    }
}
