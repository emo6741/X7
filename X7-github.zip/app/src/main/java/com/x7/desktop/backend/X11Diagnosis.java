package com.x7.desktop.backend;

import java.util.Map;

/**
 * X11 sorununun GERÇEK nedeni. Neden, Dahili Debian'taki x7-x11check / x7-x11repair çıktısından
 * (cause=...) okunur; tahmin edilmez. "Cihaz uyumsuz" gibi bir sonuç hiçbir zaman üretilmez.
 */
public final class X11Diagnosis {
    public enum Cause {
        NONE, NO_X11_APP, TERMUX_UNREACHABLE, NO_PGREP, NO_PKG_X11, NO_PKG_XFCE, LOW_STORAGE,
        STALE_SOCKET, NO_SOCKET, NO_CONN, NO_NET, REPO, PKG_FAIL, UNKNOWN
    }

    public final Cause cause;
    public final String title;
    public final String detail;
    /** "Sorunu Çöz" (x7-x11repair) bu nedeni giderebilir mi? */
    public final boolean fixable;

    private X11Diagnosis(Cause c, String title, String detail, boolean fixable) {
        this.cause = c; this.title = title; this.detail = detail; this.fixable = fixable;
    }

    public boolean ok() { return cause == Cause.NONE; }

    // ---- Android tarafında bilinen nedenler ----

    public static X11Diagnosis noX11App() {
        return new X11Diagnosis(Cause.NO_X11_APP, "Dahili Debian:X11 uygulaması yok",
                "Linux masaüstünü Android ekranında göstermek için Dahili Debian:X11 uygulaması gerekir. "
                + "Yalnızca resmi GitHub sürümlerinden kur.", false);
    }

    public static X11Diagnosis unreachable(String err) {
        return new X11Diagnosis(Cause.TERMUX_UNREACHABLE, "Dahili Debian'a ulaşılamadı",
                err == null || err.length() == 0 ? "Dahili Debian yanıt vermedi." : err, false);
    }

    /** Başlatma başarısız oldu ama ortam sağlam görünüyor: nedeni x7-start mesajıdır. */
    public static X11Diagnosis unknown(String startMsg) {
        String m = startMsg == null || startMsg.length() == 0 ? "Ayrıntı yok." : startMsg;
        return new X11Diagnosis(Cause.UNKNOWN, "X11 başlatılamadı",
                "Paketler ve X11 ortamı sağlam görünüyor ama başlatma başarısız oldu: " + m
                + "\nÖnce Sorunu Çöz'ü dene; olmazsa Teknik Ayrıntılar'a bak.", true);
    }

    public static X11Diagnosis other(String title, String detail) {
        return new X11Diagnosis(Cause.UNKNOWN, title, detail, false);
    }

    // ---- Script çıktısından ----

    /** x7-x11check sonucu. */
    public static X11Diagnosis fromCheck(CommandResult r) {
        if (r.exitCode == -1) return unreachable(r.error);
        if (r.exitCode == 127) {
            return new X11Diagnosis(Cause.UNKNOWN, "Kontrol scripti bulunamadı",
                    "x7-x11check Dahili Debian'ta yok. Masaüstünü bir kez başlatmayı veya X11 kontrolünü yeniden dene.",
                    false);
        }
        Map<String, String> kv = r.keyValues();
        return fromCause(kv.get("cause"), kv, r.error);
    }

    /** x7-x11repair sonucu (başarısızsa neden). Başarılıysa NONE. */
    public static X11Diagnosis fromRepair(CommandResult r) {
        if (r.exitCode == -1) return unreachable(r.error);
        Map<String, String> kv = r.keyValues();
        if (r.ok && "ok".equals(kv.get("state"))) return fromCause("none", kv, "");
        String msg = kv.get("msg");
        X11Diagnosis d = fromCause(kv.get("cause"), kv, r.error);
        if (d.cause == Cause.UNKNOWN) return other("Onarım başarısız", msg != null ? msg : r.error);
        return d;
    }

    private static X11Diagnosis fromCause(String c, Map<String, String> kv, String fallback) {
        if (c == null) c = "";
        if (c.equals("none")) return new X11Diagnosis(Cause.NONE, "X11 hazır", "", false);
        if (c.equals("no_pgrep")) {
            return new X11Diagnosis(Cause.NO_PGREP, "procps paketi eksik",
                    "Süreçleri izlemek için gereken 'procps' paketi kurulu değil. İnternet varsa X7 kurabilir.", true);
        }
        if (c.equals("no_xdpyinfo")) {
            return new X11Diagnosis(Cause.UNKNOWN, "X11 test aracı eksik",
                    "xdpyinfo kurulu değil. X7 onarımı bunu otomatik olarak kurabilir.", true);
        }
        if (c.equals("no_x11_app")) {
            return noX11App();
        }
        if (c.equals("no_pkg_x11")) {
            return new X11Diagnosis(Cause.NO_PKG_X11, "termux-x11 paketi eksik",
                    "Dahili Debian içinde termux-x11 paketi kurulu değil. İnternet varsa X7 yeniden kurabilir.", true);
        }
        if (c.equals("no_pkg_xfce")) {
            return new X11Diagnosis(Cause.NO_PKG_XFCE, "XFCE eksik",
                    "startxfce4 bulunamadı; XFCE paketleri eksik. İnternet varsa X7 yeniden kurabilir.", true);
        }
        if (c.equals("low_storage")) {
            return new X11Diagnosis(Cause.LOW_STORAGE, "Depolama yetersiz",
                    "Boş alan kritik derecede az (" + kv.get("free_mb") + " MB). Yer açıp tekrar dene.", false);
        }
        if (c.equals("stale_socket")) {
            return new X11Diagnosis(Cause.STALE_SOCKET, "Eski X11 soket dosyası",
                    "Önceki oturumdan kalan soket dosyası sunucunun açılmasını engelliyor olabilir. Temizlenebilir.",
                    true);
        }
        if (c.equals("no_socket")) {
            return new X11Diagnosis(Cause.NO_SOCKET, "X11 soketi yok",
                    "X sunucusu çalışıyor ama DISPLAY :1 soketi yok; bağlantı kurulamaz. "
                    + "Sunucu temizlenip yeniden başlatılabilir.", true);
        }
        if (c.equals("no_conn")) {
            return new X11Diagnosis(Cause.NO_CONN, "X11 bağlantısı kurulamadı",
                    "X sunucusu çalışıyor ama DISPLAY=:1 yanıt vermiyor. Sunucu temizlenip yeniden başlatılabilir.",
                    true);
        }
        if (c.equals("no_net")) {
            return new X11Diagnosis(Cause.NO_NET, "İnternet yok",
                    "Eksik paketleri indirmek için internet bağlantısı gerekiyor.", false);
        }
        if (c.equals("repo")) {
            return new X11Diagnosis(Cause.REPO, "Paket deposuna ulaşılamadı",
                    "Depo güncellenemedi. Biraz sonra tekrar dene.", false);
        }
        if (c.equals("pkg_fail")) {
            return new X11Diagnosis(Cause.PKG_FAIL, "Paket kurulumu başarısız",
                    "Eksik paketler kurulamadı. Teknik Ayrıntılar'a bak.", false);
        }
        return new X11Diagnosis(Cause.UNKNOWN, "X11 durumu belirsiz",
                fallback == null || fallback.length() == 0 ? "Script anlaşılır bir neden döndürmedi." : fallback,
                false);
    }
}
