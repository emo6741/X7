package com.x7.desktop.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Kütüphanesiz çizgi ikonlar (24x24 birim kutuda Canvas ile çizilir). */
public final class IconView extends View {
    public enum Type {
        HOME, DESKTOP, PALETTE, PACKAGE, WRENCH, GEAR, CHECK, PLAY, INFO, BULB,
        CHEVRON, CLOSE, CHART, TERMINAL, XMARK, CPU, RAM, DISK, WARN, STOP
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();
    private Type type;
    private int color;

    public IconView(Context c, Type t, int color) {
        super(c);
        this.type = t;
        this.color = color;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setColor(int c) { color = c; invalidate(); }

    public void setType(Type t) { type = t; invalidate(); }

    private void stroke() { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.9f); }

    private void fill() { p.setStyle(Paint.Style.FILL); }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h);
        if (s <= 0) return;
        cv.save();
        cv.translate((w - s) / 2f, (h - s) / 2f);
        float u = s / 24f;
        cv.scale(u, u);
        p.setColor(color);
        path.reset();
        switch (type) {
            case HOME:
                stroke();
                path.moveTo(3, 11); path.lineTo(12, 3); path.lineTo(21, 11);
                cv.drawPath(path, p);
                path.reset();
                path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20); path.lineTo(10, 20);
                path.lineTo(10, 14); path.lineTo(14, 14); path.lineTo(14, 20);
                path.lineTo(18.5f, 20); path.lineTo(18.5f, 9.5f);
                cv.drawPath(path, p);
                break;
            case DESKTOP:
                stroke();
                r.set(3, 4, 21, 16);
                cv.drawRoundRect(r, 2.2f, 2.2f, p);
                cv.drawLine(8, 20, 16, 20, p);
                cv.drawLine(12, 16, 12, 20, p);
                break;
            case PALETTE:
                stroke();
                cv.drawCircle(12, 12, 9, p);
                fill();
                cv.drawCircle(8, 10.5f, 1.3f, p);
                cv.drawCircle(12, 7.5f, 1.3f, p);
                cv.drawCircle(16, 10.5f, 1.3f, p);
                cv.drawCircle(8.8f, 15, 1.3f, p);
                break;
            case PACKAGE:
                stroke();
                path.moveTo(4, 8); path.lineTo(12, 4); path.lineTo(20, 8); path.lineTo(12, 12); path.close();
                cv.drawPath(path, p);
                cv.drawLine(4, 8, 4, 17, p); cv.drawLine(4, 17, 12, 21, p);
                cv.drawLine(12, 12, 12, 21, p); cv.drawLine(20, 8, 20, 17, p); cv.drawLine(20, 17, 12, 21, p);
                break;
            case WRENCH:
                stroke();
                cv.drawLine(4.5f, 19.5f, 13, 11, p);
                cv.drawCircle(16.5f, 7.5f, 4f, p);
                break;
            case GEAR:
                stroke();
                cv.drawCircle(12, 12, 3.2f, p);
                cv.drawCircle(12, 12, 7f, p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float c = (float) Math.cos(a), sn = (float) Math.sin(a);
                    cv.drawLine(12 + c * 7f, 12 + sn * 7f, 12 + c * 9.6f, 12 + sn * 9.6f, p);
                }
                break;
            case CHECK:
                stroke();
                p.setStrokeWidth(2.6f);
                path.moveTo(5, 12.5f); path.lineTo(10, 17.5f); path.lineTo(19, 7);
                cv.drawPath(path, p);
                break;
            case PLAY:
                fill();
                path.moveTo(7, 4); path.lineTo(20, 12); path.lineTo(7, 20); path.close();
                cv.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f);
                cv.drawPath(path, p);
                break;
            case STOP:
                fill();
                r.set(6, 6, 18, 18);
                cv.drawRoundRect(r, 2.5f, 2.5f, p);
                break;
            case INFO:
                stroke();
                cv.drawCircle(12, 12, 10, p);
                cv.drawLine(12, 11, 12, 17, p);
                fill();
                cv.drawCircle(12, 7.6f, 1.3f, p);
                break;
            case WARN:
                stroke();
                path.moveTo(12, 3.5f); path.lineTo(21.5f, 20); path.lineTo(2.5f, 20); path.close();
                cv.drawPath(path, p);
                cv.drawLine(12, 9.5f, 12, 14.5f, p);
                fill();
                cv.drawCircle(12, 17.4f, 1.2f, p);
                break;
            case BULB:
                stroke();
                cv.drawCircle(12, 10, 6f, p);
                cv.drawLine(9.5f, 18, 14.5f, 18, p);
                cv.drawLine(10.2f, 21, 13.8f, 21, p);
                break;
            case CHEVRON:
                stroke();
                path.moveTo(9, 5); path.lineTo(16, 12); path.lineTo(9, 19);
                cv.drawPath(path, p);
                break;
            case CLOSE:
                stroke();
                cv.drawLine(6, 6, 18, 18, p);
                cv.drawLine(18, 6, 6, 18, p);
                break;
            case XMARK:
                stroke();
                p.setStrokeWidth(2.8f);
                cv.drawLine(5, 4, 19, 20, p);
                cv.drawLine(19, 4, 5, 20, p);
                break;
            case CHART:
                fill();
                r.set(4, 12, 8, 20); cv.drawRoundRect(r, 1.4f, 1.4f, p);
                r.set(10, 5, 14, 20); cv.drawRoundRect(r, 1.4f, 1.4f, p);
                r.set(16, 9, 20, 20); cv.drawRoundRect(r, 1.4f, 1.4f, p);
                break;
            case TERMINAL:
                stroke();
                p.setStrokeWidth(2.3f);
                path.moveTo(5, 7); path.lineTo(11, 12); path.lineTo(5, 17);
                cv.drawPath(path, p);
                cv.drawLine(13, 17.5f, 19.5f, 17.5f, p);
                break;
            case CPU:
                stroke();
                r.set(6, 6, 18, 18);
                cv.drawRoundRect(r, 2f, 2f, p);
                r.set(9.7f, 9.7f, 14.3f, 14.3f);
                cv.drawRect(r, p);
                for (int i = 0; i < 3; i++) {
                    float x = 9 + i * 3f;
                    cv.drawLine(x, 3, x, 6, p);
                    cv.drawLine(x, 18, x, 21, p);
                    cv.drawLine(3, x, 6, x, p);
                    cv.drawLine(18, x, 21, x, p);
                }
                break;
            case RAM:
                stroke();
                r.set(3, 7, 21, 16);
                cv.drawRoundRect(r, 1.8f, 1.8f, p);
                for (int i = 0; i < 4; i++) {
                    float x = 7 + i * 3.4f;
                    cv.drawLine(x, 10.2f, x, 12.8f, p);
                }
                cv.drawLine(6, 16, 6, 19, p);
                cv.drawLine(18, 16, 18, 19, p);
                break;
            case DISK:
                stroke();
                r.set(4, 6, 20, 18);
                cv.drawRoundRect(r, 2.5f, 2.5f, p);
                cv.drawLine(4, 14, 20, 14, p);
                fill();
                cv.drawCircle(16.5f, 16.1f, 1f, p);
                break;
            default:
                break;
        }
        cv.restore();
    }
}
