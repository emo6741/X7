package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.RepairManager;
import com.x7.desktop.backend.RepairManager.Area;
import com.x7.desktop.backend.RepairManager.Finding;
import com.x7.desktop.backend.RepairManager.Level;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.TermuxRunner;

/**
 * Repair sekmesi (Aşama 9). Açılışta hiçbir şey çalıştırmaz: kontrol ve onarım yalnızca
 * düğmeyle başlar. Her alan: gerçek son sonuç + [Kontrol Et] + (varsa) [Onar].
 */
public final class RepairPage {
    private RepairPage() {}

    /** Sıra: ekranda görünen kart sırası. */
    private static final Area[] ORDER = {Area.TERMUX, Area.X11, Area.XFCE, Area.KDE, Area.PACKAGES, Area.THEME, Area.STARTUP};

    private static String repairLabel(Area a) {
        switch (a) {
            case X11: return "🔧 X11 Onar";
            case XFCE: return "🔧 XFCE Onar";
            case KDE: return "🔧 KDE Plasma Onar";
            case THEME: return "🔧 Tema Onar";
            case PACKAGES: return "🔧 Eksik Paketleri Kur";
            case STARTUP: return "🔧 Başlangıç Scriptini Onar";
            default: return "";
        }
    }

    private static String checkLabel(Area a) {
        switch (a) {
            case TERMUX: return "Dahili Debian Kontrolü";
            case PACKAGES: return "Paketleri Kontrol Et";
            default: return "Kontrol Et";
        }
    }

    private static String icon(Finding f) {
        if (f == null) return "·";
        switch (f.level) {
            case OK: return "✓";
            case WARN: return "⚠";
            case FAIL: return "✗";
            default: return "–";
        }
    }

    public static View build(final Ui ui, final MainActivity act) {
        final RepairManager rm = RepairManager.get(act);
        rm.setListener(new RepairManager.Listener() {
            @Override public void onChanged() { act.refresh(); }
        });
        final DesktopController dc = DesktopController.get(act);
        final boolean busy = rm.isBusy();
        final boolean blocked = rm.otherBusy();
        final boolean off = busy || blocked;

        LinearLayout col = ui.column();
        col.addView(ui.text("Onarım", 28, ui.text, true));
        col.addView(ui.text("Önce kontrol edilir; onarım yalnızca bulunan gerçek sorunlar için çalışır. "
                + "Açılışta otomatik bir şey yapılmaz.", 14, ui.sub, false));
        col.addView(new View(act), new LinearLayout.LayoutParams(1, ui.dp(12)));

        // --- Genel kart ---
        LinearLayout top = ui.addCard(col);
        top.addView(ui.text("Sistem Onarımı", 18, ui.text, true));
        if (busy) {
            TextView b = ui.addButton(top, "⟳ " + (rm.getProgress().length() > 0 ? rm.getProgress() : "Çalışıyor..."),
                    true, null);
            b.setEnabled(false);
            b.setAlpha(0.45f);
        } else if (blocked) {
            note(ui, top, "Masaüstü veya tema işlemi sürüyor. Bitince tekrar dene.");
        } else {
            ui.addButton(top, "🔍 Tam Sistem Kontrolü", true, new View.OnClickListener() {
                @Override public void onClick(View v) { rm.checkAll(); }
            });
            if (rm.hasResults() && rm.anyFixable()) {
                ui.addButton(top, "🔧 Otomatik Onar", true, new View.OnClickListener() {
                    @Override public void onClick(View v) { confirmAuto(act, rm, dc); }
                });
            }
        }
        if (rm.getNote().length() > 0 && !busy) {
            TextView n = ui.text(rm.getNote(), 14, ui.text, true);
            n.setPadding(0, ui.dp(10), 0, 0);
            top.addView(n);
        }
        if (dc.getStatus() == DesktopController.Status.RUNNING) {
            note(ui, top, "Masaüstü çalışıyor. X11 onarımı çalışan oturumu kapatır.");
        }

        // --- Alan kartları ---
        for (final Area a : ORDER) {
            Finding f = rm.getFinding(a);
            LinearLayout c = ui.addCard(col);
            c.addView(ui.text(icon(f) + "  " + RepairManager.areaName(a), 18, ui.text, true));
            if (f == null) {
                note(ui, c, "Henüz kontrol edilmedi.");
            } else {
                TextView t = ui.text(f.title, 15, ui.text, false);
                t.setPadding(0, ui.dp(6), 0, 0);
                c.addView(t);
                if (f.detail.length() > 0) note(ui, c, f.detail);
            }

            if (a == Area.TERMUX) {
                addRuntimeExtras(ui, act, c);
            }
            if (!off) {
                ui.addButton(c, checkLabel(a), false, new View.OnClickListener() {
                    @Override public void onClick(View v) { rm.check(a); }
                });
                if (a != Area.TERMUX) {
                    ui.addButton(c, repairLabel(a), true, new View.OnClickListener() {
                        @Override public void onClick(View v) { onRepair(act, rm, dc, a); }
                    });
                }
            }
        }

        // --- Teknik ayrıntılar ---
        LinearLayout tech = ui.addCard(col);
        tech.addView(ui.text("Teknik Ayrıntılar", 17, ui.text, true));
        note(ui, tech, "Çalıştırılan Repair komutlarının çıkışı (son işlem).");
        ui.addButton(tech, "Teknik Ayrıntılar", false, new View.OnClickListener() {
            @Override public void onClick(View v) { showDetails(act, rm); }
        });
        return ui.scroll(col);
    }

    private static void note(Ui ui, LinearLayout c, String s) {
        TextView n = ui.text(s, 13, ui.sub, false);
        n.setPadding(0, ui.dp(6), 0, 0);
        c.addView(n);
    }

    private static void addRuntimeExtras(final Ui ui, final MainActivity act, LinearLayout c) {
        if (TermuxDetector.check(act, TermuxDetector.TERMUX).installed && !TermuxRunner.hasPermission(act)) {
            ui.addButton(c, "İzni İste", true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    act.requestPermissions(new String[]{TermuxRunner.PERMISSION}, 1);
                }
            });
        }
        if (TermuxDetector.check(act, TermuxDetector.TERMUX).installed) {
            ui.addButton(c, "Dahili Debian'u Aç", false, new View.OnClickListener() {
                @Override public void onClick(View v) { TermuxDetector.open(act, TermuxDetector.TERMUX); }
            });
        }
    }

    private static void onRepair(final MainActivity act, final RepairManager rm,
                                 final DesktopController dc, final Area a) {
        if (a == Area.X11 && dc.getStatus() == DesktopController.Status.RUNNING) {
            new AlertDialog.Builder(act)
                    .setTitle("X11 onarılsın mı?")
                    .setMessage("Masaüstü çalışıyor. X11 onarımı takılı süreçleri ve eski soket dosyalarını "
                            + "temizler; çalışan oturum kapanır, kaydedilmemiş işler kaybolabilir.")
                    .setNegativeButton("Vazgeç", null)
                    .setPositiveButton("Onar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { rm.repair(Area.X11); }
                    })
                    .show();
            return;
        }
        rm.repair(a);
    }

    private static void confirmAuto(final MainActivity act, final RepairManager rm, final DesktopController dc) {
        String running = dc.getStatus() == DesktopController.Status.RUNNING
                ? "\n\nMasaüstü çalışıyor: X11 onarımı gerekirse oturum kapanır." : "";
        new AlertDialog.Builder(act)
                .setTitle("Otomatik Onar")
                .setMessage("Önce her şey yeniden kontrol edilir. Bulunan sorunlar için eksik scriptler yazılır, "
                        + "eksik paketler indirilir (internet gerekir), tema dosyaları kopyalanır ve gerekirse "
                        + "X11 temizlenir. Sorun bulunmayan hiçbir şeye dokunulmaz." + running)
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Onar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { rm.autoRepair(); }
                })
                .show();
    }

    private static void showDetails(MainActivity act, RepairManager rm) {
        String text = rm.getDetails().length() == 0
                ? "Henüz bir Repair komutu çalıştırılmadı." : rm.getDetails();
        TextView t = new TextView(act);
        t.setText(text);
        t.setTextSize(12);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setPadding(48, 24, 48, 24);
        ScrollView sv = new ScrollView(act);
        sv.addView(t);
        new AlertDialog.Builder(act)
                .setTitle("Teknik Ayrıntılar")
                .setView(sv)
                .setPositiveButton("Kapat", null)
                .show();
    }
}
