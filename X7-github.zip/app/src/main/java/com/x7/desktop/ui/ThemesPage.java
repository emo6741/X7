package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.theme.ThemeInfo;
import com.x7.desktop.theme.ThemeManager;
import java.util.ArrayList;
import java.util.List;

/** Fotoğraftaki Themes ekranının işlevsel karşılığı. */
public final class ThemesPage {
    private ThemesPage() {}

    public static View build(final Ui ui, final MainActivity act) {
        final ThemeManager tm = ThemeManager.get(act);
        tm.setListener(new ThemeManager.Listener() { @Override public void onChanged() { act.refresh(); } });
        final StateManager st = StateManager.load(act);
        final List<ThemeInfo> themes = new ArrayList<ThemeInfo>();
        for (ThemeInfo t : ThemeInfo.loadAll(act)) if ("xfce".equalsIgnoreCase(t.desktop)) themes.add(t);
        final String initial = st.themeApplied.length() > 0 ? st.themeApplied : "pure-xfce";
        final String[] selected = { initial };
        final java.util.ArrayList<TextView> radios = new java.util.ArrayList<TextView>();
        final java.util.ArrayList<String> radioIds = new java.util.ArrayList<String>();

        LinearLayout col=ui.column();
        LinearLayout head=new LinearLayout(ui.ctx); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView x=ui.text("X7",31,ui.accent,true); x.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD_ITALIC));
        head.addView(x,new LinearLayout.LayoutParams(ui.dp(42),-2));
        head.addView(ui.text("Temalar",21,ui.text,true)); col.addView(head);
        col.addView(ui.text("Uygulama temasını değiştir",13,ui.sub,false));
        col.addView(space(ui,8));

        for (final ThemeInfo t: themes) {
            LinearLayout card=ui.addCard(col); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(ui.dp(10),ui.dp(10),ui.dp(10),ui.dp(10));
            ImageView im=new ImageView(ui.ctx);
            int res="win7".equals(t.id)?com.x7.desktop.R.drawable.theme_win7:"win10".equals(t.id)?com.x7.desktop.R.drawable.theme_win10:com.x7.desktop.R.drawable.theme_pure_xfce;
            im.setImageResource(res); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setClipToOutline(true);
            GradientDrawableCompat.round(im,ui.dp(7));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(ui.dp(78),ui.dp(58)); ip.rightMargin=ui.dp(10); card.addView(im,ip);
            LinearLayout txt=new LinearLayout(ui.ctx); txt.setOrientation(LinearLayout.VERTICAL);
            txt.addView(ui.text(t.name,15,ui.text,true)); txt.addView(ui.text(t.description,10,ui.sub,false));
            card.addView(txt,new LinearLayout.LayoutParams(0,-2,1));
            TextView radio=ui.text(t.id.equals(selected[0])?"◉":"○",26,t.id.equals(selected[0])?ui.accent:ui.sub,false); radio.setGravity(Gravity.CENTER);
            card.addView(radio,new LinearLayout.LayoutParams(ui.dp(34),-1));
            radios.add(radio); radioIds.add(t.id);
            card.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
                selected[0]=t.id;
                for(int i=0;i<radios.size();i++){ boolean on=radioIds.get(i).equals(selected[0]); radios.get(i).setText(on?"◉":"○"); radios.get(i).setTextColor(on?ui.accent:ui.sub); }
            }});
            ui.pressable(card);
        }
        if (themes.isEmpty()) { LinearLayout c=ui.addCard(col); c.addView(ui.text("Tema bulunamadı",16,ui.text,true)); }
        ui.addButton(col,"🎨 Temayı Uygula",true,new View.OnClickListener(){ public void onClick(View v){
            ThemeInfo chosen=null; for(ThemeInfo t:themes) if(t.id.equals(selected[0])) chosen=t;
            if(chosen!=null) confirmApply(ui,act,tm,chosen);
        }});
        if (tm.getLevel()!=ThemeManager.Level.NONE && tm.getResultText().length()>0) {
            LinearLayout c=ui.addCard(col); c.addView(ui.text(tm.getResultText(),13,ui.text,true));
            if(tm.getDetails().length()>0)c.addView(ui.text(tm.getDetails(),11,ui.sub,false));
        }
        return ui.scroll(col);
    }
    private static View space(Ui ui,int d){ View v=new View(ui.ctx); v.setLayoutParams(new LinearLayout.LayoutParams(1,ui.dp(d))); return v; }
    private static void confirmApply(Ui ui, MainActivity act, final ThemeManager tm, final ThemeInfo t){
        new AlertDialog.Builder(act).setTitle(t.name+" uygulansın mı?").setMessage("Mevcut XFCE ayarları yedeklenir; tema dosyaları Dahili Debian'a gerçek komutlarla kopyalanır ve duvar kağıdı uygulanır.")
            .setNegativeButton("Vazgeç",null).setPositiveButton("Uygula",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){tm.apply(t.id);}}).show();
    }
    private static final class GradientDrawableCompat {
        static void round(ImageView v,int r){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(0x00000000); g.setCornerRadius(r); v.setBackground(g); }
    }
}
