package com.x7.desktop.backend;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import org.json.JSONObject;

/** Kurulum/çalışma durumunu ve tamamlanan adımları (checkpoint) status.json'da tutar. */
public final class StateManager {
    public enum InstallState {
        NOT_STARTED, DOWNLOADING, INSTALLING, CONFIGURING, VERIFYING, COMPLETED, FAILED
    }

    public InstallState installState = InstallState.NOT_STARTED;
    public String desktop = "XFCE";
    public String display = "Dahili Debian:X11";
    public String vncResolution = "1280x720";
    public String theme = "Windows 7";
    public String themeApplied = ""; // gerçekten uygulanmış tema kimliği (boş = yok)
    public String lastError = "";
    public String failedStep = "";
    public String stepsDone = ""; // "repo,xfce,..."

    private final File file;

    private StateManager(File f) { file = f; }

    public static StateManager load(Context c) {
        StateManager s = new StateManager(new File(c.getFilesDir(), "status.json"));
        try {
            if (s.file.exists()) {
                FileInputStream in = new FileInputStream(s.file);
                byte[] buf = new byte[(int) s.file.length()];
                int off = 0;
                while (off < buf.length) {
                    int n = in.read(buf, off, buf.length - off);
                    if (n < 0) break;
                    off += n;
                }
                in.close();
                JSONObject j = new JSONObject(new String(buf, 0, off, "UTF-8"));
                s.installState = InstallState.valueOf(j.optString("installed", "NOT_STARTED"));
                s.desktop = j.optString("desktop", s.desktop);
                s.display = j.optString("display", s.display);
                s.vncResolution = j.optString("vnc_resolution", s.vncResolution);
                s.theme = j.optString("theme", s.theme);
                s.themeApplied = j.optString("theme_applied", "");
                s.lastError = j.optString("last_error", "");
                s.failedStep = j.optString("failed_step", "");
                s.stepsDone = j.optString("steps_done", "");
            }
        } catch (Exception e) {
            LogManager.warn("STATE", "status.json okunamadı, varsayılanlar kullanılıyor.");
        }
        return s;
    }

    public void save() {
        try {
            JSONObject j = new JSONObject();
            j.put("installed", installState.name());
            j.put("desktop", desktop);
            j.put("display", display);
            j.put("vnc_resolution", vncResolution);
            j.put("theme", theme);
            j.put("theme_applied", themeApplied);
            j.put("last_error", lastError);
            j.put("failed_step", failedStep);
            j.put("steps_done", stepsDone);
            FileWriter w = new FileWriter(file, false);
            try { w.write(j.toString()); } finally { w.close(); }
        } catch (Exception e) {
            LogManager.error("STATE", "status.json yazılamadı: " + e.getMessage());
        }
    }

    public boolean isDone(String step) {
        for (String s : stepsDone.split(",")) if (s.equals(step)) return true;
        return false;
    }

    public void markDone(String step) {
        if (!isDone(step)) stepsDone = stepsDone.length() == 0 ? step : stepsDone + "," + step;
        save();
    }

    public void setDesktop(String value) {
        if (!"XFCE".equals(value) && !"KDE Plasma".equals(value)) return;
        desktop = value;
        if ("KDE Plasma".equals(value)) { theme = "None"; themeApplied = ""; }
        save();
    }

    public void setDisplay(String value) {
        if (!"Dahili Debian:X11".equals(value) && !"VNC".equals(value)) return;
        display = value;
        save();
    }

    public void setVncResolution(String value) {
        if (!"1280x720".equals(value) && !"1600x900".equals(value) && !"1920x1080".equals(value)) return;
        vncResolution = value;
        save();
    }

    public void setFailed(String step, String error) {
        installState = InstallState.FAILED;
        failedStep = step;
        lastError = error;
        save();
    }

    /** "Baştan Kur": ilerlemeyi sıfırlar. */
    public void resetProgress() {
        installState = InstallState.NOT_STARTED;
        stepsDone = "";
        lastError = "";
        failedStep = "";
        save();
    }
}
