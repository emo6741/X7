package com.x7.desktop.backend;

import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import java.util.Map;

/**
 * Masaüstünü başlatır/durdurur/yeniden başlatır, durumunu okur, X11 sorunlarını onarır.
 * Gerçek iş Dahili Debian'taki x7-start / x7-stop / x7-status / x7-x11check / x7-x11repair
 * scriptlerinde yapılır.
 *
 * Aşama 7: başlatma en fazla 3 kez denenir. X sunucusu veya XFCE oturumu açılamazsa
 * (x7-start çıkış kodu 3/4) her denemeden önce x7-x11repair temizliği çalışır. Hâlâ başarısızsa
 * x7-x11check ile GERÇEK neden bulunur ve kullanıcıya X11Diagnosis olarak gösterilir.
 */
public final class DesktopController {
    public enum Status { UNKNOWN, STOPPED, STARTING, RUNNING, STOPPING, REPAIRING, ERROR }

    public interface Listener { void onChanged(); }

    public interface CheckCallback { void onDone(X11Diagnosis d, CommandResult r); }

    private static final long SCRIPT_TIMEOUT_MS = 30000;
    private static final long START_TIMEOUT_MS = 60000;
    private static final long REPAIR_TIMEOUT_MS = 15 * 60000; // paket kurulumu uzun sürebilir
    private static final int MAX_ATTEMPTS = 3;
    private static DesktopController instance;

    private final Context app;
    private Status status = Status.UNKNOWN;
    private String message = "";
    private String progress = "";   // "X11 başlatılıyor... Deneme 2/3" gibi anlık durum
    private String notice = "";     // başarı/bilgi notu (hata değil)
    private String details = "";    // "Teknik Ayrıntılar": script çıktıları
    private X11Diagnosis diagnosis; // null değilse X11 hata kartı gösterilir
    private Listener listener;
    private boolean operating = false;
    private boolean refreshing = false;

    private DesktopController(Context app) { this.app = app; }

    public static DesktopController get(Context c) {
        if (instance == null) instance = new DesktopController(c.getApplicationContext());
        return instance;
    }

    public Status getStatus() { return status; }
    public String getMessage() { return message; }
    public String getProgress() { return progress; }
    public String getNotice() { return notice; }
    public String getDetails() { return details; }
    public X11Diagnosis getDiagnosis() { return diagnosis; }
    public void setListener(Listener l) { listener = l; }

    private void changed() {
        Listener l = listener;
        if (l != null) l.onChanged();
    }

    private boolean ready() {
        return TermuxDetector.check(app, TermuxDetector.TERMUX).installed
                && TermuxRunner.hasPermission(app);
    }

    /** Dahili Debian'tan gerçek durumu okur. Script henüz yoksa masaüstü çalışmıyordur (STOPPED). */
    public void refresh() {
        if (operating || refreshing || !ready()) return;
        // Kullanıcı kapatana kadar X11 hata kartı yerinde kalır (uygulamaya dönünce kaybolmasın).
        if (status == Status.ERROR && diagnosis != null) return;
        refreshing = true;
        TermuxRunner.run(app, CommandBuilder.Id.DESKTOP_STATUS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                refreshing = false;
                if (operating) return; // sonuç eskidi
                String s = r.keyValues().get("state");
                if (r.ok && "running".equals(s)) { status = Status.RUNNING; message = ""; notice = ""; }
                else if (r.ok && "stopped".equals(s)) { status = Status.STOPPED; message = ""; }
                else if (r.exitCode == 127) { status = Status.STOPPED; message = ""; }
                else { status = Status.UNKNOWN; message = r.error; }
                changed();
            }
        });
    }

    // ------------------------------------------------------------------ başlat

    public void start() {
        if (operating) return;
        if (StateManager.load(app).installState != StateManager.InstallState.COMPLETED) {
            fail("Önce kurulumu tamamla.");
            return;
        }
        if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
        final StateManager selected = StateManager.load(app);
        if ("VNC".equals(selected.display)) {
            startVnc(selected.vncResolution);
            return;
        }
        operating = true;
        status = Status.STARTING;
        message = "";
        notice = "";
        details = "";
        diagnosis = null;
        progress = "Masaüstü başlatılıyor...";
        LogManager.info("DESK", "Masaüstü başlatılıyor");
        changed();
        // Scriptleri her başlatmada güncelle: ucuz ve idempotent.
        TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SCRIPT_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) { operating = false; fail("Scriptler kurulamadı: " + r.error); return; }
                attempt(1);
            }
        });
    }

    /** n. başlatma denemesi. Yalnızca X sunucusu/XFCE açılamazsa (kod 3/4) temizleyip tekrar dener. */
    private void attempt(final int n) {
        progress = "X11 başlatılıyor... Deneme " + n + "/" + MAX_ATTEMPTS;
        LogManager.info("X11", progress);
        changed();
        TermuxRunner.run(app, CommandBuilder.desktopStart(selectedDesktopForVnc()), START_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                Map<String, String> kv = r.keyValues();
                if (r.ok && "running".equals(kv.get("state"))) { finishStart(r); return; }
                String msg = kv.get("msg") != null ? kv.get("msg") : r.error;
                LogManager.warn("X11", "Deneme " + n + "/" + MAX_ATTEMPTS + " başarısız: " + msg);
                boolean retryable = r.exitCode == 3 || r.exitCode == 4;
                if (retryable && n < MAX_ATTEMPTS) {
                    progress = "Deneme " + n + "/" + MAX_ATTEMPTS + " başarısız. Temizleniyor...";
                    changed();
                    final int next = n + 1;
                    TermuxRunner.run(app, CommandBuilder.Id.X11_CLEAN, SCRIPT_TIMEOUT_MS,
                            new TermuxRunner.Callback() {
                        @Override public void onResult(CommandResult c) {
                            if (c.exitCode == -1) { diagnoseStartFailure(c, c.error); return; }
                            attempt(next);
                        }
                    });
                } else {
                    diagnoseStartFailure(r, msg);
                }
            }
        });
    }

    /** Denemeler bitti: x7-x11check ile gerçek nedeni bul ve hata kartını hazırla. */
    private void diagnoseStartFailure(CommandResult startRes, String startMsg) {
        final String sm = startMsg;
        details = "x7-start: exit=" + startRes.exitCode + "\n" + startRes.stdout
                + (startRes.stderr.length() > 0 ? "stderr: " + startRes.stderr + "\n" : "");
        if (startRes.exitCode == -1) { // Dahili Debian'a hiç ulaşılamadı
            failX11(X11Diagnosis.unreachable(startRes.error), details);
            return;
        }
        progress = "Neden aranıyor...";
        changed();
        runCheck(false, new CheckCallback() {
            @Override public void onDone(X11Diagnosis d, CommandResult r) {
                details = details + "\nx7-x11check: exit=" + r.exitCode + "\n" + r.stdout;
                X11Diagnosis shown = d.cause == X11Diagnosis.Cause.NONE ? X11Diagnosis.unknown(sm) : d;
                failX11(shown, details);
            }
        });
    }

    private void finishStart(CommandResult r) {
        operating = false;
        progress = "";
        diagnosis = null;
        String msg = r.keyValues().get("msg");
        status = Status.RUNNING;
        message = "";
        LogManager.info("DESK", "Masaüstü çalışıyor: " + msg);
        if ("Dahili Debian:X11".equals(StateManager.load(app).display)) { TermuxDetector.open(app, TermuxDetector.X11); } // VNC harici viewer gerektirir
        changed();
    }

    // ------------------------------------------------------------ VNC

    private static String portOr(String p) { return (p == null || p.length() == 0) ? "5901" : p; }

    private String selectedDesktopForVnc() { return StateManager.load(app).desktop; }

    private void startVnc(final String resolution) {
        operating = true;
        status = Status.STARTING;
        message = "";
        notice = "";
        details = "";
        diagnosis = null;
        progress = "VNC başlatılıyor...";
        LogManager.info("VNC", "VNC başlatılıyor: " + resolution);
        changed();
        TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SCRIPT_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) { operating = false; fail("VNC scripti kurulamadı: " + r.error); return; }
                TermuxRunner.run(app, CommandBuilder.vncStart(resolution, selectedDesktopForVnc()), START_TIMEOUT_MS,
                        new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult vr) {
                        operating = false;
                        details = "x7-vnc: exit=" + vr.exitCode + "\n" + vr.stdout;
                        if (vr.ok && "running".equals(vr.keyValues().get("state"))) {
                            status = Status.RUNNING;
                            message = "";
                            progress = "";
                            notice = "✓ VNC çalışıyor: 127.0.0.1:" + portOr(vr.keyValues().get("port"));
                            LogManager.info("VNC", notice);
                        } else {
                            status = Status.ERROR;
                            progress = "";
                            message = vr.error.length() > 0 ? vr.error : "VNC başlatılamadı.";
                            LogManager.error("VNC", message);
                        }
                        changed();
                    }
                });
            }
        });
    }

    public void setupVnc(final Runnable done) {
        if (operating) return;
        if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
        operating = true;
        status = Status.STARTING;
        progress = "VNC hazırlanıyor...";
        changed();
        TermuxRunner.run(app, CommandBuilder.Id.VNC_INSTALL, REPAIR_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) { operating = false; fail("TigerVNC kurulamadı: " + r.error); return; }
                TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SCRIPT_TIMEOUT_MS,
                        new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult ir) {
                        if (!ir.ok) { operating = false; fail("VNC scripti kurulamadı: " + ir.error); return; }
                        TermuxRunner.run(app, CommandBuilder.vncSetup(StateManager.load(app).desktop), SCRIPT_TIMEOUT_MS,
                                new TermuxRunner.Callback() {
                            @Override public void onResult(CommandResult sr) {
                                operating = false; progress = "";
                                if (!sr.ok) { fail("VNC yapılandırılamadı: " + sr.error); return; }
                                StateManager st = StateManager.load(app);
                                st.setDisplay("VNC");
                                st.display = "VNC";
                                st.save();
                                LogManager.info("VNC", "VNC hazırlandı");
                                if (done != null) done.run();
                                changed();
                            }
                        });
                    }
                });
            }
        });
    }

    public void stopVnc(final boolean force) {
        if (operating) return;
        if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
        operating = true;
        status = Status.STOPPING;
        progress = "VNC durduruluyor...";
        changed();
        TermuxRunner.run(app, force ? CommandBuilder.Id.VNC_FORCE_STOP : CommandBuilder.Id.VNC_STOP,
                SCRIPT_TIMEOUT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                operating = false; progress = "";
                if (r.ok) { status = Status.STOPPED; message = ""; notice = "VNC durduruldu."; }
                else { status = Status.ERROR; message = r.error; }
                changed();
            }
        });
    }

    // ------------------------------------------------------------ X11 kontrol / onarım

    /**
     * Salt-okunur X11 kontrolü (Settings > X11 Kontrolü). Durumu değiştirmez.
     * Masaüstü işlemi sürerken çalışmaz: script dosyaları o sırada yeniden yazılmamalı.
     */
    public void checkX11(CheckCallback cb) {
        if (operating) {
            cb.onDone(X11Diagnosis.other("Meşgul", "Masaüstü işlemi sürerken kontrol yapılamaz."),
                    CommandResult.failure("meşgul"));
            return;
        }
        if (!ready()) {
            String m = "Dahili Debian kurulu değil veya komut izni verilmedi.";
            cb.onDone(X11Diagnosis.unreachable(m), CommandResult.failure(m));
            return;
        }
        runCheck(true, cb);
    }

    private void runCheck(boolean installScriptsFirst, final CheckCallback cb) {
        if (!installScriptsFirst) { doCheck(cb); return; }
        TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SCRIPT_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) {
                    cb.onDone(X11Diagnosis.unreachable("Scriptler kurulamadı: " + r.error), r);
                    return;
                }
                doCheck(cb);
            }
        });
    }

    private void doCheck(final CheckCallback cb) {
        TermuxRunner.run(app, CommandBuilder.Id.X11_CHECK, SCRIPT_TIMEOUT_MS,
                new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                cb.onDone(X11Diagnosis.fromCheck(r), r);
            }
        });
    }

    /** "Sorunu Çöz": kontrol -> temizlik + eksik paketler -> doğrulama. Masaüstünü başlatmaz. */
    public void repairX11() {
        if (operating) return;
        if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
        operating = true;
        status = Status.REPAIRING;
        message = "";
        notice = "";
        details = "";
        diagnosis = null;
        progress = "Ortam kontrol ediliyor...";
        LogManager.info("X11", "Onarım başlatıldı");
        changed();
        runCheck(true, new CheckCallback() {
            @Override public void onDone(X11Diagnosis d, CommandResult r) {
                details = "x7-x11check: exit=" + r.exitCode + "\n" + r.stdout;
                // Nedeni script'le giderilemiyorsa (depolama, X11 uygulaması...) boşuna uğraşma.
                if (!d.ok() && !d.fixable) { failX11(d, details); return; }
                progress = "Onarılıyor (temizlik ve eksik paketler)...";
                changed();
                TermuxRunner.run(app, CommandBuilder.Id.X11_REPAIR, REPAIR_TIMEOUT_MS,
                        new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult rr) {
                        details = details + "\nx7-x11repair: exit=" + rr.exitCode + "\n" + rr.stdout;
                        X11Diagnosis rd = X11Diagnosis.fromRepair(rr);
                        if (!rd.ok()) { failX11(rd, details); return; }
                        progress = "Doğrulanıyor...";
                        changed();
                        doCheck(new CheckCallback() {
                            @Override public void onDone(X11Diagnosis d2, CommandResult r2) {
                                details = details + "\nx7-x11check: exit=" + r2.exitCode + "\n" + r2.stdout;
                                if (d2.ok()) { repairDone(); } else { failX11(d2, details); }
                            }
                        });
                    }
                });
            }
        });
    }

    private void repairDone() {
        operating = false;
        progress = "";
        diagnosis = null;
        status = Status.STOPPED;
        message = "";
        notice = "✓ Onarım tamamlandı. Masaüstünü tekrar başlatabilirsin.";
        LogManager.info("X11", "Onarım tamamlandı");
        changed();
    }

    /** Hata kartını kapatır ("İptal") ve gerçek durumu yeniden okur. */
    public void dismissError() {
        if (operating) return;
        diagnosis = null;
        progress = "";
        message = "";
        status = Status.UNKNOWN;
        changed();
        refresh();
    }

    private void failX11(X11Diagnosis d, String det) {
        operating = false;
        progress = "";
        status = Status.ERROR;
        diagnosis = d;
        details = det;
        message = d.title + ". " + d.detail;
        LogManager.error("X11", d.cause + ": " + d.title);
        changed();
    }

    // ------------------------------------------------------------------ durdur

    public void stop(boolean force) { doStop(force, null); }

    /** Kontrollü durdur, sonra başlat. */
    public void restart() {
        doStop(false, new Runnable() {
            @Override public void run() { start(); }
        });
    }

    private void doStop(boolean force, final Runnable afterStopped) {
        if ("VNC".equals(StateManager.load(app).display)) {
            if (operating) return;
            if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
            operating = true;
            status = Status.STOPPING;
            progress = "VNC durduruluyor...";
            changed();
            TermuxRunner.run(app, force ? CommandBuilder.Id.VNC_FORCE_STOP : CommandBuilder.Id.VNC_STOP,
                    SCRIPT_TIMEOUT_MS, new TermuxRunner.Callback() {
                @Override public void onResult(CommandResult r) {
                    operating = false; progress = "";
                    if (!r.ok) { status = Status.ERROR; message = r.error; changed(); return; }
                    status = Status.STOPPED; message = ""; notice = "VNC durduruldu.";
                    changed();
                    if (afterStopped != null) afterStopped.run();
                }
            });
            return;
        }
        if (operating) return;
        if (!ready()) { fail("Dahili Debian kurulu değil veya komut izni verilmedi."); return; }
        operating = true;
        status = Status.STOPPING;
        message = "";
        notice = "";
        diagnosis = null;
        progress = "";
        LogManager.info("DESK", force ? "Masaüstü zorla durduruluyor" : "Masaüstü durduruluyor");
        changed();
        TermuxRunner.run(app, force ? CommandBuilder.Id.DESKTOP_FORCE_STOP : CommandBuilder.Id.DESKTOP_STOP,
                SCRIPT_TIMEOUT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                operating = false;
                Map<String, String> kv = r.keyValues();
                String s = kv.get("state");
                String msg = kv.get("msg");
                if ((r.ok && "stopped".equals(s)) || r.exitCode == 127) {
                    status = Status.STOPPED;
                    message = "";
                    LogManager.info("DESK", "Masaüstü durdu");
                    if (afterStopped != null) { afterStopped.run(); return; }
                    changed();
                } else if ("running".equals(s)) {
                    status = Status.RUNNING;
                    message = msg != null ? msg : "Masaüstü durmadı.";
                    LogManager.warn("DESK", message);
                    changed();
                } else {
                    fail(msg != null ? msg : r.error);
                }
            }
        });
    }

    private void fail(String msg) {
        status = Status.ERROR;
        message = msg;
        progress = "";
        diagnosis = null;
        LogManager.error("DESK", msg);
        changed();
    }
}
