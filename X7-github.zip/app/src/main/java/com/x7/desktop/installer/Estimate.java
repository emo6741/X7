package com.x7.desktop.installer;

import com.x7.desktop.backend.CommandResult;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** apt simülasyon çıktısından (apt-get -s) gerçek indirme/kurulum boyutunu okur. */
public final class Estimate {
    public final boolean ok;
    public final long downloadBytes;
    public final long installBytes;
    public final String error;

    private static final Pattern NEED = Pattern.compile("Need to get ([0-9.,]+) ?([kMG]?B)");
    private static final Pattern AFTER =
            Pattern.compile("After this operation, ([0-9.,]+) ?([kMG]?B) of additional");

    private Estimate(boolean ok, long dl, long inst, String error) {
        this.ok = ok; this.downloadBytes = dl; this.installBytes = inst; this.error = error;
    }

    private static Estimate fail(String msg) { return new Estimate(false, 0, 0, msg); }

    public static Estimate from(CommandResult r) {
        if (!r.ok) return fail(r.error);
        Map<String, String> kv = r.keyValues();
        if (!"ok".equals(kv.get("prep"))) {
            return fail("Paket deposuna ulaşılamadı veya depo güncellenemedi. İnterneti kontrol edip tekrar dene.");
        }
        String out = r.stdout;
        long dl = -1, inst = -1;
        Matcher n = NEED.matcher(out);
        if (n.find()) dl = toBytes(n.group(1), n.group(2));
        Matcher a = AFTER.matcher(out);
        if (a.find()) inst = toBytes(a.group(1), a.group(2));
        if (dl < 0 && inst < 0) {
            if (out.contains("0 newly installed")) return new Estimate(true, 0, 0, "");
            return fail("Boyut hesaplanamadı (apt çıktısı beklenen biçimde değil).");
        }
        if (dl < 0) dl = 0;
        if (inst < 0) inst = 0;
        return new Estimate(true, dl, inst, "");
    }

    private static long toBytes(String num, String unit) {
        try {
            double v = Double.parseDouble(num.replace(",", ""));
            double mul = 1;
            if (unit.equals("kB")) mul = 1000;
            else if (unit.equals("MB")) mul = 1000.0 * 1000;
            else if (unit.equals("GB")) mul = 1000.0 * 1000 * 1000;
            return (long) (v * mul);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
