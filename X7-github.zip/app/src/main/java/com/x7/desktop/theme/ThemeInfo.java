package com.x7.desktop.theme;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

/** assets/themes/<id>/theme.json içeriği. Tema sistemi hardcoded değildir: metadata dosyadan okunur. */
public final class ThemeInfo {
    public final String id;
    public final String name;
    public final String description;
    public final String desktop;
    public final String gtkTheme;
    public final String packages;

    private ThemeInfo(String id, String name, String desc, String desktop, String gtk, String pk) {
        this.id = id; this.name = name; this.description = desc;
        this.desktop = desktop; this.gtkTheme = gtk; this.packages = pk;
    }

    /** assets/themes altındaki bütün geçerli temaları döndürür. */
    public static List<ThemeInfo> loadAll(Context c) {
        List<ThemeInfo> out = new ArrayList<ThemeInfo>();
        try {
            String[] dirs = c.getAssets().list("themes");
            if (dirs == null) return out;
            for (String d : dirs) {
                try {
                    String json = read(c, "themes/" + d + "/theme.json");
                    JSONObject j = new JSONObject(json);
                    StringBuilder pk = new StringBuilder();
                    org.json.JSONArray a = j.optJSONArray("packages");
                    if (a != null) {
                        for (int i = 0; i < a.length(); i++) {
                            if (i > 0) pk.append(", ");
                            pk.append(a.optString(i));
                        }
                    }
                    out.add(new ThemeInfo(j.optString("id", d), j.optString("name", d),
                            j.optString("description", ""), j.optString("desktop", "xfce"),
                            j.optString("gtk_theme", ""), pk.toString()));
                } catch (Exception e) {
                    // theme.json'u olmayan/bozuk klasör atlanır
                }
            }
        } catch (IOException e) {
            // liste boş döner
        }
        return out;
    }

    private static String read(Context c, String path) throws IOException {
        InputStream in = c.getAssets().open(path);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally {
            in.close();
        }
    }
}
