package com.x7.desktop.backend;

import android.content.Context;
import com.x7.desktop.theme.ThemeInfo;
import com.x7.desktop.theme.ThemeManager;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Repair sistemi (Aşama 9). Gerçek işi Dahili Debian'taki scriptler yapar; burada yalnızca
 * sıra ve sonuç yorumu vardır. Hiçbir sonuç tahmin edilmez: script çıktısı okunamazsa
 * "başarısız" yazılır.
 *
 * Alanlar: Dahili Debian, X11, XFCE, Paketler, Tema, Başlangıç scriptleri.
 * check = salt-okunur. fix = yalnızca bulunan sorunu giderir. repair = check, sorun varsa fix.
 * Dahili Debian'ta x7-repair yoksa (ilk kullanım / silinmiş) scriptler bir kez yazılır ve komut tekrarlanır.
 */
public final class RepairManager {
    public interface Listener { void onChanged(); }

    public enum Area { TERMUX, X11, XFCE, KDE, PACKAGES, THEME, STARTUP }

    public enum Level { OK, WARN, FAIL, SKIP }

    /** Bir alanın son kontrol sonucu. */
    public static final class Finding {
        public final Level level;
        public final String title;
        public final String detail;
        /** Onar düğmesi bu sorunu giderebilir mi? */
        public final boolean fixable;

        Finding(Level level, String title, String detail, boolean fixable) {
            this.level = level;
            this.title = title;
            this.detail = detail == null ? "" : detail;
            this.fixable = fixable;
        }

        public boolean needsFix() { return level != Level.OK && level != Level.SKIP && fixable; }
    }

    private interface Done { void done(); }

    private static final long SHORT_MS = 30000;
    private static final long FIX_MS = 15L * 60 * 1000;
    private static final int MAX_DETAILS = 9000;
    private static final Area[] ALL = {Area.TERMUX, Area.X11, Area.XFCE, Area.KDE, Area.PACKAGES, Area.THEME, Area.STARTUP};
    /** Onarım sırası: önce scriptler ve paketler, en son (oturumu kapatabilen) X11. */
    private static final Area[] FIX_ORDER = {Area.STARTUP, Area.PACKAGES, Area.XFCE, Area.KDE, Area.THEME, Area.X11};

    private static RepairManager instance;

    private final Context app;
    private Listener listener;
    private boolean busy = false;
    private String progress = "";
    private String note = "";
    private final StringBuilder details = new StringBuilder();
    private final Map<Area, Finding> results = new EnumMap<Area, Finding>(Area.class);
    private boolean bootstrapped = false; // bu işlem sırasında scriptler Dahili Debian'a yazıldı mı

    private RepairManager(Context app) { this.app = app; }

    public static RepairManager get(Context c) {
        if (instance == null) instance = new RepairManager(c.getApplicationContext());
        return instance;
    }

    public void setListener(Listener l) { listener = l; }
    public boolean isBusy() { return busy; }
    public String getProgress() { return progress; }
    public String getNote() { return note; }
    public String getDetails() { return details.toString(); }
    public Finding getFinding(Area a) { return results.get(a); }
    public boolean hasResults() { return !results.isEmpty(); }

    public static String areaName(Area a) {
        switch (a) {
            case TERMUX: return "Dahili Debian";
            case X11: return "X11";
            case XFCE: return "XFCE";
            case KDE: return "KDE Plasma";
            case PACKAGES: return "Paketler";
            case THEME: return "Tema";
            default: return "Başlangıç scriptleri";
        }
    }

    /** Onarılacak bir şey var mı? (Otomatik Onar düğmesi için) */
    public boolean anyFixable() {
        for (Finding f : results.values()) if (f.needsFix()) return true;
        return false;
    }

    /** Masaüstü veya tema işlemi sürerken Repair başlatılmaz: aynı dosyalara aynı anda dokunulmasın. */
    public boolean otherBusy() {
        DesktopController.Status s = DesktopController.get(app).getStatus();
        return s == DesktopController.Status.STARTING || s == DesktopController.Status.STOPPING
                || s == DesktopController.Status.REPAIRING || ThemeManager.get(app).isBusy();
    }

    // ------------------------------------------------------------ genel akış

    private void changed() {
        Listener l = listener;
        if (l != null) l.onChanged();
    }

    private boolean begin(String p, boolean clearDetails) {
        if (busy || otherBusy()) return false;
        busy = true;
        progress = p;
        note = "";
        bootstrapped = false;
        if (clearDetails) details.setLength(0);
        changed();
        return true;
    }

    private void end(String finalNote) {
        busy = false;
        progress = "";
        note = finalNote == null ? "" : finalNote;
        // Masaüstü durumu onarım sırasında değişmiş olabilir: gerçek durumu yeniden oku.
        DesktopController.get(app).refresh();
        changed();
    }

    private void step(String p) {
        progress = p;
        changed();
    }

    private void set(Area a, Level lv, String title, String detail, boolean fixable) {
        results.put(a, new Finding(lv, title, detail, fixable));
        LogManager.log(lv == Level.FAIL ? LogManager.Level.ERROR
                : lv == Level.WARN ? LogManager.Level.WARNING : LogManager.Level.INFO,
                "REPAIR", areaName(a) + ": " + title);
    }

    private void logCmd(String label, CommandResult r) {
        details.append("== ").append(label).append(" (exit=").append(r.exitCode).append(")\n");
        if (r.stdout.length() > 0) details.append(r.stdout.trim()).append('\n');
        if (r.stderr.length() > 0) details.append("stderr: ").append(r.stderr.trim()).append('\n');
        if (!r.ok && r.error.length() > 0) details.append("hata: ").append(r.error).append('\n');
        details.append('\n');
        if (details.length() > MAX_DETAILS) details.delete(0, details.length() - MAX_DETAILS);
    }

    private boolean termuxReady() {
        return TermuxDetector.check(app, TermuxDetector.TERMUX).installed && TermuxRunner.hasPermission(app);
    }

    // ------------------------------------------------------------ komut çalıştırma

    private void execId(final CommandBuilder.Id id, final long timeout, final TermuxRunner.Callback cb) {
        CommandBuilder.Spec spec;
        try {
            spec = CommandBuilder.build(app, id);
        } catch (RuntimeException e) {
            cb.onResult(CommandResult.failure("Komut hazırlanamadı: " + e.getMessage()));
            return;
        }
        exec(spec, timeout, cb);
    }

    private void execTheme(final CommandBuilder.ThemeOp op, final String themeId, final long timeout,
                           final TermuxRunner.Callback cb) {
        CommandBuilder.Spec spec;
        try {
            spec = CommandBuilder.theme(app, op, themeId);
        } catch (RuntimeException e) {
            cb.onResult(CommandResult.failure("Komut hazırlanamadı: " + e.getMessage()));
            return;
        }
        exec(spec, timeout, cb);
    }

    /** Script Dahili Debian'ta yoksa (çıkış 127) scriptleri yazar ve komutu bir kez daha dener. */
    private void exec(final CommandBuilder.Spec spec, final long timeout, final TermuxRunner.Callback cb) {
        TermuxRunner.run(app, spec, timeout, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                logCmd(spec.label, r);
                if (r.exitCode != 127 || bootstrapped) { cb.onResult(r); return; }
                bootstrapped = true;
                LogManager.warn("REPAIR", "Script Dahili Debian'ta yok, yazılıyor: " + spec.label);
                TermuxRunner.run(app, CommandBuilder.Id.INSTALL_SCRIPTS, SHORT_MS,
                        new TermuxRunner.Callback() {
                    @Override public void onResult(CommandResult w) {
                        logCmd("Scriptleri kur", w);
                        if (!w.ok) { cb.onResult(w); return; }
                        TermuxRunner.run(app, spec, timeout, new TermuxRunner.Callback() {
                            @Override public void onResult(CommandResult r2) {
                                logCmd(spec.label + " (tekrar)", r2);
                                cb.onResult(r2);
                            }
                        });
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------ dışarıya açık işlemler

    /** Tek alanı salt-okunur kontrol eder. */
    public void check(final Area a) {
        if (!begin(areaName(a) + " kontrol ediliyor...", true)) return;
        checkArea(a, new Done() {
            @Override public void done() { end(""); }
        });
    }

    /** Tek alan: kontrol et, giderilebilir sorun varsa onar, sonucu doğrula. */
    public void repair(final Area a) {
        if (!begin(areaName(a) + " kontrol ediliyor...", true)) return;
        checkArea(a, new Done() {
            @Override public void done() {
                Finding f = results.get(a);
                if (f == null || !f.needsFix()) {
                    end(f != null && f.level == Level.OK ? "✓ " + areaName(a) + ": onarım gerekmiyor." : "");
                    return;
                }
                step(areaName(a) + " onarılıyor...");
                fixArea(a, new Done() {
                    @Override public void done() {
                        Finding g = results.get(a);
                        end(g != null && g.level == Level.OK ? "✓ " + areaName(a) + " onarıldı."
                                : "⚠ " + areaName(a) + " tam onarılamadı. Ayrıntılar aşağıda.");
                    }
                });
            }
        });
    }

    /** Tam Sistem Kontrolü: bütün alanlar sırayla, salt-okunur. */
    public void checkAll() {
        if (!begin("Sistem kontrol ediliyor...", true)) return;
        results.clear();
        runChecks(new Done() {
            @Override public void done() { end(summaryNote("Kontrol bitti")); }
        });
    }

    /** Otomatik Onar: tam kontrol, sonra giderilebilen her sorun için onarım, en sonda tekrar doğrulama. */
    public void autoRepair() {
        if (!begin("Sistem kontrol ediliyor...", true)) return;
        results.clear();
        runChecks(new Done() {
            @Override public void done() { fixChain(0, 0); }
        });
    }

    // ------------------------------------------------------------ zincirler

    private void runChecks(final Done end) {
        checkArea(Area.TERMUX, new Done() {
            @Override public void done() {
                Finding t = results.get(Area.TERMUX);
                if (t != null && t.level == Level.FAIL) {
                    // Dahili Debian olmadan diğer kontroller anlamsız: dürüstçe atla.
                    for (Area a : ALL) {
                        if (a != Area.TERMUX) {
                            set(a, Level.SKIP, "Kontrol edilemedi", "Önce Dahili Debian sorununu çöz.", false);
                        }
                    }
                    end.done();
                    return;
                }
                checkChain(1, end);
            }
        });
    }

    private void checkChain(final int i, final Done end) {
        if (i >= ALL.length) { end.done(); return; }
        step(areaName(ALL[i]) + " kontrol ediliyor...");
        checkArea(ALL[i], new Done() {
            @Override public void done() { checkChain(i + 1, end); }
        });
    }

    private void fixChain(final int i, final int fixedSoFar) {
        if (i >= FIX_ORDER.length) {
            end(summaryNote(fixedSoFar > 0 ? fixedSoFar + " alan onarıldı" : "Onarılacak bir şey bulunamadı"));
            return;
        }
        final Area a = FIX_ORDER[i];
        Finding f = results.get(a);
        if (f == null || !f.needsFix()) { fixChain(i + 1, fixedSoFar); return; }
        step(areaName(a) + " onarılıyor...");
        fixArea(a, new Done() {
            @Override public void done() {
                Finding g = results.get(a);
                int add = g != null && g.level == Level.OK ? 1 : 0;
                fixChain(i + 1, fixedSoFar + add);
            }
        });
    }

    private String summaryNote(String head) {
        int ok = 0, warn = 0, fail = 0;
        for (Finding f : results.values()) {
            if (f.level == Level.OK) ok++;
            else if (f.level == Level.WARN) warn++;
            else if (f.level == Level.FAIL) fail++;
        }
        String s = head + ": " + ok + " tamam";
        if (warn > 0) s += ", " + warn + " uyarı";
        if (fail > 0) s += ", " + fail + " sorun";
        return (fail > 0 ? "⚠ " : "✓ ") + s + ".";
    }

    // ------------------------------------------------------------ alan başına kontrol

    private void checkArea(Area a, Done d) {
        switch (a) {
            case TERMUX: checkRuntime(d); break;
            case X11: checkX11(d); break;
            case XFCE:
                if ("KDE Plasma".equals(StateManager.load(app).desktop)) { set(Area.XFCE, Level.SKIP, "Atlandı", "Seçili masaüstü KDE Plasma.", false); d.done(); }
                else checkScript(Area.XFCE, CommandBuilder.Id.REPAIR_XFCE, false, d);
                break;
            case KDE:
                if (!"KDE Plasma".equals(StateManager.load(app).desktop)) { set(Area.KDE, Level.SKIP, "Atlandı", "Seçili masaüstü XFCE.", false); d.done(); }
                else checkScript(Area.KDE, CommandBuilder.Id.REPAIR_KDE, false, d);
                break;
            case PACKAGES: checkScript(Area.PACKAGES, CommandBuilder.Id.REPAIR_PACKAGES, false, d); break;
            case THEME: checkTheme(d); break;
            default: checkStartup(d); break;
        }
    }

    private void fixArea(Area a, Done d) {
        switch (a) {
            case X11: fixX11(d); break;
            case XFCE: checkScript(Area.XFCE, CommandBuilder.Id.REPAIR_XFCE_FIX, true, d); break;
            case KDE: checkScript(Area.KDE, CommandBuilder.Id.REPAIR_KDE_FIX, true, d); break;
            case PACKAGES: checkScript(Area.PACKAGES, CommandBuilder.Id.REPAIR_PACKAGES_FIX, true, d); break;
            case THEME: fixTheme(d); break;
            case STARTUP: fixStartup(d); break;
            default: d.done(); break; // Dahili Debian: kullanıcı müdahalesi gerekir
        }
    }

    // ---- Dahili Debian

    private void checkRuntime(final Done d) {
        TermuxDetector.Result tx = TermuxDetector.check(app, TermuxDetector.TERMUX);
        if (!tx.installed) {
            set(Area.TERMUX, Level.FAIL, "Dahili Debian kurulu değil",
                    "X7'nin Linux masaüstünü kurabilmesi için Dahili Debian gerekir. Home sekmesinden resmi kaynağa git.",
                    false);
            d.done();
            return;
        }
        if (!TermuxRunner.hasPermission(app)) {
            set(Area.TERMUX, Level.FAIL, "Komut izni verilmedi",
                    "Dahili Debian'a komut gönderebilmek için RUN_COMMAND izni gerekir. Aşağıdaki \"İzni İste\" düğmesini kullan.",
                    false);
            d.done();
            return;
        }
        execId(CommandBuilder.Id.REPAIR_TERMUX, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (r.exitCode == -1) {
                    set(Area.TERMUX, Level.FAIL, "Dahili Debian'a ulaşılamadı", r.error, false);
                    d.done();
                    return;
                }
                Map<String, String> kv = r.keyValues();
                String cause = kv.get("cause");
                String free = freeText(kv.get("free_mb"));
                if (r.ok && "none".equals(cause)) {
                    set(Area.TERMUX, Level.OK, "Dahili Debian hazır", free, false);
                } else if ("low_storage".equals(cause)) {
                    set(Area.TERMUX, Level.WARN, "Depolama az",
                            free + ". Paket kurulumu için daha fazla boş alan gerekebilir.", false);
                } else if ("no_cmd".equals(cause)) {
                    set(Area.TERMUX, Level.FAIL, "Dahili Debian'ta temel komut eksik",
                            "Eksik: " + kv.get("missing") + ". Dahili Debian'u güncelle veya yeniden kur.", false);
                } else if ("home_ro".equals(cause)) {
                    set(Area.TERMUX, Level.FAIL, "Dahili Debian ev dizini yazılamıyor",
                            "Dahili Debian verisi bozulmuş olabilir.", false);
                } else {
                    set(Area.TERMUX, Level.FAIL, "Dahili Debian kontrolü başarısız", r.error, false);
                }
                d.done();
            }
        });
    }

    private static String freeText(String mb) {
        try {
            int v = Integer.parseInt(mb);
            if (v >= 0) return "Boş alan: " + v + " MB";
        } catch (Exception ignored) { }
        return "Boş alan okunamadı";
    }

    // ---- X11

    private void checkX11(final Done d) {
        if (!TermuxDetector.check(app, TermuxDetector.X11).installed) {
            X11Diagnosis x = X11Diagnosis.noX11App();
            set(Area.X11, Level.FAIL, x.title, x.detail, false);
            d.done();
            return;
        }
        if (!termuxReady()) {
            set(Area.X11, Level.SKIP, "Kontrol edilemedi", "Dahili Debian hazır değil.", false);
            d.done();
            return;
        }
        execId(CommandBuilder.Id.X11_CHECK, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                X11Diagnosis x = X11Diagnosis.fromCheck(r);
                if (x.ok()) set(Area.X11, Level.OK, "X11 hazır", "", false);
                else set(Area.X11, Level.FAIL, x.title, x.detail, x.fixable);
                d.done();
            }
        });
    }

    /** x7-x11repair (temizlik + eksik paketler), sonra x7-x11check ile doğrulama. */
    private void fixX11(final Done d) {
        execId(CommandBuilder.Id.X11_REPAIR, FIX_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                X11Diagnosis x = X11Diagnosis.fromRepair(r);
                if (!x.ok()) {
                    set(Area.X11, Level.FAIL, x.title, x.detail, x.fixable);
                    d.done();
                    return;
                }
                step("X11 doğrulanıyor...");
                checkX11(new Done() {
                    @Override public void done() {
                        Finding f = results.get(Area.X11);
                        DesktopController dc = DesktopController.get(app);
                        if (f != null && f.level == Level.OK
                                && dc.getStatus() == DesktopController.Status.ERROR) {
                            dc.dismissError(); // eski X11 hata kartı artık geçersiz
                        }
                        d.done();
                    }
                });
            }
        });
    }

    // ---- XFCE ve Paketler (aynı script, farklı alan)

    private void checkScript(final Area a, CommandBuilder.Id id, final boolean fixing, final Done d) {
        if (!termuxReady()) {
            set(a, Level.SKIP, "Kontrol edilemedi", "Dahili Debian hazır değil.", false);
            d.done();
            return;
        }
        execId(id, fixing ? FIX_MS : SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (r.exitCode == -1) {
                    set(a, Level.FAIL, "Dahili Debian'a ulaşılamadı", r.error, false);
                    d.done();
                    return;
                }
                Map<String, String> kv = r.keyValues();
                String state = kv.get("state");
                if (r.ok && "ok".equals(state)) {
                    String inst = kv.get("installed");
                    boolean noThunar = a == Area.XFCE && "no".equals(kv.get("bin.thunar"));
                    String ok = a == Area.XFCE ? "XFCE bileşenleri tam" : a == Area.KDE ? "KDE Plasma bileşenleri tam" : "Gerekli paketler kurulu";
                    String det = inst != null && inst.length() > 0 ? "Kuruldu: " + inst : "";
                    if (noThunar) {
                        set(a, Level.WARN, ok + " (dosya yöneticisi yok)",
                                "Thunar kurulu değil; isteğe bağlıdır. " + det, false);
                    } else {
                        set(a, Level.OK, ok, det, false);
                    }
                } else if ("issues".equals(state)) {
                    set(a, Level.FAIL, a == Area.XFCE ? "XFCE eksik veya bozuk" : a == Area.KDE ? "KDE Plasma eksik veya bozuk" : "Gerekli paket eksik",
                            missingText(kv), true);
                } else if ("error".equals(state)) {
                    set(a, Level.FAIL, "Onarım başarısız", errorText(kv, r), true);
                } else {
                    set(a, Level.FAIL, "Kontrol başarısız", r.error, false);
                }
                d.done();
            }
        });
    }

    private static String missingText(Map<String, String> kv) {
        StringBuilder sb = new StringBuilder();
        String p = kv.get("missing_pkgs");
        String b = kv.get("missing_bins");
        if (p != null && p.length() > 0) sb.append("Eksik paket: ").append(p);
        if (b != null && b.length() > 0) {
            if (sb.length() > 0) sb.append('\n');
            sb.append("Eksik dosya: ").append(b);
        }
        return sb.length() == 0 ? "Ayrıntı yok." : sb.toString();
    }

    private static String errorText(Map<String, String> kv, CommandResult r) {
        String cause = kv.get("cause");
        String msg = kv.get("msg");
        if ("no_net".equals(cause)) return "Linux paketlerini indirmek için internet bağlantısı gerekiyor.";
        if ("repo".equals(cause)) return msg != null ? msg : "Paket deposuna ulaşılamadı.";
        return msg != null ? msg : r.error;
    }

    // ---- Tema

    private String themeId() {
        String applied = StateManager.load(app).themeApplied;
        if (applied.length() > 0) return applied;
        List<ThemeInfo> all = ThemeInfo.loadAll(app);
        return all.isEmpty() ? null : all.get(0).id;
    }

    private void checkTheme(final Done d) {
        final String id = themeId();
        if (id == null) {
            set(Area.THEME, Level.FAIL, "Tema tanımı yok", "assets/themes altında geçerli bir theme.json yok.", false);
            d.done();
            return;
        }
        if (!termuxReady()) {
            set(Area.THEME, Level.SKIP, "Kontrol edilemedi", "Dahili Debian hazır değil.", false);
            d.done();
            return;
        }
        execTheme(CommandBuilder.ThemeOp.STATUS, id, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok) {
                    set(Area.THEME, Level.FAIL, "Tema durumu okunamadı", r.error, false);
                    d.done();
                    return;
                }
                Map<String, String> kv = r.keyValues();
                boolean applied = StateManager.load(app).themeApplied.length() > 0;
                if ("complete".equals(kv.get("files"))) {
                    set(Area.THEME, Level.OK, applied ? "Tema dosyaları tam" : "Tema dosyaları hazır",
                            applied ? "" : "Tema henüz uygulanmadı (Themes sekmesi).", false);
                } else if (!applied) {
                    set(Area.THEME, Level.SKIP, "Tema henüz uygulanmadı",
                            "Themes sekmesinden uygularsan dosyalar o sırada kopyalanır.", false);
                } else {
                    String m = kv.get("missing");
                    set(Area.THEME, Level.FAIL, "Tema eksik",
                            "Eksik dosya: " + (m == null || m.length() == 0 ? "?" : m), true);
                }
                d.done();
            }
        });
    }

    /** Tema dosyalarını APK'dan yeniden kopyalar (XFCE ayarlarına dokunmaz), sonra doğrular. */
    private void fixTheme(final Done d) {
        final String id = themeId();
        if (id == null) { d.done(); return; }
        execTheme(CommandBuilder.ThemeOp.FILES, id, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok || !"ok".equals(r.keyValues().get("files"))) {
                    set(Area.THEME, Level.FAIL, "Tema dosyaları kopyalanamadı", r.error, true);
                    d.done();
                    return;
                }
                step("Tema doğrulanıyor...");
                checkTheme(d);
            }
        });
    }

    // ---- Başlangıç scriptleri

    private void checkStartup(final Done d) {
        if (!termuxReady()) {
            set(Area.STARTUP, Level.SKIP, "Kontrol edilemedi", "Dahili Debian hazır değil.", false);
            d.done();
            return;
        }
        execId(CommandBuilder.Id.REPAIR_STARTUP, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (r.exitCode == -1) {
                    set(Area.STARTUP, Level.FAIL, "Dahili Debian'a ulaşılamadı", r.error, false);
                    d.done();
                    return;
                }
                Map<String, String> kv = r.keyValues();
                Map<String, String> expected = CommandBuilder.scriptHashes(app);
                StringBuilder bad = new StringBuilder();
                int unverified = 0;
                String[] names = CommandBuilder.scriptNames();
                for (String n : names) {
                    String s = kv.get("s." + n);
                    if (s == null || "missing".equals(s)) { addBad(bad, n, "eksik"); continue; }
                    if ("notexec".equals(s)) { addBad(bad, n, "çalıştırma izni yok"); continue; }
                    if ("syntax".equals(s)) { addBad(bad, n, "bozuk (sözdizimi hatası)"); continue; }
                    String h = kv.get("h." + n);
                    String exp = expected.get(n);
                    if (h == null || "unknown".equals(h) || exp == null || exp.length() == 0) { unverified++; continue; }
                    if (!exp.equals(h)) addBad(bad, n, "güncel değil");
                }
                if (bad.length() > 0) {
                    set(Area.STARTUP, Level.FAIL, "Başlangıç scriptleri eksik veya güncel değil", bad.toString(), true);
                } else if (unverified > 0) {
                    set(Area.STARTUP, Level.WARN, "Scriptler yerinde, sürümleri doğrulanamadı",
                            unverified + " script için SHA-256 karşılaştırması yapılamadı. Onar ile yeniden yazabilirsin.",
                            true);
                } else {
                    set(Area.STARTUP, Level.OK, "Scriptler yerinde ve güncel",
                            bootstrapped ? "Eksik scriptler bu kontrol sırasında yazıldı." : names.length + " script doğrulandı.",
                            false);
                }
                d.done();
            }
        });
    }

    private static void addBad(StringBuilder sb, String name, String why) {
        if (sb.length() > 0) sb.append('\n');
        sb.append(name).append(": ").append(why);
    }

    /** Bütün scriptleri APK'daki sürümleriyle yeniden yazar, sonra özet karşılaştırmasıyla doğrular. */
    private void fixStartup(final Done d) {
        execId(CommandBuilder.Id.INSTALL_SCRIPTS, SHORT_MS, new TermuxRunner.Callback() {
            @Override public void onResult(CommandResult r) {
                if (!r.ok || !"ok".equals(r.keyValues().get("scripts"))) {
                    set(Area.STARTUP, Level.FAIL, "Scriptler Dahili Debian'a yazılamadı", r.error, true);
                    d.done();
                    return;
                }
                step("Scriptler doğrulanıyor...");
                checkStartup(d);
            }
        });
    }
}
