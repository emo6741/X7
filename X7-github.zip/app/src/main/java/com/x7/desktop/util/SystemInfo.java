package com.x7.desktop.util;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import java.util.Locale;

/** Gerçek cihaz değerlerini okur. Okunamazsa "Bilinmiyor" döner, uydurma değer yok. */
public final class SystemInfo {
    private SystemInfo() {}

    public static String android() {
        return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
    }

    public static String ram(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return fmt(mi.availMem) + " boş / " + fmt(mi.totalMem);
        } catch (Exception e) {
            return "Bilinmiyor";
        }
    }

    public static String storage() {
        try {
            StatFs s = new StatFs(Environment.getDataDirectory().getPath());
            return fmt(s.getAvailableBytes()) + " boş / " + fmt(s.getTotalBytes());
        } catch (Exception e) {
            return "Bilinmiyor";
        }
    }

    /** Kullanım yüzdesi Android'de kolay okunamaz; yalnızca çekirdek sayısı gerçek. */
    public static String cpu() {
        int n = Runtime.getRuntime().availableProcessors();
        return n + " çekirdek (kullanım: Bilinmiyor)";
    }

    public static String fmt(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1) return String.format(Locale.US, "%.1f GB", gb);
        return String.format(Locale.US, "%d MB", bytes / (1024 * 1024));
    }


    /** Linux/Android kernel toplam CPU kullanımını örnekler; okunamazsa -1. */
    public static int cpuUsagePercent() {
        long[] a = cpuTimes();
        if (a == null) return -1;
        try { Thread.sleep(80); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        long[] b = cpuTimes();
        if (b == null) return -1;
        long total = b[0] - a[0];
        long idle = b[1] - a[1];
        if (total <= 0) return -1;
        return Math.max(0, Math.min(100, (int)Math.round(100.0 * (total - idle) / total)));
    }

    private static long[] cpuTimes() {
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/proc/stat"));
            String line = r.readLine(); r.close();
            if (line == null || !line.startsWith("cpu ")) return null;
            String[] p = line.trim().split("\\s+");
            if (p.length < 5) return null;
            long user=Long.parseLong(p[1]), nice=Long.parseLong(p[2]), sys=Long.parseLong(p[3]), idle=Long.parseLong(p[4]);
            long iowait=p.length>5?Long.parseLong(p[5]):0;
            long irq=p.length>6?Long.parseLong(p[6]):0, soft=p.length>7?Long.parseLong(p[7]):0, steal=p.length>8?Long.parseLong(p[8]):0;
            return new long[]{user+nice+sys+idle+iowait+irq+soft+steal, idle+iowait};
        } catch (Exception e) { return null; }
    }

    /** Android veri bölümündeki boş bayt. Okunamazsa -1. */
    public static long freeBytes() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes();
        } catch (Exception e) {
            return -1;
        }
    }

    public static long ramTotal(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.totalMem;
        } catch (Exception e) { return -1; }
    }

    public static long ramAvail(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Exception e) { return -1; }
    }

    public static long storageTotal() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getTotalBytes();
        } catch (Exception e) { return -1; }
    }

    public static String abi() {
        try {
            return Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?";
        } catch (Exception e) { return "?"; }
    }
}
