package com.x7.desktop.ui;

import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.EmbeddedDebianRuntime;

/** Dahili Debian terminali: komutlar uygulamanın kendi rootfs'inde çalışır. */
public final class TerminalPage {
    private TerminalPage() {}
    public static View build(final Ui ui, final MainActivity act) {
        LinearLayout col=ui.column();
        col.addView(ui.text("Dahili Terminal",28,ui.text,true));
        col.addView(ui.text("Komutlar X7'nin kendi Debian rootfs'i içinde çalışır. Termux gerekmez.",13,ui.sub,false));
        col.addView(sp(ui,10));
        final TextView out=ui.text("x7@debian:~$ Terminal hazır\\n",12,0xFFE8EDF5,false);
        out.setTypeface(Typeface.MONOSPACE); out.setPadding(ui.dp(12),ui.dp(12),ui.dp(12),ui.dp(12));
        LinearLayout card=ui.addCard(col); card.setBackground(ui.rounded(0xFF071019,12,ui.stroke));
        ScrollView sv=new ScrollView(ui.ctx); sv.setFillViewport(true); sv.addView(out,new ScrollView.LayoutParams(-1,-1));
        card.addView(sv,new LinearLayout.LayoutParams(-1,ui.dp(300)));
        final EditText input=new EditText(ui.ctx); input.setSingleLine(true); input.setHint("debian komutu…"); input.setTextColor(ui.text); input.setHintTextColor(ui.sub); input.setTypeface(Typeface.MONOSPACE); input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LinearLayout row=ui.row(); row.setGravity(Gravity.CENTER_VERTICAL); row.addView(input,new LinearLayout.LayoutParams(0,ui.dp(52),1));
        TextView run=ui.addButton(row,"Çalıştır",true,v->{
            String cmd=input.getText().toString().trim(); if(cmd.isEmpty()) return;
            out.append("\\n$ "+cmd+"\\n"); input.setText("");
            new EmbeddedDebianRuntime(act).shell(cmd,(ok,text)->act.runOnUiThread(()->{out.append((text==null?"":text)+"\\n"); sv.post(()->sv.fullScroll(View.FOCUS_DOWN));}));
        }); run.setMinWidth(ui.dp(110)); col.addView(row);
        ui.addButton(col,"APT güncelle",false,v->new EmbeddedDebianRuntime(act).shell("apt-get update",(ok,t)->act.runOnUiThread(()->out.append("\\n"+t+"\\n"))));
        return ui.scroll(col);
    }
    private static View sp(Ui u,int d){View v=new View(u.ctx);v.setLayoutParams(new LinearLayout.LayoutParams(1,u.dp(d)));return v;}
}
