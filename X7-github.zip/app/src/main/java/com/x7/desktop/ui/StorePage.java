package com.x7.desktop.ui;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.EmbeddedDebianRuntime;

/** Debian paket mağazası. Kurulumlar doğrudan apt-get ile rootfs'e yapılır. */
public final class StorePage {
    private StorePage() {}
    private static final String[][] PKGS={
            {"XFCE Desktop","xfce4 xfce4-terminal dbus-x11","Hafif Linux masaüstü ve terminal"},
            {"Firefox","firefox-esr","Web tarayıcısı"},
            {"Chromium","chromium","Chromium web tarayıcısı"},
            {"VLC","vlc","Medya oynatıcı"},
            {"Git","git","Sürüm kontrolü"},
            {"Python 3","python3 python3-pip","Python geliştirme araçları"},
            {"KDE Plasma","kde-plasma-desktop","Tam KDE masaüstü (büyük paket)"}
    };
    public static View build(final Ui ui, final MainActivity act){
        LinearLayout col=ui.column(); col.addView(ui.text("Uygulama Mağazası",28,ui.text,true));
        col.addView(ui.text("Debian depolarındaki paketleri doğrudan dahili Linux sistemine kur.",13,ui.sub,false));
        col.addView(ui.addButton(col,"Paket listesini güncelle (apt-get update)",false,v->run(act,ui,"apt-get update",null)));
        for(String[] p:PKGS){
            LinearLayout c=ui.addCard(col); c.addView(ui.text(p[0],17,ui.text,true)); c.addView(ui.text(p[2],12,ui.sub,false));
            TextView b=ui.addButton(c,"Kur: "+p[1],true,v->run(act,ui,"DEBIAN_FRONTEND=noninteractive apt-get install -y "+p[1],null));
        }
        return ui.scroll(col);
    }
    private static void run(MainActivity act,Ui ui,String cmd,Runnable done){
        new EmbeddedDebianRuntime(act).shell(cmd,(ok,out)->act.runOnUiThread(()->{
            new android.app.AlertDialog.Builder(act).setTitle(ok?"Tamamlandı":"İşlem başarısız").setMessage(out==null?"":out).setPositiveButton("Kapat",null).show();
            if(done!=null)done.run();
        }));
    }
}
