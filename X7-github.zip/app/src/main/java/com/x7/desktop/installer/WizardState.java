package com.x7.desktop.installer;

/** Sihirbazın ekran durumu. Ekran yeniden çizilse de (döndürme vb.) korunur. */
public final class WizardState {
    private WizardState() {}

    public static int screen = 0; // 0 hoş geldin, 1 kontrol, 2 masaüstü, 3 depolama, 4 özet, 5 kurulum
    public static boolean netChecking = false;
    public static Boolean netOk = null;
    public static String netMsg = "";
    public static boolean estimating = false;
    public static Estimate estimate = null;
}
