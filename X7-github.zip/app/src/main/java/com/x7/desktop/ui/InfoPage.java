package com.x7.desktop.ui;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;

/** Fotoğraftaki Hakkında ekranına yakın gerçek uygulama bilgileri. */
public final class InfoPage {
    private InfoPage() {}
    public static View build(final Ui ui, String ignoredTitle, String ignoredDesc, String ignoredStage) {
        LinearLayout col=ui.column();
        LinearLayout h=new LinearLayout(ui.ctx); h.setGravity(Gravity.CENTER_VERTICAL);
        TextView x=ui.text("X7",31,ui.accent,true); x.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD_ITALIC));
        h.addView(x,new LinearLayout.LayoutParams(ui.dp(42),-2));
        h.addView(ui.text("Hakkında",21,ui.text,true)); col.addView(h);
        col.addView(ui.text("Uygulama bilgileri",13,ui.sub,false));
        TextView logo=ui.text("X7",64,ui.accent,true); logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD_ITALIC));
        col.addView(logo,new LinearLayout.LayoutParams(-1,ui.dp(90)));
        TextView ver=ui.text("v0.13.0",18,ui.text,true); ver.setGravity(Gravity.CENTER); col.addView(ver);
        TextView sub=ui.text("Android'da Linux Deneyimi",13,ui.sub,false); sub.setGravity(Gravity.CENTER); col.addView(sub);
        LinearLayout c=ui.addCard(col);
        ui.addRow(c,"Geliştirici","X7 Team"); ui.addRow(c,"Sürüm","0.13.0");
        ui.addRow(c,"Android","13+"); ui.addRow(c,"Min SDK","24"); ui.addRow(c,"Compile SDK","34"); ui.addRow(c,"Java","17"); ui.addRow(c,"Lisans","MIT");
        ui.addButton(c,"GitHub",false,new View.OnClickListener(){ public void onClick(View v){ MainActivity a=(MainActivity)ui.ctx; try{ a.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse("https://github.com/"))); }catch(Exception ignored){} }});
        return ui.scroll(col);
    }
}
