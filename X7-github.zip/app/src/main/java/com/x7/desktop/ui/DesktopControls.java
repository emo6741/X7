package com.x7.desktop.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.DialogInterface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.x7.desktop.MainActivity;
import com.x7.desktop.backend.DesktopController;
import com.x7.desktop.backend.StateManager;
import com.x7.desktop.backend.TermuxDetector;
import com.x7.desktop.backend.X11Diagnosis;

/** Başlat / Durdur / Yeniden Başlat / Zorla Durdur düğmeleri. Home ve Desktop sekmesinde ortak. */
public final class DesktopControls {
    private DesktopControls() {}

    public static String statusText(DesktopController dc) {
        switch (dc.getStatus()) {
            case RUNNING: return "✓ Running";
            case STOPPED: return "Stopped";
            case STARTING: return "⟳ Starting";
            case STOPPING: return "⟳ Stopping";
            case REPAIRING: return "🔧 Repairing";
            case ERROR: return "✗ Error";
            default: return "Bilinmiyor";
        }
    }

    private static TextView disabled(Ui ui, LinearLayout p, String label) {
        TextView b = ui.addButton(p, label, true, null);
        b.setEnabled(false);
        b.setAlpha(0.45f);
        b.setMinHeight(ui.dp(56));
        return b;
    }

    public static void add(final Ui ui, final MainActivity act, LinearLayout parent, boolean showForce) {
        final DesktopController dc = DesktopController.get(act);
        dc.setListener(new DesktopController.Listener() {
            @Override public void onChanged() { act.refresh(); }
        });

        boolean installed = StateManager.load(act).installState == StateManager.InstallState.COMPLETED;
        if (!installed) {
            disabled(ui, parent, "🚀 Masaüstünü Başlat");
            TextView n = ui.text("Önce Desktop sekmesinden kurulumu tamamla.", 13, ui.sub, false);
            n.setPadding(0, ui.dp(8), 0, 0);
            parent.addView(n);
            return;
        }

        DesktopController.Status s = dc.getStatus();
        if (s == DesktopController.Status.STARTING) {
            String p = dc.getProgress();
            disabled(ui, parent, "⟳ " + (p.length() > 0 ? p : "Masaüstü başlatılıyor..."));
        } else if (s == DesktopController.Status.REPAIRING) {
            String p = dc.getProgress();
            disabled(ui, parent, "🔧 " + (p.length() > 0 ? p : "X11 onarılıyor..."));
        } else if (s == DesktopController.Status.ERROR && dc.getDiagnosis() != null) {
            addX11Error(ui, act, parent, dc);
            return; // hata kartı kendi mesajını gösterir
        } else if (s == DesktopController.Status.STOPPING) {
            disabled(ui, parent, "⟳ Masaüstü durduruluyor...");
        } else if (s == DesktopController.Status.RUNNING) {
            TextView stop = ui.addButton(parent, "⏹ Masaüstünü Durdur", true, new View.OnClickListener() {
                @Override public void onClick(View v) { dc.stop(false); }
            });
            stop.setMinHeight(ui.dp(56));
            ui.addButton(parent, "↻ Yeniden Başlat", false, new View.OnClickListener() {
                @Override public void onClick(View v) { dc.restart(); }
            });
            if ("VNC".equals(StateManager.load(act).display)) {
                ui.addButton(parent, "VNC Bağlantısı: 127.0.0.1:5901", false, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        try {
                            Intent i = act.getPackageManager().getLaunchIntentForPackage("com.realvnc.viewer.android");
                            if (i != null) act.startActivity(i);
                            else new AlertDialog.Builder(act).setTitle("VNC hazır")
                                    .setMessage("VNC sunucusu localhost:5901 üzerinde çalışıyor. Android cihazınıza bir VNC Viewer kurup 127.0.0.1:5901 adresine bağlanabilirsiniz.")
                                    .setPositiveButton("Tamam", null).show();
                        } catch (Exception e) {
                            new AlertDialog.Builder(act).setTitle("VNC hazır")
                                    .setMessage("Bağlantı: 127.0.0.1:5901").setPositiveButton("Tamam", null).show();
                        }
                    }
                });
            } else {
                ui.addButton(parent, "Dahili Debian:X11'i Aç", false, new View.OnClickListener() {
                    @Override public void onClick(View v) { TermuxDetector.open(act, TermuxDetector.X11); }
                });
            }
            if (showForce) {
                ui.addButton(parent, "Zorla Durdur", false, new View.OnClickListener() {
                    @Override public void onClick(View v) { confirmForce(act, dc); }
                });
            }
        } else {
            TextView start = ui.addButton(parent, "🚀 Masaüstünü Başlat", true, new View.OnClickListener() {
                @Override public void onClick(View v) { dc.start(); }
            });
            start.setMinHeight(ui.dp(56));
            start.setTextSize(18);
            if (s == DesktopController.Status.UNKNOWN || s == DesktopController.Status.ERROR) {
                ui.addButton(parent, "Durumu Yenile", false, new View.OnClickListener() {
                    @Override public void onClick(View v) { dc.refresh(); }
                });
            }
        }

        if (dc.getMessage().length() > 0) {
            TextView m = ui.text("✗ " + dc.getMessage(), 13, ui.sub, false);
            m.setPadding(0, ui.dp(8), 0, 0);
            m.setTextIsSelectable(true);
            parent.addView(m);
        }
        if (dc.getNotice().length() > 0) {
            TextView n = ui.text(dc.getNotice(), 13, ui.sub, false);
            n.setPadding(0, ui.dp(8), 0, 0);
            parent.addView(n);
        }
    }

    /** "X11 başlatılamadı" kartı: gerçek neden + [Sorunu Çöz] [VNC Kullan] [İptal]. */
    private static void addX11Error(final Ui ui, final MainActivity act, LinearLayout parent,
                                    final DesktopController dc) {
        final X11Diagnosis d = dc.getDiagnosis();
        if (!act.getPreferences(0).getBoolean("x11_guide_shown", false)) {
            act.getPreferences(0).edit().putBoolean("x11_guide_shown", true).apply();
            parent.postDelayed(new Runnable() { @Override public void run() { X11Guide.show(act, d.title + "\n" + d.detail); } }, 250);
        }
        TextView t = ui.text("✗ " + d.title, 17, ui.text, true);
        parent.addView(t);
        TextView det = ui.text(d.detail, 14, ui.sub, false);
        det.setPadding(0, ui.dp(6), 0, ui.dp(2));
        det.setTextIsSelectable(true);
        parent.addView(det);

        if (d.fixable) {
            TextView fix = ui.addButton(parent, "🔧 Sorunu Çöz", true, new View.OnClickListener() {
                @Override public void onClick(View v) { dc.repairX11(); }
            });
            fix.setMinHeight(ui.dp(56));
        } else if (d.cause == X11Diagnosis.Cause.NO_X11_APP) {
            ui.addButton(parent, "Dahili Debian:X11 Nightly APK (GitHub)", true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new AlertDialog.Builder(act).setTitle("Dahili görüntüleme").setMessage("Bu sürüm harici Termux:X11 kullanmaz. Görüntüleme katmanı X7 tarafından yönetilir.").setPositiveButton("Tamam", null).show();
                }
            });
        } else {
            ui.addButton(parent, "Tekrar Dene", true, new View.OnClickListener() {
                @Override public void onClick(View v) { dc.start(); }
            });
        }
        final StateManager st = StateManager.load(act);
        if ("VNC".equals(st.display)) {
            ui.addButton(parent, "🖥 VNC'yi Hazırla / Parolayı Ayarla", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dc.setupVnc(new Runnable() {
                        @Override public void run() {
                            TermuxDetector.open(act, TermuxDetector.TERMUX);
                            new AlertDialog.Builder(act).setTitle("VNC parolası gerekli")
                                    .setMessage("Dahili Debian açıldığında bir kez 'vncpasswd' çalıştır. Parola X7 tarafından okunmaz veya kaydedilmez. Ardından X7'ye dönüp Masaüstünü Başlat'a bas.")
                                    .setPositiveButton("Tamam", null).show();
                        }
                    });
                }
            });
        } else {
            ui.addButton(parent, "🖥 VNC'ye Geç", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    StateManager s = StateManager.load(act);
                    s.setDisplay("VNC");
                    dc.setupVnc(null);
                }
            });
        }
        ui.addButton(parent, "🖥 VNC Kullan", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                StateManager st = StateManager.load(act);
                st.setDisplay("VNC");
                dc.setupVnc(null);
            }
        });
        ui.addButton(parent, "📖 Manuel X11 Bağlantı Rehberi", false, new View.OnClickListener() {
            @Override public void onClick(View v) { X11Guide.show(act, d.title + "\n" + d.detail); }
        });
        ui.addButton(parent, "Teknik Ayrıntılar", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String text = dc.getDetails().length() > 0 ? dc.getDetails() : "(ayrıntı yok)";
                new AlertDialog.Builder(act).setTitle("Teknik Ayrıntılar")
                        .setMessage(text).setPositiveButton("Kapat", null).show();
            }
        });
        ui.addButton(parent, "↩ İptal", false, new View.OnClickListener() {
            @Override public void onClick(View v) { dc.dismissError(); }
        });
    }

    private static void confirmForce(MainActivity act, final DesktopController dc) {
        new AlertDialog.Builder(act)
                .setTitle("Zorla Durdur")
                .setMessage("Masaüstü süreçleri anında sonlandırılır. Kaydedilmemiş veriler kaybolabilir.")
                .setNegativeButton("İptal", null)
                .setPositiveButton("Zorla Durdur", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { dc.stop(true); }
                })
                .show();
    }
}
