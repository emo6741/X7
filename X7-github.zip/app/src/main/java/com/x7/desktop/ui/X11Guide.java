package com.x7.desktop.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.TextView;
import android.app.AlertDialog;

/** Dahili Debian:X11 manuel kurulum/bağlantı rehberi. */
public final class X11Guide {
    private X11Guide() {}
    private static final String NIGHTLY = "https://www.debian.org/";
    private static final String GUIDE =
            "1) Dahili Debian:X11 uygulamasını NIGHTLY sürüm olarak kur.\n\n" +
            "2) Dahili Debian'u aç ve şunları çalıştır:\n" +
            "pkg update\n" +
            "pkg install x11-repo\n" +
            "pkg install termux-x11-nightly xfce4 xfce4-terminal dbus procps xorg-xdpyinfo -y\n\n" +
            "3) X7'nin Dahili Debian'a komut gönderebilmesi için:\n" +
            "mkdir -p ~/.termux\n" +
            "echo 'allow-external-apps=true' >> ~/.termux/termux.properties\n" +
            "termux-reload-settings\n\n" +
            "4) Dahili Debian:X11 uygulamasını aç. Ardından X7'ye dönüp 'Masaüstünü Başlat' de.\n\n" +
            "Manuel başlatmak istersen Dahili Debian'ta:\n" +
            "termux-x11 :1 -legacy-drawing -xstartup \"dbus-launch --exit-with-session xfce4-session\"\n\n" +
            "Siyah ekran varsa -legacy-drawing seçeneğini koru. X11 renkleri tersse -force-bgra deneyebilirsin.";

    public static void show(final Activity a, String reason) {
        String msg = (reason == null || reason.length() == 0 ? "X11 bağlantısı kurulamadı." : reason)
                + "\n\nAşağıdaki manuel adımlar bağlantıyı düzeltmek için kullanılabilir.";
        AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("Dahili Debian:X11 Bağlantı Rehberi")
                .setMessage(msg + "\n\n" + GUIDE)
                .setNegativeButton("Kapat", null)
                .setNeutralButton("Komutu Kopyala", null)
                .setPositiveButton("NIGHTLY'yi Aç", null)
                .create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager)a.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("X11 rehberi", GUIDE));
                TextView m = d.findViewById(android.R.id.message);
                if (m != null) m.setText(msg + "\n\nKomutlar panoya kopyalandı.\n\n" + GUIDE);
            });
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(NIGHTLY))); } catch (Exception ignored) {}
            });
        });
        d.show();
    }
}
