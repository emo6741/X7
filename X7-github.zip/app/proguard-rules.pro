# X7 does not use custom ProGuard/R8 rules.
