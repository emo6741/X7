package com.novabrowser.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private EditText address;
    private FrameLayout content;
    private static final String HOME = "https://www.google.com/";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        setContentView(R.layout.activity_main);
        address = findViewById(R.id.address); content = findViewById(R.id.content);
        setupWebView(); setupButtons();
        if (state == null) webView.loadUrl(HOME); else webView.restoreState(state);
    }

    @SuppressLint("SetJavaScriptEnabled") private void setupWebView() {
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        webView.setClipToOutline(true);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        content.addView(webView); // WebView is permanently attached to the window content; never detach during dragging.

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        CookieManager cm = CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(webView, true);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return handleUrl(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return handleUrl(Uri.parse(url)); }
            @Override public void onPageStarted(WebView v, String url, Bitmap favicon) { address.setText(url); }
            @Override public void onPageFinished(WebView v, String url) { address.setText(url); updateButtons(); }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) { /* keep navigation inside the same WebView */ }
            @Override public void onReceivedSslError(WebView v, SslErrorHandler handler, android.net.http.SslError error) { handler.cancel(); }
            @Override public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail detail) {
                content.removeView(v); v.destroy(); createReplacement(); return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (ActivityNotFoundException ignored) {}
        });
    }

    private void createReplacement() { setupWebView(); webView.loadUrl(HOME); }
    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) {}
        return true;
    }
    private void setupButtons() {
        Button back=findViewById(R.id.back), forward=findViewById(R.id.forward), reload=findViewById(R.id.reload), go=findViewById(R.id.go);
        back.setOnClickListener(v -> { if(webView.canGoBack()) webView.goBack(); updateButtons(); });
        forward.setOnClickListener(v -> { if(webView.canGoForward()) webView.goForward(); updateButtons(); });
        reload.setOnClickListener(v -> webView.reload());
        go.setOnClickListener(v -> navigate());
        address.setOnEditorActionListener((v, actionId, event) -> { navigate(); return true; });
        address.setOnFocusChangeListener((v, has) -> { if(has) address.selectAll(); });
    }
    private void navigate() {
        String q=address.getText().toString().trim(); if(q.isEmpty()) return;
        String u;
        if(q.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) u=q;
        else if(q.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}([/:].*)?$")) u="https://"+q;
        else u="https://www.google.com/search?q="+URLEncoder.encode(q, StandardCharsets.UTF_8);
        webView.loadUrl(u);
    }
    private void updateButtons() { findViewById(R.id.back).setEnabled(webView.canGoBack()); findViewById(R.id.forward).setEnabled(webView.canGoForward()); }
    @Override public void onBackPressed() { if(webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle out) { if(webView != null) webView.saveState(out); super.onSaveInstanceState(out); }
    @Override protected void onDestroy() { if(isFinishing() && webView != null) { webView.stopLoading(); webView.destroy(); } super.onDestroy(); }
}
