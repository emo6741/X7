# NOVA WebView
Android WebView browser shell designed for embedding into a movable window system.

## Important architecture
The WebView is created once and remains a child of the window content container. Do not detach/re-attach or recreate it while moving a desktop window. Move the parent window instead; this avoids the common delayed WebView-following effect.

## Build
GitHub Actions builds with JDK 17. Locally, use a compatible Gradle/AndroidIDE installation and run `assembleDebug`.

## Security
SSL certificate errors are rejected rather than bypassed. JavaScript, DOM storage, cookies, third-party cookies, media, redirects and normal modern Web content are enabled.
